"""Generate the ladder of minimal DEGAUSS validation systems.

Each system adds exactly one complication over the previous one, so a failing
comparison localises immediately:

    s01_onepair  2 atoms, one DE pair, zero charge      the DE form alone
    s02_twopair  3 atoms, two atom types                 ico type-pair indexing
    s03_excl     2 atoms, the pair excluded              exclusion handling
    s04_14       4 atoms, one dihedral                   1-4 scaling
    s05_wat8     24 atoms, TIP3P charges                 Gaussian electrostatics
    s06_alch     2 atoms, region 1 = atom 1              the alchemical path

AMBER topologies are written directly rather than through LEaP or ParmEd: the
whole purpose of this harness is that nothing outside it interprets the
parameters.  (ParmEd 0+untagged is in any case incompatible with numpy 2.x.)
"""

import os
import numpy as np

__all__ = ["build_all"]

# Physical parameters shared by the ladder.  Type 0 is a carbon-like site,
# type 1 a smaller site, type 2 TIP3P hydrogen (no van der Waals).
TYPE_PARAMS = [
    # (eps, rmin_half)
    (0.1521, 1.9000),
    (0.0860, 1.7000),
    (0.0000, 0.0000),
]
COULOMB_SCALE = 18.2223


# --------------------------------------------------------------------------
# prmtop writing primitives
# --------------------------------------------------------------------------

def _fmt_block(values, per_line, width, conv):
    lines = []
    for k in range(0, len(values), per_line):
        lines.append("".join(conv(v, width) for v in values[k:k + per_line]))
    if not lines:
        lines.append("")
    return "\n".join(lines) + "\n"


def _sec_int(name, values):
    return (f"%FLAG {name:<74}\n%FORMAT(10I8)\n"
            + _fmt_block(list(values), 10, 8, lambda v, w: "%*d" % (w, int(v))))


def _sec_real(name, values):
    return (f"%FLAG {name:<74}\n%FORMAT(5E16.8)\n"
            + _fmt_block(list(values), 5, 16, lambda v, w: "%16.8E" % float(v)))


def _sec_char(name, values):
    return (f"%FLAG {name:<74}\n%FORMAT(20a4)\n"
            + _fmt_block(list(values), 20, 4, lambda v, w: "%-4s" % str(v)[:4]))


def _lj_coefficients(type_ids):
    """Lorentz-Berthelot A/B coefficients for the packed type-pair table.

    A = eps*rmin^12 and B = 2*eps*rmin^6, so that pmemd's DEGAUSS fallback
    rmin = (2A/B)^(1/6) and eps = B^2/(4A) recovers exactly these values.
    """
    nt = len(type_ids)
    nttyp = nt * (nt + 1) // 2
    acoef = np.zeros(nttyp)
    bcoef = np.zeros(nttyp)
    for a in range(1, nt + 1):
        for b in range(1, a + 1):
            eps_a, rh_a = TYPE_PARAMS[type_ids[a - 1]]
            eps_b, rh_b = TYPE_PARAMS[type_ids[b - 1]]
            eps = np.sqrt(eps_a * eps_b)
            rmin = rh_a + rh_b
            idx = a * (a - 1) // 2 + b - 1
            acoef[idx] = eps * rmin ** 12
            bcoef[idx] = 2.0 * eps * rmin ** 6
    return acoef, bcoef


def _nonbonded_parm_index(nt):
    ico = np.zeros(nt * nt, dtype=int)
    for i in range(1, nt + 1):
        for j in range(1, nt + 1):
            a, b = max(i, j), min(i, j)
            ico[nt * (i - 1) + (j - 1)] = a * (a - 1) // 2 + b
    return ico


def _excluded_arrays(natom, excl):
    """AMBER lists only partners with index > i; empty entries get one 0."""
    counts, flat = [], []
    for i in range(natom):
        partners = sorted(j for j in excl[i] if j > i)
        if partners:
            counts.append(len(partners))
            flat.extend(j + 1 for j in partners)
        else:
            counts.append(1)
            flat.append(0)
    return counts, flat


def _write_prmtop(path, *, natom, type_ids, atom_type_index, charges, masses,
                  excl, box, residues, bonds=(), angles=(), dihedrals=(),
                  mols=None, widths=None):
    nt = len(type_ids)
    nttyp = nt * (nt + 1) // 2
    acoef, bcoef = _lj_coefficients(type_ids)
    counts, flat_excl = _excluded_arrays(natom, excl)
    nres = len(residues)
    mols = mols if mols is not None else [natom]

    numbnd = 1 if bonds else 0
    numang = 1 if angles else 0
    nptra = 1 if dihedrals else 0

    # Bonds and angles go in the *_INC_HYDROGEN arrays (NBONH, NTHETH);
    # dihedrals go in DIHEDRALS_WITHOUT_HYDROGEN, so they must be counted by
    # MPHIA/NPHIA, not NPHIH.  Getting this wrong makes pmemd read an empty
    # array and silently report a zero 1-4 term.
    ndih = len(dihedrals)
    pointers = [
        natom, nt, len(bonds), 0, len(angles), 0, 0, ndih,
        0, 0, len(flat_excl), nres, 0, 0, ndih, numbnd,
        numang, nptra, nt, 0, 0, 0, 0, 0,
        0, 0, 0, 1, max(r[1] for r in residues) if residues else natom, 0,
        0, 0,
    ]

    out = ["%VERSION  VERSION_STAMP = V0001.000  DATE = 01/01/26  00:00:00\n"]
    out.append("%FLAG TITLE" + " " * 69 + "\n%FORMAT(20a4)\ndegauss validation\n")
    out.append(_sec_int("POINTERS", pointers))
    out.append(_sec_char("ATOM_NAME", ["A%d" % (i + 1) for i in range(natom)]))
    out.append(_sec_real("CHARGE", charges))
    out.append(_sec_int("ATOMIC_NUMBER", [6] * natom))
    out.append(_sec_real("MASS", masses))
    out.append(_sec_int("ATOM_TYPE_INDEX", [t + 1 for t in atom_type_index]))
    out.append(_sec_int("NUMBER_EXCLUDED_ATOMS", counts))
    out.append(_sec_int("NONBONDED_PARM_INDEX", _nonbonded_parm_index(nt)))
    out.append(_sec_char("RESIDUE_LABEL", [r[0] for r in residues]))
    out.append(_sec_int("RESIDUE_POINTER", [r[1] for r in residues]))
    out.append(_sec_real("BOND_FORCE_CONSTANT", [300.0] if numbnd else []))
    out.append(_sec_real("BOND_EQUIL_VALUE", [1.0] if numbnd else []))
    out.append(_sec_real("ANGLE_FORCE_CONSTANT", [50.0] if numang else []))
    out.append(_sec_real("ANGLE_EQUIL_VALUE", [1.9] if numang else []))
    out.append(_sec_real("DIHEDRAL_FORCE_CONSTANT", [0.0] if nptra else []))
    out.append(_sec_real("DIHEDRAL_PERIODICITY", [2.0] if nptra else []))
    out.append(_sec_real("DIHEDRAL_PHASE", [0.0] if nptra else []))
    out.append(_sec_real("SCEE_SCALE_FACTOR", [1.2] if nptra else []))
    out.append(_sec_real("SCNB_SCALE_FACTOR", [2.0] if nptra else []))
    out.append(_sec_real("SOLTY", [0.0] * nt))
    out.append(_sec_real("LENNARD_JONES_ACOEF", acoef))
    out.append(_sec_real("LENNARD_JONES_BCOEF", bcoef))
    out.append(_sec_int("BONDS_INC_HYDROGEN",
                        [v for b in bonds for v in (b[0] * 3, b[1] * 3, 1)]))
    out.append(_sec_int("BONDS_WITHOUT_HYDROGEN", []))
    out.append(_sec_int("ANGLES_INC_HYDROGEN",
                        [v for a in angles
                         for v in (a[0] * 3, a[1] * 3, a[2] * 3, 1)]))
    out.append(_sec_int("ANGLES_WITHOUT_HYDROGEN", []))
    out.append(_sec_int("DIHEDRALS_INC_HYDROGEN", []))
    out.append(_sec_int("DIHEDRALS_WITHOUT_HYDROGEN",
                        [v for d in dihedrals
                         for v in (d[0] * 3, d[1] * 3, d[2] * 3, d[3] * 3, 1)]))
    out.append(_sec_int("EXCLUDED_ATOMS_LIST", flat_excl))
    out.append(_sec_real("HBOND_ACOEF", []))
    out.append(_sec_real("HBOND_BCOEF", []))
    out.append(_sec_real("HBCUT", []))
    out.append(_sec_char("AMBER_ATOM_TYPE", ["T%d" % t for t in atom_type_index]))
    out.append(_sec_char("TREE_CHAIN_CLASSIFICATION", ["BLA"] * natom))
    out.append(_sec_int("JOIN_ARRAY", [0] * natom))
    out.append(_sec_int("IROTAT", [0] * natom))
    out.append(_sec_int("SOLVENT_POINTERS", [nres, len(mols), len(mols) + 1]))
    out.append(_sec_int("ATOMS_PER_MOLECULE", mols))
    out.append(_sec_real("BOX_DIMENSIONS", [90.0, box[0], box[1], box[2]]))
    out.append(_sec_int("IPOL", [0]))
    if widths is not None:
        out.append(_sec_real("GAUSS_RADII_LIST", widths))

    with open(path, "w") as fh:
        fh.write("".join(out))


def _write_inpcrd(path, crd, box):
    crd = np.asarray(crd, dtype=float)
    with open(path, "w") as fh:
        fh.write("degauss validation\n%6d\n" % len(crd))
        flat = crd.reshape(-1)
        for k in range(0, len(flat), 6):
            fh.write("".join("%12.7f" % v for v in flat[k:k + 6]) + "\n")
        fh.write("".join("%12.7f" % v for v in list(box) + [90.0, 90.0, 90.0]) + "\n")


# --------------------------------------------------------------------------
# the ladder
# --------------------------------------------------------------------------

def _tip3p_box(nmol=8, spacing=6.0):
    """A cubic lattice of rigid TIP3P-geometry waters, well separated."""
    geom = np.array([[0.0, 0.0, 0.0],
                     [0.9572, 0.0, 0.0],
                     [-0.2399872, 0.9266272, 0.0]])
    side = int(np.ceil(nmol ** (1.0 / 3.0)))
    crd, k = [], 0
    for a in range(side):
        for b in range(side):
            for c in range(side):
                if k >= nmol:
                    break
                crd.append(geom + np.array([a, b, c]) * spacing)
                k += 1
    return np.vstack(crd[:nmol])


def build_all(dest):
    os.makedirs(dest, exist_ok=True)
    out = {}

    def emit(name, *, natom, type_ids, ati, charges, masses, excl, box, crd,
             residues, bonds=(), angles=(), dihedrals=(), mols=None):
        d = os.path.join(dest, name)
        os.makedirs(d, exist_ok=True)
        p, c = os.path.join(d, "prmtop"), os.path.join(d, "inpcrd")
        _write_prmtop(p, natom=natom, type_ids=type_ids, atom_type_index=ati,
                      charges=charges, masses=masses, excl=excl, box=box,
                      residues=residues, bonds=bonds, angles=angles,
                      dihedrals=dihedrals, mols=mols)
        _write_inpcrd(c, crd, box)
        out[name] = {"prmtop": p, "inpcrd": c, "box": tuple(box),
                     "natom": natom, "dir": d}

    box = [50.0, 50.0, 50.0]

    # s01: one DE pair.
    emit("s01_onepair", natom=2, type_ids=[0], ati=[0, 0],
         charges=[0.0, 0.0], masses=[12.011] * 2,
         excl=[set(), set()], box=box,
         crd=[[0, 0, 0], [4.2, 0, 0]],
         residues=[("MOL", 1)], mols=[1, 1])

    # s02: two atom types, exercising the ico table.
    emit("s02_twopair", natom=3, type_ids=[0, 1], ati=[0, 1, 1],
         charges=[0.0] * 3, masses=[12.011] * 3,
         excl=[set(), set(), set()], box=box,
         crd=[[0, 0, 0], [4.2, 0, 0], [0, 3.9, 0]],
         residues=[("MOL", 1)], mols=[1, 1, 1])

    # s03: the same pair, excluded.
    emit("s03_excl", natom=2, type_ids=[0], ati=[0, 0],
         charges=[0.0, 0.0], masses=[12.011] * 2,
         excl=[{1}, {0}], box=box,
         crd=[[0, 0, 0], [4.2, 0, 0]],
         residues=[("MOL", 1)], mols=[2])

    # s04: a 1-4 pair.  AMBER excludes 1-2, 1-3 and 1-4 from the ordinary
    # non-bonded sum; the 1-4 term is applied separately and scaled.
    emit("s04_14", natom=4, type_ids=[0], ati=[0, 0, 0, 0],
         charges=[0.0] * 4, masses=[12.011] * 4,
         excl=[{1, 2, 3}, {0, 2, 3}, {0, 1, 3}, {0, 1, 2}], box=box,
         crd=[[0, 0, 0], [1.5, 0, 0], [2.1, 1.4, 0], [3.6, 1.4, 0]],
         residues=[("MOL", 1)], dihedrals=[(0, 1, 2, 3)], mols=[4])

    # s05: eight TIP3P waters with real charges.
    nmol = 8
    wat = _tip3p_box(nmol)
    q = np.array([-0.834, 0.417, 0.417] * nmol) * COULOMB_SCALE
    ati, excl, bonds, angles = [], [], [], []
    for m in range(nmol):
        o = 3 * m
        # Indices into this system's own type list (type_ids below), not into
        # the global TYPE_PARAMS table: O -> slot 0, H -> slot 1.
        ati.extend([0, 1, 1])
        excl.extend([{o + 1, o + 2}, {o, o + 2}, {o, o + 1}])
        bonds.extend([(o, o + 1), (o, o + 2)])
        angles.append((o + 1, o, o + 2))
    emit("s05_wat8", natom=3 * nmol, type_ids=[0, 2], ati=ati,
         charges=q, masses=[16.0, 1.008, 1.008] * nmol,
         excl=excl, box=[24.0, 24.0, 24.0], crd=wat,
         residues=[("WAT", 3 * m + 1) for m in range(nmol)],
         bonds=bonds, angles=angles, mols=[3] * nmol)

    # s06: the alchemical system -- atom 1 is region 1 (":1").
    emit("s06_alch", natom=2, type_ids=[0], ati=[0, 0],
         charges=[0.0, 0.0], masses=[12.011] * 2,
         excl=[set(), set()], box=box,
         crd=[[0, 0, 0], [4.2, 0, 0]],
         residues=[("MOL", 1), ("MOL", 2)], mols=[1, 1])

    return out


if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    for name, info in sorted(build_all(here).items()):
        print(f"{name:14s} natom={info['natom']:3d}  {info['prmtop']}")
