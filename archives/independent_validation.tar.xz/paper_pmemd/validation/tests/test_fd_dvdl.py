"""Validation of the alchemical energy and dV/dlambda for every ifsc_v mode.

Two independent checks are made:

1. against the external reference, which implements each mode from the
   manuscript/design description and shares no code with pmemd;
2. against pmemd's own energy differences (finite-difference self-consistency).

Check 1 is the sharper of the two.  A finite difference of pmemd's printed
EPtot is limited by the F14.4 print quantum: dividing 5e-5 by 2h gives a
resolution of 0.25 kcal/mol at h=1e-4, which is coarser than the quantities
being tested here.  The step is therefore chosen large enough that the print
quantum is negligible, and the reference comparison carries the precision.

The code audit records that no finite-difference validation of forces or
dV/dlambda existed anywhere in the AMBER tree; this is the first.
"""

import numpy as np
import pytest
from runner import write_mdin, run_pmemd
from systems.build_systems import build_all
from degauss_ref.topology import DegaussTopology
from degauss_ref.alchemy import u_lambda, dudl_numeric

# mdout prints F14.4, so nothing tighter than 5e-5 can be asserted.
MDOUT_PRECISION = 1.0e-4

# Finite-difference step for the self-consistency check.  h=0.02 puts the
# print-quantum resolution at 5e-5/0.04 = 1.3e-3 while keeping truncation
# error O(h^2 * U''') ~ 1e-3 for these smooth schedules.
HL = 0.02
FD_TOL = 5.0e-3

LAMBDAS = (0.25, 0.5, 0.75)

# User-facing ifsc_v values, with the reference's matching keyword arguments.
MODES = [
    pytest.param(dict(ifsc_v=0), 0, {}, id="v0_direct"),
    pytest.param(dict(ifsc_v=1, de_prefactor_k=3.0, de_prefactor_j=3.0),
                 1, dict(k=3.0, j=3.0), id="v1_prefactor"),
    pytest.param(dict(ifsc_v=2, alpha_min=5.0, beta_min=4.0, de_schedule=2),
                 2, dict(alpha_min=5.0, beta_min=4.0, schedule=2),
                 id="v2_steepness"),
    pytest.param(dict(ifsc_v=3, de_sc_alpha=0.5), 3, dict(sc_alpha=0.5),
                 id="v3_softcore"),
]

BASE = dict(imin=0, nstlim=0, ntx=1, irest=0, ntb=1, ntt=0, cut=9.0,
            idegauss=1, ips=0, ntpr=1, ntwx=0, ntwr=0)
# AMBER requires the softcore masks so the TI atoms are not counted as
# linearly scaled atoms; without them setup aborts with
# "The number of linearly scaled atoms must be the same".
MASKS = dict(icfe=1, ifsc=1, timask1=":1", timask2="",
             scmask1=":1", scmask2="")

BOX = np.array([50.0, 50.0, 50.0])
CRD = np.array([[0.0, 0.0, 0.0], [4.2, 0.0, 0.0]])


@pytest.fixture(scope="module")
def systems(tmp_path_factory):
    return build_all(str(tmp_path_factory.mktemp("systems")))


@pytest.fixture(scope="module")
def top(systems):
    return DegaussTopology.from_prmtop(systems["s06_alch"]["prmtop"])


def _run(tmp_path, info, lam, tag, extra):
    mdin = str(tmp_path / f"mdin_{tag}")
    write_mdin(mdin, clambda=lam, **BASE, **MASKS, **extra)
    return run_pmemd(str(tmp_path / tag), info["prmtop"], info["inpcrd"], mdin)


@pytest.mark.parametrize("extra,mode,refkw", MODES)
def test_alchemical_energy_matches_the_reference(
        tmp_path, systems, top, extra, mode, refkw):
    info = systems["s06_alch"]
    for lam in LAMBDAS:
        out = _run(tmp_path, info, lam, f"e{mode}{str(lam)[2:]}", extra)
        want = u_lambda(top, CRD, BOX, 9.0, lam, mode, **refkw)
        assert out["vdwaals"] == pytest.approx(want, abs=MDOUT_PRECISION), (
            f"ifsc_v={mode} lam={lam}: pmemd {out['vdwaals']} vs reference {want}")


@pytest.mark.parametrize("extra,mode,refkw", MODES)
def test_reported_dvdl_matches_the_reference(
        tmp_path, systems, top, extra, mode, refkw):
    """The decisive check on dV/dlambda.

    Mode 3's derivative is assembled by hand in the pair kernel from an outer
    (1-lambda)^2 term and a radial-shift term; mode 1's carries explicit
    k*lambda^(k-1) factors.  Neither had ever been verified.
    """
    info = systems["s06_alch"]
    for lam in LAMBDAS:
        out = _run(tmp_path, info, lam, f"d{mode}{str(lam)[2:]}", extra)
        assert "dvdl" in out, f"pmemd reported no DV/DL for ifsc_v={mode}"
        want = dudl_numeric(top, CRD, BOX, 9.0, lam, mode, h=1e-6, **refkw)
        assert out["dvdl"] == pytest.approx(want, abs=MDOUT_PRECISION), (
            f"ifsc_v={mode} lam={lam}: pmemd {out['dvdl']} vs reference {want}")


@pytest.mark.parametrize("extra,mode,refkw", MODES)
def test_reported_dvdl_is_self_consistent_with_pmemds_own_energies(
        tmp_path, systems, extra, mode, refkw):
    """pmemd's analytic dV/dlambda against a finite difference of pmemd's own
    EPtot.  Independent of the reference entirely."""
    info = systems["s06_alch"]
    for lam in LAMBDAS:
        tag = f"{mode}{str(lam)[2:]}"
        eu = _run(tmp_path, info, lam + HL, f"fu{tag}", extra)["eptot"]
        ed = _run(tmp_path, info, lam - HL, f"fd{tag}", extra)["eptot"]
        mid = _run(tmp_path, info, lam, f"fm{tag}", extra)
        numeric = (eu - ed) / (2 * HL)
        assert mid["dvdl"] == pytest.approx(numeric, abs=FD_TOL), (
            f"ifsc_v={mode} lam={lam}: reported {mid['dvdl']} vs FD {numeric}")


@pytest.mark.parametrize("extra,mode,refkw", MODES)
def test_lambda_zero_reproduces_the_nonalchemical_energy(
        tmp_path, systems, extra, mode, refkw):
    """Endpoint exactness: at lam=0 the disappearing region is fully coupled,
    so EPtot must equal a plain non-alchemical DEGAUSS single point.

    This is what the path-independence result rests on -- if any mode fails
    here its lambda=0 state is not the physical state, and its free energy is
    measured from the wrong reference.
    """
    info = systems["s06_alch"]
    alch = _run(tmp_path, info, 0.0, f"z{mode}", extra)
    mdin = str(tmp_path / "mdin_plain")
    write_mdin(mdin, **BASE)
    plain = run_pmemd(str(tmp_path / "plain"), info["prmtop"], info["inpcrd"], mdin)
    assert alch["eptot"] == pytest.approx(plain["eptot"], abs=MDOUT_PRECISION)


@pytest.mark.parametrize("extra,mode,refkw", MODES)
def test_lambda_one_fully_decouples(tmp_path, systems, extra, mode, refkw):
    """At lam=1 the interaction must be gone for every mode, so the decoupled
    endpoint really is shared across paths."""
    info = systems["s06_alch"]
    out = _run(tmp_path, info, 1.0, f"o{mode}", extra)
    assert out["vdwaals"] == pytest.approx(0.0, abs=MDOUT_PRECISION)


def test_direct_mode_matches_the_closed_form_exactly(tmp_path, systems, top):
    """Mode 0 is exactly (1-lambda)*V with dV/dlambda = -V, so it can be
    checked with no differencing at all."""
    from degauss_ref.nonbonded import direct_space
    info = systems["s06_alch"]
    v = direct_space(top, CRD, BOX, cutoff=9.0, do_elec=False)["evdw"]
    for lam in (0.0, 0.25, 0.4, 0.75, 1.0):
        out = _run(tmp_path, info, lam, f"cf{str(lam)[2:]}", dict(ifsc_v=0))
        assert out["vdwaals"] == pytest.approx((1.0 - lam) * v, abs=MDOUT_PRECISION)
        assert out["dvdl"] == pytest.approx(-v, abs=MDOUT_PRECISION)
