import numpy as np
import pytest
from degauss_ref.functions import de_energy, de_dedr, de_coefficients
from degauss_ref.nonbonded import minimum_image, direct_space


class FakeTop:
    """Two atoms, one type, zero charge -- the simplest possible DEGAUSS system."""

    def __init__(self, natom=2):
        self.natom = natom
        self.ntypes = 1
        self.nttyp = 1
        self.iac = np.zeros(natom, dtype=int)
        self.ico = np.array([1])
        self.charge = np.zeros(natom)
        self.widths = np.full(natom, 0.2)
        self.gbeta = 2.0 * self.widths**2
        self.effective_radius = np.sqrt(self.gbeta)
        self.alpha = np.array([18.17])
        self.beta = np.array([3.65])
        self.eps = np.array([0.1521])
        self.rmin = np.array([3.8])
        cn1, cn2 = de_coefficients(self.eps[0], self.rmin[0],
                                   self.alpha[0], self.beta[0])
        self.cn1 = np.array([cn1])
        self.cn2 = np.array([cn2])
        self.excluded = [set() for _ in range(natom)]
        self.pairs14 = []

    def type_index(self, i, j):
        return 0

    def gamma_ij(self, i, j):
        return 1.0 / np.sqrt(self.gbeta[i] + self.gbeta[j])


def test_minimum_image_wraps_each_axis_independently():
    box = np.array([10.0, 20.0, 30.0])
    d = np.array([6.0, -11.0, 14.0])
    assert minimum_image(d, box) == pytest.approx(np.array([-4.0, 9.0, 14.0]))


def test_single_pair_energy_equals_the_closed_form():
    top = FakeTop()
    box = np.array([50.0, 50.0, 50.0])
    r = 4.2
    crd = np.array([[0.0, 0.0, 0.0], [r, 0.0, 0.0]])
    out = direct_space(top, crd, box, cutoff=9.0, do_elec=False)
    expect = de_energy(r, top.eps[0], top.rmin[0], top.alpha[0], top.beta[0])
    assert out["evdw"] == pytest.approx(expect, rel=1e-13)
    assert len(out["pairs"]) == 1


def test_single_pair_force_equals_minus_gradient():
    top = FakeTop()
    box = np.array([50.0, 50.0, 50.0])
    r = 4.2
    crd = np.array([[0.0, 0.0, 0.0], [r, 0.0, 0.0]])
    out = direct_space(top, crd, box, cutoff=9.0, do_elec=False)
    dedr = de_dedr(r, top.eps[0], top.rmin[0], top.alpha[0], top.beta[0])
    # Atom 1 sits at +x from atom 0, so F_1 = -dV/dr * xhat.
    assert out["forces"][1, 0] == pytest.approx(-dedr, rel=1e-12)
    assert out["forces"][0, 0] == pytest.approx(+dedr, rel=1e-12)
    assert out["forces"].sum(axis=0) == pytest.approx(np.zeros(3), abs=1e-12)


def test_pair_beyond_cutoff_contributes_nothing():
    top = FakeTop()
    box = np.array([50.0, 50.0, 50.0])
    crd = np.array([[0.0, 0.0, 0.0], [12.0, 0.0, 0.0]])
    out = direct_space(top, crd, box, cutoff=9.0, do_elec=False)
    assert out["evdw"] == 0.0
    assert out["pairs"] == []


def test_excluded_pair_contributes_no_vdw():
    top = FakeTop()
    top.excluded = [{1}, {0}]
    box = np.array([50.0, 50.0, 50.0])
    crd = np.array([[0.0, 0.0, 0.0], [4.2, 0.0, 0.0]])
    out = direct_space(top, crd, box, cutoff=9.0, do_elec=False)
    assert out["evdw"] == 0.0


def test_forces_are_consistent_with_energy_under_displacement():
    # Numerical gradient of the total energy must equal -F for a random
    # 6-atom configuration.  h=1e-5 gives ~1e-8 relative truncation error;
    # the absolute gate 1e-5 covers cancellation round-off on ~1e2 kcal/mol.
    rng = np.random.default_rng(20260819)
    top = FakeTop(natom=6)
    box = np.array([30.0, 30.0, 30.0])
    crd = rng.uniform(0.0, 8.0, size=(6, 3))
    out = direct_space(top, crd, box, cutoff=9.0, do_elec=False)
    h = 1e-5
    for a in range(6):
        for c in range(3):
            up, dn = crd.copy(), crd.copy()
            up[a, c] += h
            dn[a, c] -= h
            eu = direct_space(top, up, box, cutoff=9.0, do_elec=False)["evdw"]
            ed = direct_space(top, dn, box, cutoff=9.0, do_elec=False)["evdw"]
            assert out["forces"][a, c] == pytest.approx(
                -(eu - ed) / (2 * h), rel=1e-6, abs=1e-5)


def test_electrostatic_pair_energy_uses_the_gaussian_form():
    top = FakeTop()
    top.charge = np.array([1.0, -1.0]) * 18.2223
    box = np.array([50.0, 50.0, 50.0])
    r = 4.2
    crd = np.array([[0.0, 0.0, 0.0], [r, 0.0, 0.0]])
    out = direct_space(top, crd, box, cutoff=9.0, do_elec=True, do_vdw=False)
    from scipy.special import erf
    g = top.gamma_ij(0, 1)
    expect = -(18.2223**2) * erf(g * r) / r
    assert out["eelec"] == pytest.approx(expect, rel=1e-13)
