import numpy as np
import pytest
from degauss_ref.functions import (
    de_energy, de_dedr, de_coefficients, gauss_energy, gauss_dedr,
)

EPS, RMIN, ALPHA, BETA = 0.1521, 3.8, 18.17, 3.65


def test_de_well_depth_is_exactly_minus_eps():
    # V(r_m) = eps/(a-b) * (b - a) = -eps, exactly, for any alpha != beta.
    # Tolerance: double-precision round-off through ~6 flops.
    assert de_energy(RMIN, EPS, RMIN, ALPHA, BETA) == pytest.approx(-EPS, rel=1e-14)


def test_de_minimum_is_located_at_rmin():
    # dV/dr = 0 only where exp(alpha*A) == exp(beta*A), i.e. A=0, i.e. r=r_m.
    assert de_dedr(RMIN, EPS, RMIN, ALPHA, BETA) == pytest.approx(0.0, abs=1e-12)


def test_de_zero_separation_is_finite_and_matches_closed_form():
    # V(0) = eps/(a-b) * (b*e^a - a*e^b)
    expect = EPS / (ALPHA - BETA) * (BETA * np.exp(ALPHA) - ALPHA * np.exp(BETA))
    assert de_energy(0.0, EPS, RMIN, ALPHA, BETA) == pytest.approx(expect, rel=1e-13)
    assert np.isfinite(de_energy(0.0, EPS, RMIN, ALPHA, BETA))


def test_de_coefficients_match_prmtop_conversion_formula():
    # pmemd stores cn1 = eps*beta*exp(alpha)/(alpha-beta),
    #              cn2 = eps*alpha*exp(beta)/(alpha-beta)
    A, C = de_coefficients(EPS, RMIN, ALPHA, BETA)
    assert A == pytest.approx(EPS * BETA * np.exp(ALPHA) / (ALPHA - BETA), rel=1e-13)
    assert C == pytest.approx(EPS * ALPHA * np.exp(BETA) / (ALPHA - BETA), rel=1e-13)


def test_de_analytic_derivative_matches_central_difference():
    # Central difference truncation error is O(h^2 * V'''); h=1e-5 on a smooth
    # exponential gives ~1e-8 relative, so 1e-6 is a safe relative gate.
    #
    # An absolute floor is also required: at r = RMIN the true derivative is
    # exactly zero, so the difference quotient there is pure cancellation
    # round-off.  Its scale is ~eps_machine*|V|/h amplified by the exponential
    # argument alpha*a, which is ~1e-10 here; 1e-9 is a safe floor.
    h = 1e-5
    for r in (1.0, 2.5, 3.8, 5.0, 8.0):
        num = (de_energy(r + h, EPS, RMIN, ALPHA, BETA)
               - de_energy(r - h, EPS, RMIN, ALPHA, BETA)) / (2 * h)
        assert de_dedr(r, EPS, RMIN, ALPHA, BETA) == pytest.approx(
            num, rel=1e-6, abs=1e-9)


def test_gauss_zero_separation_limit():
    # erf(g r)/r -> 2g/sqrt(pi) as r->0
    g, qq = 2.5, 1.0
    expect = 2.0 * g / np.sqrt(np.pi)
    assert gauss_energy(1e-9, qq, g) == pytest.approx(expect, rel=1e-6)


def test_gauss_analytic_derivative_matches_central_difference():
    h, g, qq = 1e-5, 2.5, 3.7
    for r in (0.5, 1.0, 3.0, 6.0):
        num = (gauss_energy(r + h, qq, g) - gauss_energy(r - h, qq, g)) / (2 * h)
        assert gauss_dedr(r, qq, g) == pytest.approx(num, rel=1e-6)
