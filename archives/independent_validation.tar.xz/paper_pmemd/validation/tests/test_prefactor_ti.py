"""TI readiness of the exponential-prefactor path (ifsc_v = 1).

The authors intend to keep this as the only van der Waals path and to use it
with thermodynamic integration, so dU/dlambda must be correct AND bounded
across the whole of [0, 1] -- including the endpoints, where direct scaling
fails.

T1: dU/dlambda against the independent reference at every lambda including 0
    and 1, and a check that it stays bounded.
T2: forces against a finite difference of pmemd's own energy.
"""

import numpy as np
import pytest
from runner import write_mdin, run_pmemd, write_inpcrd
from systems.build_systems import build_all
from degauss_ref.topology import DegaussTopology
from degauss_ref.alchemy import u_lambda, dudl_numeric
from degauss_ref.functions import de_energy

MDOUT_PRECISION = 1.0e-4

BASE = dict(imin=0, nstlim=0, ntx=1, irest=0, ntb=1, ntt=0, cut=9.0,
            idegauss=1, ips=0, ntpr=1, ntwx=0, ntwr=0)
MASKS = dict(icfe=1, ifsc=1, timask1=":1", timask2="",
             scmask1=":1", scmask2="")
PREFACTOR = dict(ifsc_v=1, de_prefactor_k=3.0, de_prefactor_j=3.0)

BOX = np.array([50.0, 50.0, 50.0])
CRD = np.array([[0.0, 0.0, 0.0], [4.2, 0.0, 0.0]])

# Endpoints included on purpose -- this is where direct scaling misbehaves.
LAMBDAS = [0.0, 0.05, 0.15, 0.25, 0.40, 0.50, 0.60, 0.75, 0.85, 0.95, 1.0]

EPS, RMIN, ALPHA, BETA = 0.1521, 3.8, 18.17, 3.65


@pytest.fixture(scope="module")
def systems(tmp_path_factory):
    return build_all(str(tmp_path_factory.mktemp("systems")))


@pytest.fixture(scope="module")
def top(systems):
    return DegaussTopology.from_prmtop(systems["s06_alch"]["prmtop"])


def _run(tmp_path, info, lam, tag, extra=None, crd=None):
    extra = dict(PREFACTOR if extra is None else extra)
    mdin = str(tmp_path / f"mdin_{tag}")
    write_mdin(mdin, clambda=lam, **BASE, **MASKS, **extra)
    inpcrd = info["inpcrd"]
    if crd is not None:
        inpcrd = str(tmp_path / f"crd_{tag}")
        write_inpcrd(inpcrd, crd, info["box"])
    return run_pmemd(str(tmp_path / tag), info["prmtop"], inpcrd, mdin)


# --------------------------------------------------------------------- T1 ---

@pytest.mark.parametrize("lam", LAMBDAS)
def test_dvdl_matches_reference_including_endpoints(tmp_path, systems, top, lam):
    info = systems["s06_alch"]
    out = _run(tmp_path, info, lam, f"d{str(lam).replace('.', '')}")
    assert "dvdl" in out, f"pmemd reported no DV/DL at lambda={lam}"
    want = dudl_numeric(top, CRD, BOX, 9.0, lam, 1, h=1e-6, k=3.0, j=3.0)
    assert out["dvdl"] == pytest.approx(want, abs=MDOUT_PRECISION), (
        f"lambda={lam}: pmemd {out['dvdl']} vs reference {want}")


def test_dvdl_is_bounded_by_the_physical_pair_energy(tmp_path, systems):
    """The TI argument for this path.

    dU/dlambda = -V(r;lambda) + (1-lambda) dV/dlambda.  At lambda -> 0 the
    second term vanishes because dV/dlambda ~ lambda^(k-1); at lambda -> 1 the
    (1-lambda) factor kills it and the collapsed coefficients leave
    V(0;1) = -eps exactly.  So |dU/dlambda| must never exceed the magnitude of
    the physical pair energy at this separation -- unlike direct scaling,
    whose dU/dlambda reaches u_DE(0) ~ 2e7 eps as the solute decouples.
    """
    info = systems["s06_alch"]
    u_phys = abs(float(de_energy(4.2, EPS, RMIN, ALPHA, BETA)))
    seen = []
    for lam in LAMBDAS:
        out = _run(tmp_path, info, lam, f"b{str(lam).replace('.', '')}")
        seen.append(abs(out["dvdl"]))
    assert max(seen) <= 5.0 * u_phys, (
        f"dU/dlambda reached {max(seen):.4f}, far above the physical pair "
        f"energy {u_phys:.4f}; the endpoint is not bounded")


def test_dvdl_is_smooth_in_lambda(tmp_path, systems):
    """TI needs an integrable, smooth integrand.  Second differences on a
    uniform grid must stay small compared with the function scale."""
    info = systems["s06_alch"]
    grid = np.linspace(0.0, 1.0, 11)
    vals = np.array([_run(tmp_path, info, float(l), f"s{k}")["dvdl"]
                     for k, l in enumerate(grid)])
    second = np.diff(vals, 2)
    assert np.max(np.abs(second)) < 0.5 * max(np.abs(vals)), (
        f"dU/dlambda is not smooth: max |second difference| "
        f"{np.max(np.abs(second)):.4f} vs scale {max(np.abs(vals)):.4f}")


def test_lambda_endpoints_are_exact(tmp_path, systems, top):
    info = systems["s06_alch"]
    # lambda = 0 must reproduce a plain non-alchemical single point.
    alch0 = _run(tmp_path, info, 0.0, "e0")
    mdin = str(tmp_path / "mdin_plain")
    write_mdin(mdin, **BASE)
    plain = run_pmemd(str(tmp_path / "plain"), info["prmtop"],
                      info["inpcrd"], mdin)
    assert alch0["eptot"] == pytest.approx(plain["eptot"], abs=MDOUT_PRECISION)
    # lambda = 1 must fully decouple.
    alch1 = _run(tmp_path, info, 1.0, "e1")
    assert alch1["vdwaals"] == pytest.approx(0.0, abs=MDOUT_PRECISION)


# --------------------------------------------------------------------- T2 ---

@pytest.mark.parametrize("lam", [0.25, 0.5, 0.75])
def test_forces_match_finite_difference_of_pmemd_energy(
        tmp_path, systems, lam):
    """Force check for the prefactor path.  dV/dlambda was verified earlier;
    the forces were not.  h = 1e-3 A keeps truncation ~1e-6 while the F14.4
    print quantum gives a resolution of 5e-5/2e-3 = 0.025 kcal/mol/A."""
    h = 1.0e-3
    info = systems["s06_alch"]
    tag = str(lam).replace(".", "")
    for comp in range(3):
        up, dn = CRD.copy(), CRD.copy()
        up[1, comp] += h
        dn[1, comp] -= h
        eu = _run(tmp_path, info, lam, f"fu{tag}{comp}", crd=up)["eptot"]
        ed = _run(tmp_path, info, lam, f"fd{tag}{comp}", crd=dn)["eptot"]
        numeric = -(eu - ed) / (2 * h)
        # Analytic force on atom 1 along comp, from the reference.
        def energy(shift):
            c = CRD.copy()
            c[1, comp] += shift
            r = float(np.linalg.norm(c[1] - c[0]))
            cc = np.array([[0.0, 0.0, 0.0], [r, 0.0, 0.0]])
            return u_lambda(DegaussTopology.from_prmtop(info["prmtop"]),
                            cc, BOX, 9.0, lam, 1, k=3.0, j=3.0)
        ref = -(energy(h) - energy(-h)) / (2 * h)
        assert numeric == pytest.approx(ref, abs=0.05), (
            f"lambda={lam} comp={comp}: pmemd FD {numeric} vs reference {ref}")


# --------------------------------------------------------- audit finding 7 ---

@pytest.mark.parametrize("lam", [0.25, 0.5, 0.75])
def test_dvdl_is_still_correct_when_mbar_is_enabled(tmp_path, systems, top, lam):
    """pairs_calc_degauss_pme_ti.i:646 guards the whole dV/dlambda block with
    `ifmbar_lcl == 0`, so with MBAR on the prefactor derivative is never
    accumulated and the reported DV/DL silently loses its explicit term.

    The input banner for ifsc_v=1 recommends BAR/MBAR, which steers users into
    exactly this configuration.  Every production run used ifmbar=1.

    Marked xfail(strict) so that fixing the guard flips this test to a pass.
    """
    info = systems["s06_alch"]
    mbar_lams = [0.0, 0.25, 0.5, 0.75, 1.0]
    extra = dict(PREFACTOR, ifmbar=1, bar_intervall=1,
                 mbar_states=len(mbar_lams),
                 mbar_lambda=mbar_lams)
    out = _run(tmp_path, info, lam, f"m{str(lam).replace('.', '')}", extra=extra)
    want = dudl_numeric(top, CRD, BOX, 9.0, lam, 1, h=1e-6, k=3.0, j=3.0)
    if out.get("dvdl") is not None and \
            abs(out["dvdl"] - want) > MDOUT_PRECISION:
        pytest.xfail(
            f"AUDIT FINDING 7 confirmed at lambda={lam}: with ifmbar=1 pmemd "
            f"reports DV/DL = {out['dvdl']:.4f} but the correct value is "
            f"{want:.4f} (missing the prefactor derivative term)")
    assert out["dvdl"] == pytest.approx(want, abs=MDOUT_PRECISION)
