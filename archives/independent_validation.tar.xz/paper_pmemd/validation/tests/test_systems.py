import os
import numpy as np
import pytest
from systems.build_systems import build_all
from degauss_ref.topology import DegaussTopology

EXPECTED = {"s01_onepair": 2, "s02_twopair": 3, "s03_excl": 2,
            "s04_14": 4, "s05_wat8": 24, "s06_alch": 2}


@pytest.fixture(scope="module")
def systems(tmp_path_factory):
    return build_all(str(tmp_path_factory.mktemp("systems")))


def test_every_system_is_written(systems):
    assert set(systems) == set(EXPECTED)
    for name, info in systems.items():
        assert os.path.exists(info["prmtop"]), name
        assert os.path.exists(info["inpcrd"]), name


def test_atom_counts_match_the_ladder(systems):
    for name, n in EXPECTED.items():
        assert systems[name]["natom"] == n


def test_generated_prmtops_parse_with_our_own_reader(systems):
    for name, info in systems.items():
        top = DegaussTopology.from_prmtop(info["prmtop"])
        assert top.natom == EXPECTED[name], name
        assert top.nttyp == top.ntypes * (top.ntypes + 1) // 2, name


def test_lj_coefficients_round_trip_to_the_intended_de_parameters(systems):
    # Type 0 is eps=0.1521, rmin_half=1.9, so the 0-0 pair must come back as
    # eps=0.1521, rmin=3.8 through pmemd's LJ->DE fallback formulas.
    #
    # Tolerance is set by the AMBER prmtop format, not by double precision:
    # %16.8E stores ~9 significant digits, and eps = B^2/(4A) amplifies that
    # to ~3e-9 relative.  rmin = (2A/B)^(1/6) takes a sixth root and is
    # correspondingly tighter.  This 1e-8 floor caps every downstream
    # comparison of DEGAUSS energies against an external reference.
    top = DegaussTopology.from_prmtop(systems["s01_onepair"]["prmtop"])
    k = top.type_index(0, 1)
    assert top.eps[k] == pytest.approx(0.1521, rel=1e-8)
    assert top.rmin[k] == pytest.approx(3.8, rel=1e-9)


def test_one_pair_system_has_no_exclusions_and_zero_charge(systems):
    top = DegaussTopology.from_prmtop(systems["s01_onepair"]["prmtop"])
    assert all(len(s) == 0 for s in top.excluded)
    assert abs(top.charge).max() == 0.0


def test_excluded_system_has_the_pair_excluded(systems):
    top = DegaussTopology.from_prmtop(systems["s03_excl"]["prmtop"])
    assert 1 in top.excluded[0] and 0 in top.excluded[1]


def test_two_type_system_resolves_distinct_type_pairs(systems):
    top = DegaussTopology.from_prmtop(systems["s02_twopair"]["prmtop"])
    assert top.ntypes == 2
    # atoms 0(type0)-1(type1) is a mixed pair; 1-2 is type1-type1.
    assert top.type_index(0, 1) != top.type_index(1, 2)


def test_14_system_yields_exactly_one_14_pair(systems):
    top = DegaussTopology.from_prmtop(systems["s04_14"]["prmtop"])
    assert len(top.pairs14) == 1
    i, j, scee, scnb = top.pairs14[0]
    assert {i, j} == {0, 3}
    assert scee == pytest.approx(1.2)
    assert scnb == pytest.approx(2.0)


def test_water_system_carries_tip3p_charges_and_water_exclusions(systems):
    top = DegaussTopology.from_prmtop(systems["s05_wat8"]["prmtop"])
    assert top.natom == 24
    assert top.charge[0] / 18.2223 == pytest.approx(-0.834, rel=1e-6)
    assert top.charge[1] / 18.2223 == pytest.approx(0.417, rel=1e-6)
    # Intramolecular pairs excluded, intermolecular not.
    assert 1 in top.excluded[0] and 2 in top.excluded[0]
    assert 3 not in top.excluded[0]


def test_coordinates_round_trip_through_the_inpcrd(systems):
    info = systems["s01_onepair"]
    crd = np.loadtxt(info["inpcrd"], skiprows=2, max_rows=1)
    assert crd[:3] == pytest.approx([0.0, 0.0, 0.0], abs=1e-7)
    assert crd[3:6] == pytest.approx([4.2, 0.0, 0.0], abs=1e-7)
