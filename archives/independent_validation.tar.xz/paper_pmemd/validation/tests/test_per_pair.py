import os
import numpy as np
import pytest
from runner import write_mdin, run_pmemd
from systems.build_systems import build_all
from degauss_ref.topology import DegaussTopology
from degauss_ref.nonbonded import direct_space
import pairdump

# The dump writes E24.16, so the comparison is limited by how accurately the
# DE parameters survive the prmtop, not by the printed digits.  AMBER's
# %16.8E carries ~9 significant figures and eps = B^2/(4A) amplifies that to
# ~3e-9 relative (see tests/test_systems.py), so 1e-7 is the tight-but-safe
# gate on a per-pair energy.
PAIR_TOL = 1.0e-7
# Distances are pure geometry from the inpcrd (%12.7f).
DIST_TOL = 1.0e-6


@pytest.fixture(scope="module")
def systems(tmp_path_factory):
    return build_all(str(tmp_path_factory.mktemp("systems")))


def _coords(info):
    top = DegaussTopology.from_prmtop(info["prmtop"])
    flat = []
    with open(info["inpcrd"]) as fh:
        fh.readline()
        fh.readline()
        for line in fh:
            flat.extend(float(line[k:k + 12])
                        for k in range(0, len(line.rstrip()), 12))
    return top, np.array(flat[:3 * top.natom]).reshape(-1, 3)


def _run_with_dump(tmp_path, info, tag, **extra):
    """Run a single point with the per-pair dump on.

    Returns (mdout dict, dump array).  The dump array is empty when pmemd
    evaluated no DE pairs at all, in which case Fortran never creates the unit.
    """
    mdin = str(tmp_path / f"mdin_{tag}")
    write_mdin(mdin, imin=0, nstlim=0, ntx=1, irest=0, ntb=1, ntt=0, cut=9.0,
               idegauss=1, ips=0, ntpr=1, ntwx=0, ntwr=0,
               degauss_pairdump=1, **extra)
    out = run_pmemd(str(tmp_path / tag), info["prmtop"], info["inpcrd"], mdin)
    dpath = os.path.join(str(tmp_path / tag), "fort.771")
    if not os.path.exists(dpath):
        return out, np.empty(0, dtype=pairdump.DTYPE)
    return out, pairdump.read(dpath)


def _sorted_pairs(records):
    """(r, e) sorted by distance, for multiplicity-correct comparison.

    The dump carries IMAGE indices, which are not the reference's original
    atom numbers, so pairs are matched on geometry instead of identity.
    """
    return sorted(((float(r), float(e)) for r, e in records),
                  key=lambda t: (t[0], t[1]))


@pytest.mark.parametrize("name", ["s01_onepair", "s02_twopair", "s05_wat8"])
def test_every_reference_pair_appears_with_the_same_distance_and_energy(
        tmp_path, systems, name):
    info = systems[name]
    _out, dump = _run_with_dump(tmp_path, info, name)
    top, crd = _coords(info)
    ref = direct_space(top, crd, np.array(info["box"]), cutoff=9.0, do_elec=False)

    got = _sorted_pairs(zip(dump["r"], dump["evdw"]))
    want = _sorted_pairs((r, e_v) for (_i, _j, r, e_v, _e_e) in ref["pairs"])

    assert len(got) == len(want), (
        f"{name}: pmemd evaluated {len(got)} DE pairs, reference {len(want)}")
    for (r_pm, e_pm), (r_rf, e_rf) in zip(got, want):
        assert r_pm == pytest.approx(r_rf, abs=DIST_TOL), f"{name}: distance"
        assert e_pm == pytest.approx(e_rf, rel=PAIR_TOL, abs=1e-12), \
            f"{name}: energy at r={r_rf}"


def test_excluded_pair_never_reaches_the_de_kernel(tmp_path, systems):
    _out, dump = _run_with_dump(tmp_path, systems["s03_excl"], "s03")
    assert len(dump) == 0, "an excluded pair was evaluated by the DE kernel"


def test_dumped_pair_energies_sum_to_the_reported_total(tmp_path, systems):
    info = systems["s05_wat8"]
    out, dump = _run_with_dump(tmp_path, info, "sum")
    # VDWAALS additionally carries pmemd's continuum tail correction, which
    # the pair sum does not include; for this dilute box the tail is small.
    assert dump["evdw"].sum() == pytest.approx(out["vdwaals"], abs=0.05)


def test_per_pair_energies_reproduce_the_de_closed_form(tmp_path, systems):
    """The strongest form of the check: every dumped pair must satisfy the
    analytic DE expression using the alpha and beta pmemd itself reported."""
    from degauss_ref.functions import de_energy
    info = systems["s05_wat8"]
    _out, dump = _run_with_dump(tmp_path, info, "form")
    top, _crd = _coords(info)
    # Every dumped pair in this system is the O-O type pair.
    k = top.type_index(0, 3)
    for rec in dump:
        expect = de_energy(rec["r"], top.eps[k], top.rmin[k],
                           rec["alpha"], rec["beta"])
        assert rec["evdw"] == pytest.approx(expect, rel=PAIR_TOL, abs=1e-12)
