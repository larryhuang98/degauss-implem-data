import numpy as np
import pytest
from degauss_ref.alchemy import (
    schedule_f, de_params_at_lambda, u_lambda, dudl_numeric, u_matrix,
)
from tests.test_nonbonded import FakeTop

SCHEDULES = [(1, 1.0), (2, 2.0), (3, 2.0), (4, 2.0), (5, 1.0)]
# User-facing ifsc_v values.  The reference never uses the legacy
# ifsc_degauss numbering, in which 1 and 2 are swapped.
MODES = [0, 1, 2, 3, 4]


@pytest.mark.parametrize("sched,c", SCHEDULES)
def test_every_schedule_is_exactly_one_at_lambda_one(sched, c):
    # Endpoint exactness: region 1 reads f(1-lam), so alpha(lam=0) equals
    # alpha_phys only if f(1) == 1 exactly, for every schedule variant.
    f, _ = schedule_f(1.0, sched, c)
    assert f == pytest.approx(1.0, rel=1e-13)


@pytest.mark.parametrize("sched,c", SCHEDULES)
def test_every_schedule_is_exactly_zero_at_lambda_zero(sched, c):
    f, _ = schedule_f(0.0, sched, c)
    assert f == pytest.approx(0.0, abs=1e-13)


@pytest.mark.parametrize("sched,c", SCHEDULES)
def test_schedule_derivative_matches_central_difference(sched, c):
    h = 1e-6
    for lam in (0.15, 0.5, 0.85):
        fu, _ = schedule_f(lam + h, sched, c)
        fd, _ = schedule_f(lam - h, sched, c)
        _, fp = schedule_f(lam, sched, c)
        assert fp == pytest.approx((fu - fd) / (2 * h), rel=1e-5)


@pytest.mark.parametrize("mode", MODES)
def test_lambda_zero_reproduces_the_physical_parameters(mode):
    # Region 1 at lam=0 is the fully coupled physical state for every mode.
    top = FakeTop()
    p = de_params_at_lambda(top, 0.0, mode, region=1)
    assert p["alpha"] == pytest.approx(top.alpha, rel=1e-13)
    assert p["beta"] == pytest.approx(top.beta, rel=1e-13)
    assert p["cn1"] == pytest.approx(top.cn1, rel=1e-13)
    assert p["cn2"] == pytest.approx(top.cn2, rel=1e-13)
    assert p["sc_shift"] == pytest.approx(np.zeros_like(p["sc_shift"]), abs=1e-13)


@pytest.mark.parametrize("mode", MODES)
def test_lambda_zero_energy_equals_the_unmodified_de_energy(mode):
    from degauss_ref.functions import de_energy
    top = FakeTop()
    box = np.array([50.0, 50.0, 50.0])
    r = 4.2
    crd = np.array([[0.0, 0.0, 0.0], [r, 0.0, 0.0]])
    got = u_lambda(top, crd, box, 9.0, 0.0, mode, weight=False)
    expect = float(de_energy(r, top.eps[0], top.rmin[0], top.alpha[0], top.beta[0]))
    assert got == pytest.approx(expect, rel=1e-12)


def test_prefactor_mode_moves_the_minimum_inward():
    # Mode 1 sets the argument to 1 - r/rm - lam^k, so the minimum sits at
    # r = rm*(1-lam^k) with depth still exactly -eps.  This is the analytic
    # claim behind the mode-1 critique; assert it against the reference's own
    # lambda-dependent parameters rather than a hand-written formula.
    top = FakeTop()
    lam, k = 0.75, 3.0
    p = de_params_at_lambda(top, lam, 1, k=k, j=k, region=1)
    rm = top.rmin[0]
    r_expect = rm * (1.0 - lam**k)
    grid = np.linspace(0.3 * rm, 1.2 * rm, 400001)
    v = (p["cn1"][0] * np.exp(-p["alpha"][0] * grid / rm)
         - p["cn2"][0] * np.exp(-p["beta"][0] * grid / rm))
    assert grid[np.argmin(v)] == pytest.approx(r_expect, rel=1e-4)
    assert v.min() == pytest.approx(-top.eps[0], rel=1e-6)


def test_steepness_mode_lowers_the_contact_energy():
    # Mode 2 reduces alpha towards alpha_min, cutting V(0) by orders of
    # magnitude.  Verified as a monotone decrease, not a specific value.
    top = FakeTop()
    v0 = []
    for lam in (0.0, 0.5, 0.9):
        p = de_params_at_lambda(top, lam, 2, alpha_min=5.0, beta_min=4.0,
                                schedule=2, region=1)
        v0.append(p["cn1"][0] - p["cn2"][0])
    assert v0[0] > v0[1] > v0[2] > 0.0


def test_softcore_mode_shift_grows_with_lambda_and_vanishes_at_zero():
    top = FakeTop()
    prev = -1.0
    for lam in (0.0, 0.25, 0.5, 1.0):
        p = de_params_at_lambda(top, lam, 3, sc_alpha=0.5, region=1)
        s = float(p["sc_shift"][0])
        assert s >= prev
        prev = s
    assert de_params_at_lambda(top, 0.0, 3, region=1)["sc_shift"][0] == 0.0
    expect = 0.5 * 1.0 * top.rmin[0] ** 2
    assert de_params_at_lambda(top, 1.0, 3, region=1)["sc_shift"][0] == \
        pytest.approx(expect, rel=1e-13)


@pytest.mark.parametrize("mode", [0, 1, 2, 3])
def test_dudl_is_finite_and_matches_a_coarser_difference(mode):
    top = FakeTop()
    box = np.array([50.0, 50.0, 50.0])
    crd = np.array([[0.0, 0.0, 0.0], [4.2, 0.0, 0.0]])
    for lam in (0.25, 0.5, 0.75):
        fine = dudl_numeric(top, crd, box, 9.0, lam, mode, h=1e-6)
        coarse = dudl_numeric(top, crd, box, 9.0, lam, mode, h=1e-4)
        assert np.isfinite(fine)
        # Two step sizes two orders apart must agree if the function is smooth.
        assert fine == pytest.approx(coarse, rel=1e-4, abs=1e-8)


def test_u_matrix_diagonal_equals_u_lambda():
    top = FakeTop()
    box = np.array([50.0, 50.0, 50.0])
    crd = np.array([[0.0, 0.0, 0.0], [4.2, 0.0, 0.0]])
    lambdas = [0.0, 0.25, 0.5, 0.75, 1.0]
    row = u_matrix(top, crd, box, 9.0, lambdas, 0)
    for idx, lam in enumerate(lambdas):
        assert row[idx] == pytest.approx(
            u_lambda(top, crd, box, 9.0, lam, 0), rel=1e-13)


def test_full_decoupling_gives_zero_energy_at_lambda_one():
    # The outer (1-lam) weight must annihilate the interaction at lam=1
    # for every mode, so the decoupled endpoint is shared.
    top = FakeTop()
    box = np.array([50.0, 50.0, 50.0])
    crd = np.array([[0.0, 0.0, 0.0], [4.2, 0.0, 0.0]])
    for mode in MODES:
        assert u_lambda(top, crd, box, 9.0, 1.0, mode) == pytest.approx(0.0, abs=1e-12)
