import numpy as np
import pytest
from runner import write_mdin, run_pmemd
from systems.build_systems import build_all
from degauss_ref.topology import DegaussTopology
from degauss_ref.nonbonded import direct_space, nb14

# pmemd prints energies as F14.4, so the smallest resolvable difference is
# 5e-5 kcal/mol.  Nothing tighter than that can be asserted from mdout.
MDOUT_PRECISION = 1.0e-4


@pytest.fixture(scope="module")
def systems(tmp_path_factory):
    return build_all(str(tmp_path_factory.mktemp("systems")))


def _coords(info):
    top = DegaussTopology.from_prmtop(info["prmtop"])
    flat = []
    with open(info["inpcrd"]) as fh:
        fh.readline()
        fh.readline()
        for line in fh:
            flat.extend(float(line[k:k + 12]) for k in range(0, len(line.rstrip()), 12))
    return top, np.array(flat[:3 * top.natom]).reshape(-1, 3)


def _single_point(tmp_path, info, tag="sp", **extra):
    mdin = str(tmp_path / f"mdin_{tag}")
    write_mdin(mdin, imin=0, nstlim=0, ntx=1, irest=0, ntb=1, ntt=0,
               cut=9.0, idegauss=1, ips=0, ntpr=1, ntwx=0, ntwr=0, **extra)
    return run_pmemd(str(tmp_path / tag), info["prmtop"], info["inpcrd"], mdin)


def test_one_pair_vdw_matches_the_reference(tmp_path, systems):
    info = systems["s01_onepair"]
    out = _single_point(tmp_path, info, "s01")
    top, crd = _coords(info)
    ref = direct_space(top, crd, np.array(info["box"]), cutoff=9.0, do_elec=False)
    assert out["vdwaals"] == pytest.approx(ref["evdw"], abs=MDOUT_PRECISION)


def test_two_pair_vdw_matches_the_reference(tmp_path, systems):
    info = systems["s02_twopair"]
    out = _single_point(tmp_path, info, "s02")
    top, crd = _coords(info)
    ref = direct_space(top, crd, np.array(info["box"]), cutoff=9.0, do_elec=False)
    assert out["vdwaals"] == pytest.approx(ref["evdw"], abs=MDOUT_PRECISION)


def test_excluded_pair_yields_zero_vdw(tmp_path, systems):
    out = _single_point(tmp_path, systems["s03_excl"], "s03")
    assert out["vdwaals"] == pytest.approx(0.0, abs=MDOUT_PRECISION)


def test_14_pair_matches_the_reference(tmp_path, systems):
    info = systems["s04_14"]
    out = _single_point(tmp_path, info, "s04")
    top, crd = _coords(info)
    ref = nb14(top, crd, np.array(info["box"]))
    # All ordinary pairs are excluded in this system, so the whole vdW signal
    # must appear in the 1-4 channel.
    assert out["vdwaals"] == pytest.approx(0.0, abs=MDOUT_PRECISION)
    assert out["vdw14"] == pytest.approx(ref["evdw14"], abs=MDOUT_PRECISION)


def test_condensed_phase_vdw_matches_the_reference(tmp_path, systems):
    info = systems["s05_wat8"]
    out = _single_point(tmp_path, info, "s05")
    top, crd = _coords(info)
    ref = direct_space(top, crd, np.array(info["box"]), cutoff=9.0, do_elec=False)
    # VDWAALS also carries pmemd's continuum tail correction, which the
    # reference does not model; assert the pair sum dominates and agrees to
    # within a physically small tail for this dilute box.
    assert out["vdwaals"] == pytest.approx(ref["evdw"], abs=0.05)
