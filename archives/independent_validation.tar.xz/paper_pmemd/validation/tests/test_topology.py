import numpy as np
import pytest
from degauss_ref.topology import DegaussTopology

# 1786 atoms, 3 atom types, and NO DEGAUSS prmtop sections -- so this file
# exercises the LJ-fallback conversion path, which is the path every
# production run in the manuscript actually uses.
NA_PRMTOP = "/home8/larry/ambers/amber_merge_degauss_pmemd/test/cuda/gti/Na/prmtop"

# The value carried by every production mdin: `gbeta=0.2`.
PRODUCTION_WIDTH = 0.2


@pytest.fixture(scope="module")
def top():
    return DegaussTopology.from_prmtop(NA_PRMTOP, width=PRODUCTION_WIDTH)


def test_atom_and_type_counts_are_self_consistent(top):
    assert top.natom == 1786
    assert top.ntypes == 3
    assert top.nttyp == top.ntypes * (top.ntypes + 1) // 2
    assert top.iac.shape == (top.natom,)
    assert top.charge.shape == (top.natom,)


def test_type_index_uses_prmtop_ico_not_a_recomputed_formula(top):
    # Fix 7 in the pmemd history: never recompute AMBER's NONBONDED_PARM_INDEX.
    # ico is 1-based in the prmtop; type_index must return a valid 0-based slot.
    for i in range(min(20, top.natom)):
        for j in range(min(20, top.natom)):
            k = top.type_index(i, j)
            assert -1 <= k < top.nttyp
    assert top.type_index(0, 1) == top.type_index(1, 0)


def test_de_coefficients_match_the_documented_conversion(top):
    # cn1 = eps*beta*exp(alpha)/(alpha-beta); cn2 = eps*alpha*exp(beta)/(alpha-beta)
    mask = np.abs(top.alpha - top.beta) > 1e-10
    expect_cn1 = (top.eps[mask] * top.beta[mask] * np.exp(top.alpha[mask])
                  / (top.alpha[mask] - top.beta[mask]))
    assert top.cn1[mask] == pytest.approx(expect_cn1, rel=1e-12)


def test_lj_fallback_recovers_rmin_and_eps(top):
    # Where RMIN was absent, pmemd derives it from the LJ coefficients:
    #   rmin = (2*cn1_lj/cn2_lj)^(1/6),  eps = cn2_lj^2/(4*cn1_lj)
    # Round-tripping must return the original LJ A and B coefficients.
    for k in range(top.nttyp):
        if top.cn2_lj[k] <= 1.0e-10:
            continue
        assert top.rmin[k] > 0.0
        a_back = top.eps[k] * top.rmin[k] ** 12
        b_back = 2.0 * top.eps[k] * top.rmin[k] ** 6
        assert a_back == pytest.approx(top.cn1_lj[k], rel=1e-10)
        assert b_back == pytest.approx(top.cn2_lj[k], rel=1e-10)


def test_gaussian_width_and_effective_radius_differ_by_sqrt_two(top):
    # pmemd stores gbeta = 2*w^2 (w = the mdin `gbeta` input) and forms
    # gamma_ij = 1/sqrt(gbeta_i + gbeta_j).  Matching that against the SI's
    # 1/gamma_ij^2 = R_i^2 + R_j^2 forces gbeta_i == R_i^2, hence
    #     R_i = sqrt(2) * w.
    # With the production input w = 0.2 A, the EFFECTIVE radius is 0.2828 A.
    assert top.gbeta == pytest.approx(2.0 * PRODUCTION_WIDTH**2, rel=1e-13)
    assert top.gbeta[0] == pytest.approx(0.08, rel=1e-13)
    assert top.effective_radius[0] == pytest.approx(
        np.sqrt(2.0) * PRODUCTION_WIDTH, rel=1e-13)
    assert top.effective_radius[0] == pytest.approx(0.28284271, rel=1e-7)


def test_gamma_ij_matches_the_si_combination_rule_on_effective_radii(top):
    # The SI rule 1/gamma_ij^2 = R_i^2 + R_j^2 must hold once R is the
    # effective radius.  It does NOT hold if R is taken to be the mdin input.
    i, j = 0, 1
    R = top.effective_radius
    assert top.gamma_ij(i, j) == pytest.approx(
        1.0 / np.sqrt(R[i] ** 2 + R[j] ** 2), rel=1e-13)
    wrong = 1.0 / np.sqrt(PRODUCTION_WIDTH**2 + PRODUCTION_WIDTH**2)
    assert top.gamma_ij(i, j) == pytest.approx(wrong / np.sqrt(2.0), rel=1e-12)


def test_exclusions_are_symmetric(top):
    for i, s in enumerate(top.excluded):
        for j in s:
            assert i in top.excluded[j], f"exclusion {i}-{j} is not symmetric"
