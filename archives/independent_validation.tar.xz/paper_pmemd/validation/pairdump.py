"""Reader for the pmemd per-pair DEGAUSS dump.

The dump is written by the instrumented pair kernels when the mdin flag
`degauss_pairdump` is non-zero.  One record per evaluated DE pair:

    atom_i  atom_j  r  vdw_raw  alpha  beta  region

Atom indices are ORIGINAL (prmtop) 1-based indices, converted here to 0-based.
`region` is 0 for the non-alchemical kernel and 1 or 2 for the TI kernels.
"""

import numpy as np

DTYPE = np.dtype([("i", "i8"), ("j", "i8"), ("r", "f8"), ("evdw", "f8"),
                  ("alpha", "f8"), ("beta", "f8"), ("region", "i4")])

__all__ = ["DTYPE", "read", "as_pair_map"]


def read(path):
    rows = []
    with open(path) as fh:
        for line in fh:
            t = line.split()
            if len(t) != 7:
                continue
            try:
                rows.append((int(t[0]) - 1, int(t[1]) - 1, float(t[2]),
                             float(t[3]), float(t[4]), float(t[5]), int(t[6])))
            except ValueError:
                continue
    return np.array(rows, dtype=DTYPE)


def as_pair_map(dump):
    """{(min(i,j), max(i,j)): (r, evdw)} for easy comparison."""
    return {(min(int(a), int(b)), max(int(a), int(b))): (float(r), float(e))
            for a, b, r, e in zip(dump["i"], dump["j"], dump["r"], dump["evdw"])}
