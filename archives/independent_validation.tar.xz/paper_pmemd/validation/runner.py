"""Invoke pmemd and parse its output.  Serial CPU build only.

GPU is never used for correctness work: the manuscript's free-energy results
are all CPU, and SPFP round-off would swamp the comparisons this harness makes.
"""

import os
import re
import subprocess
import numpy as np

PMEMD = "/home8/larry/ambers/amber_merge_degauss_pmemd/build/src/pmemd/src/pmemd"
PMEMD_MPI_BUILD = ("/home8/larry/ambers/amber_merge_degauss_pmemd/"
                   "build_mpi_codex/src/pmemd/src/pmemd")

__all__ = ["PMEMD", "PMEMD_MPI_BUILD", "write_mdin", "parse_mdout",
           "parse_mbar", "run_pmemd", "read_forces", "write_inpcrd"]

_TERMS = {
    "Etot": "etot", "EPtot": "eptot", "VDWAALS": "vdwaals", "EELEC": "eelec",
    "EHBOND": "ehbond", "1-4 NB": "vdw14", "1-4 EEL": "eel14",
    "BOND": "bond", "ANGLE": "angle", "DIHED": "dihed", "DV/DL": "dvdl",
    "EKtot": "ektot", "RESTRAINT": "restraint",
}
_PAIR = re.compile(r"([A-Za-z0-9\-\s/]+?)\s*=\s*(-?\d+\.\d+(?:E[+-]\d+)?|\*+)")


def write_mdin(path, title="degauss validation", **cntrl):
    """Write a &cntrl namelist.  String values are quoted, numbers are not."""
    with open(path, "w") as fh:
        fh.write(title + "\n &cntrl\n")
        for key, val in cntrl.items():
            if isinstance(val, str):
                fh.write(f"   {key}='{val}',\n")
            elif isinstance(val, (list, tuple)):
                fh.write(f"   {key}={', '.join(str(v) for v in val)},\n")
            else:
                fh.write(f"   {key}={val},\n")
        fh.write(" /\n")


def write_inpcrd(path, crd, box):
    """Write an AMBER restart-format coordinate file."""
    crd = np.asarray(crd, dtype=float)
    with open(path, "w") as fh:
        fh.write("degauss validation\n%6d\n" % len(crd))
        flat = crd.reshape(-1)
        for k in range(0, len(flat), 6):
            fh.write("".join("%12.7f" % v for v in flat[k:k + 6]) + "\n")
        fh.write("".join("%12.7f" % v for v in list(box) + [90.0, 90.0, 90.0]) + "\n")


def parse_mdout(path):
    """Return the first NSTEP energy block as a dict of floats."""
    out, started = {}, False
    with open(path) as fh:
        for line in fh:
            if "NSTEP" in line and "TIME(PS)" in line:
                started, out = True, {}
                continue
            if not started:
                continue
            if line.strip().startswith("---"):
                if out:
                    break
                continue
            for raw, val in _PAIR.findall(line):
                key = _TERMS.get(raw.strip())
                if key and "*" not in val:
                    out[key] = float(val)
    return out


def parse_mbar(path):
    """Return the MBAR target energies from the first reported block.

    pmemd writes, under 'MBAR Energy analysis:', one line per target state.
    The exact layout is version dependent, so anything that parses as a
    trailing float on an indented line inside the block is taken.
    """
    rows, grab = [], False
    with open(path) as fh:
        for line in fh:
            if "MBAR Energy analysis" in line:
                grab, rows = True, []
                continue
            if not grab:
                continue
            toks = line.split()
            if not toks:
                if rows:
                    break
                continue
            try:
                rows.append(float(toks[-1]))
            except ValueError:
                if rows:
                    break
    return np.array(rows)


def run_pmemd(workdir, prmtop, inpcrd, mdin, refc=None, exe=PMEMD):
    """Run one pmemd job in `workdir` and return the parsed first energy block."""
    os.makedirs(workdir, exist_ok=True)
    mdout = os.path.join(workdir, "mdout")
    cmd = [exe, "-O", "-i", os.path.abspath(mdin),
           "-p", os.path.abspath(prmtop), "-c", os.path.abspath(inpcrd),
           "-o", mdout, "-r", os.path.join(workdir, "restrt"),
           "-x", os.path.join(workdir, "mdcrd"),
           "-inf", os.path.join(workdir, "mdinfo")]
    if refc:
        cmd += ["-ref", os.path.abspath(refc)]
    proc = subprocess.run(cmd, capture_output=True, text=True, cwd=workdir)
    if proc.returncode != 0:
        tail = ""
        if os.path.exists(mdout):
            tail = "".join(open(mdout).readlines()[-40:])
        raise RuntimeError(
            f"pmemd failed rc={proc.returncode}\n{proc.stdout}\n{proc.stderr}\n{tail}")
    res = parse_mdout(mdout)
    res["_mdout"] = mdout
    res["_workdir"] = workdir
    return res


def read_forces(path):
    """Parse an AMBER formatted force dump into an (natom, 3) array."""
    vals = []
    with open(path) as fh:
        fh.readline()
        for line in fh:
            vals.extend(float(t) for t in line.split())
    return np.array(vals, dtype=float).reshape(-1, 3)
