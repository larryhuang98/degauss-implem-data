"""Put the validation root on sys.path so `degauss_ref`, `systems`, `runner`
and `tests` are importable regardless of where pytest is invoked from.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
