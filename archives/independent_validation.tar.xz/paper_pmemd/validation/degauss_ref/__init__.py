"""Independent reference implementation of the DEGAUSS Hamiltonian.

Derived from the DEGAUSS papers and the manuscript equations only.
Deliberately shares no code and no constants with AMBER pmemd: any place where
this reference had to be changed in order to agree with pmemd is a finding,
recorded in validation/FINDINGS.md, not a silent edit.
"""
