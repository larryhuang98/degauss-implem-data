"""DEGAUSS pair functions and their radial derivatives.

Double-exponential van der Waals (manuscript Eq. 4):

    V(r) = eps/(alpha-beta) * [ beta*exp(alpha*a) - alpha*exp(beta*a) ],
    a    = 1 - r/r_m

which is equivalently  A*exp(-alpha*r/r_m) - C*exp(-beta*r/r_m)  with

    A = eps*beta *exp(alpha)/(alpha-beta)
    C = eps*alpha*exp(beta) /(alpha-beta)

Gaussian electrostatics (manuscript Eq. 2):

    u(r) = q_i q_j erf(gamma_ij r) / r
"""

import numpy as np
from scipy.special import erf, erfc

__all__ = [
    "de_coefficients", "de_energy", "de_dedr",
    "gauss_energy", "gauss_dedr", "pme_direct_energy",
]


def de_coefficients(eps, rmin, alpha, beta):
    """Return (A, C) such that V = A*exp(-alpha*r/rmin) - C*exp(-beta*r/rmin)."""
    diff = alpha - beta
    A = eps * beta * np.exp(alpha) / diff
    C = eps * alpha * np.exp(beta) / diff
    return A, C


def de_energy(r, eps, rmin, alpha, beta):
    """Double-exponential van der Waals pair energy."""
    a = 1.0 - np.asarray(r, dtype=float) / rmin
    return eps / (alpha - beta) * (beta * np.exp(alpha * a) - alpha * np.exp(beta * a))


def de_dedr(r, eps, rmin, alpha, beta):
    """dV/dr for the double-exponential pair energy.

    dV/dr = eps*alpha*beta/((alpha-beta)*r_m) * [exp(beta*a) - exp(alpha*a)],
    which vanishes exactly at a = 0, i.e. r = r_m.
    """
    a = 1.0 - np.asarray(r, dtype=float) / rmin
    return (eps * alpha * beta / ((alpha - beta) * rmin)
            * (np.exp(beta * a) - np.exp(alpha * a)))


def gauss_energy(r, qiqj, gamma_ij):
    """Gaussian-smeared electrostatic pair energy, qiqj in AMBER charge units."""
    r = np.asarray(r, dtype=float)
    return qiqj * erf(gamma_ij * r) / r


def gauss_dedr(r, qiqj, gamma_ij):
    """d/dr of the Gaussian electrostatic pair energy."""
    r = np.asarray(r, dtype=float)
    g = gamma_ij
    return qiqj * (2.0 * g / np.sqrt(np.pi) * np.exp(-((g * r) ** 2)) / r
                   - erf(g * r) / r**2)


def pme_direct_energy(r, qiqj, gamma_ij, kappa):
    """PME direct-space DEGAUSS pair energy: qq*[erf(g r) + erfc(k r) - 1]/r."""
    r = np.asarray(r, dtype=float)
    return qiqj * (erf(gamma_ij * r) + erfc(kappa * r) - 1.0) / r
