"""Reference lambda-dependent DEGAUSS Hamiltonians.

Mode numbering follows the USER-FACING ifsc_v values:

    0  none       direct interpolation, parameters fixed
    1  prefactor  cn1 *= exp(-alpha*lam^k), cn2 *= exp(-beta*lam^j)
    2  steepness  alpha, beta interpolate min -> base via f(lam)
    3  softcore   r~ = sqrt(r^2 + sc_alpha*lam*rm^2), outer (1-lam)^2 on cn1,cn2
    4  amplitude  endpoint-normalised weights on cn1, cn2

Note that pmemd's internal `ifsc_degauss` uses the legacy numbering, in which
1 and 2 are swapped; the permutation lives in mdin_ctrl_dat.F90:1569.  This
module deliberately uses only the user-facing numbering.

Region 1 is the disappearing region and is physical at lam = 0.
"""

import numpy as np

from .functions import de_coefficients
from .nonbonded import minimum_image

__all__ = ["schedule_f", "de_params_at_lambda", "amplitude_prefactor",
           "u_lambda", "dudl_numeric", "u_matrix"]


def schedule_f(lam, schedule, c):
    """Shape function f(lam) and f'(lam).  f(0)=0 and f(1)=1 for every variant."""
    if schedule == 1:
        return lam, 1.0
    if schedule == 2:
        return lam * lam, 2.0 * lam
    if schedule == 3:
        ec = np.exp(c)
        return (np.exp(c * lam) - 1.0) / (ec - 1.0), c * np.exp(c * lam) / (ec - 1.0)
    if schedule == 4:
        ec = np.exp(c)
        return (np.log(1.0 + lam * (ec - 1.0)) / c,
                (ec - 1.0) / (c * (1.0 + lam * (ec - 1.0))))
    if schedule == 5:
        return lam * lam * (3.0 - 2.0 * lam), 6.0 * lam * (1.0 - lam)
    raise ValueError(f"unknown schedule {schedule}")


def amplitude_prefactor(progress, shape, family):
    """q(p;c) = W(p;c)/(1-p) for the endpoint-normalised weight families.

    Only the exponential family (1) and the rational family (2) are needed by
    the current tests; the remaining families are rejected explicitly rather
    than silently returning 1.
    """
    remain = 1.0 - progress
    if family == 1:
        if shape <= 1.0e-10:
            return 1.0
        if remain <= 1.0e-8:
            return shape / (np.exp(shape) - 1.0)
        exp_end = np.exp(-shape)
        weight = (np.exp(-shape * progress) - exp_end) / (1.0 - exp_end)
        return weight / remain
    if family == 2:
        return 1.0 / (1.0 + shape * progress)
    raise NotImplementedError(f"amplitude family {family} not in the reference")


def de_params_at_lambda(top, lam, mode, *, alpha_min=5.0, beta_min=4.0,
                        schedule=2, schedule_c=2.0, k=3.0, j=3.0,
                        sc_alpha=0.5, amp_family=1, region=1):
    """Return the lambda-dependent DE parameters for one TI region."""
    nttyp = len(top.alpha)
    alpha = np.array(top.alpha, dtype=float)
    beta = np.array(top.beta, dtype=float)
    eps = np.array(top.eps, dtype=float)
    rmin = np.array(top.rmin, dtype=float)
    sc_shift = np.zeros(nttyp)

    # Region 1 is physical at lam=0; region 2 is the mirror image.
    lam_eff = lam if region == 1 else (1.0 - lam)

    if mode == 2:
        f, _ = schedule_f(1.0 - lam_eff, schedule, schedule_c)
        alpha = alpha_min + (alpha - alpha_min) * f
        beta = beta_min + (beta - beta_min) * f

    cn1 = np.zeros(nttyp)
    cn2 = np.zeros(nttyp)
    for t in range(nttyp):
        if abs(alpha[t] - beta[t]) <= 1.0e-10 or eps[t] <= 1.0e-20:
            continue
        A, C = de_coefficients(eps[t], rmin[t], alpha[t], beta[t])
        if mode == 1:
            A *= np.exp(-alpha[t] * lam_eff ** k)
            C *= np.exp(-beta[t] * lam_eff ** j)
        elif mode == 3:
            A *= (1.0 - lam_eff) ** 2
            C *= (1.0 - lam_eff) ** 2
            sc_shift[t] = sc_alpha * lam_eff * rmin[t] ** 2
        elif mode == 4:
            A *= amplitude_prefactor(lam_eff, k, amp_family)
            C *= amplitude_prefactor(lam_eff, j, amp_family)
        cn1[t], cn2[t] = A, C

    return {"alpha": alpha, "beta": beta, "cn1": cn1, "cn2": cn2,
            "sc_shift": sc_shift, "rmin": rmin, "eps": eps}


def _pair_energy(top, p, i, j, r):
    t = top.type_index(i, j)
    if t < 0 or (p["cn1"][t] == 0.0 and p["cn2"][t] == 0.0):
        return 0.0
    rr = np.sqrt(r * r + p["sc_shift"][t])
    x = rr / p["rmin"][t]
    return float(p["cn1"][t] * np.exp(-p["alpha"][t] * x)
                 - p["cn2"][t] * np.exp(-p["beta"][t] * x))


def u_lambda(top, crd, box, cutoff, lam, mode, *, weight=True, region=1, **kw):
    """Alchemical vdW energy at lam: w(lam) * sum_pairs V(r; lam)."""
    crd = np.asarray(crd, dtype=float)
    box = np.asarray(box, dtype=float)
    p = de_params_at_lambda(top, lam, mode, region=region, **kw)
    total = 0.0
    for i in range(top.natom - 1):
        for j in range(i + 1, top.natom):
            if j in top.excluded[i]:
                continue
            d = minimum_image(crd[j] - crd[i], box)
            r = float(np.sqrt(d @ d))
            if r >= cutoff or r == 0.0:
                continue
            total += _pair_energy(top, p, i, j, r)
    w = (1.0 - lam) if region == 1 else lam
    return w * total if weight else total


def dudl_numeric(top, crd, box, cutoff, lam, mode, h=1e-6, **kw):
    """Central-difference dU/dlambda of the fully weighted Hamiltonian."""
    lo = max(0.0, lam - h)
    hi = min(1.0, lam + h)
    return ((u_lambda(top, crd, box, cutoff, hi, mode, **kw)
             - u_lambda(top, crd, box, cutoff, lo, mode, **kw)) / (hi - lo))


def u_matrix(top, crd, box, cutoff, lambdas, mode, **kw):
    """U_k(x) for a single configuration at every lambda in `lambdas`."""
    return np.array([u_lambda(top, crd, box, cutoff, lk, mode, **kw)
                     for lk in lambdas])
