"""Unit constants, sourced independently of pmemd."""

# AMBER stores charges as q_e * sqrt(332.0522173).  A product of two stored
# charges therefore already carries the electrostatic conversion constant.
KE = 332.0522173
COULOMB_SCALE = 18.2223
