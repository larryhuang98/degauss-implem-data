"""Direct-space DEGAUSS non-bonded sums, computed by brute force.

No neighbour list, no spatial decomposition: every ordered pair is visited.
Correctness over speed -- the validation systems are deliberately tiny.
"""

import numpy as np

from .functions import (
    de_energy, de_dedr, gauss_energy, gauss_dedr, pme_direct_energy,
)

__all__ = ["minimum_image", "direct_space", "nb14"]


def minimum_image(dxyz, box):
    """Orthorhombic minimum-image convention."""
    dxyz = np.asarray(dxyz, dtype=float)
    box = np.asarray(box, dtype=float)
    return dxyz - box * np.round(dxyz / box)


def direct_space(top, crd, box, cutoff, kappa=None, do_elec=True, do_vdw=True):
    """Brute-force direct-space DEGAUSS energy and force.

    Returns dict with `evdw`, `eelec`, `forces` (natom x 3) and `pairs`,
    a list of (i, j, r, e_vdw, e_elec) for every pair inside the cutoff that
    contributed.
    """
    crd = np.asarray(crd, dtype=float)
    box = np.asarray(box, dtype=float)
    n = top.natom
    forces = np.zeros((n, 3))
    evdw = 0.0
    eelec = 0.0
    pairs = []

    for i in range(n - 1):
        for j in range(i + 1, n):
            d = minimum_image(crd[j] - crd[i], box)
            r = float(np.sqrt(d @ d))
            if r >= cutoff or r == 0.0:
                continue
            if j in top.excluded[i]:
                continue

            e_v = 0.0
            e_e = 0.0
            dedr = 0.0

            if do_vdw:
                k = top.type_index(i, j)
                if k >= 0 and top.eps[k] > 1.0e-20:
                    e_v = float(de_energy(r, top.eps[k], top.rmin[k],
                                          top.alpha[k], top.beta[k]))
                    dedr += float(de_dedr(r, top.eps[k], top.rmin[k],
                                          top.alpha[k], top.beta[k]))

            if do_elec:
                qq = float(top.charge[i] * top.charge[j])
                if qq != 0.0:
                    g = float(top.gamma_ij(i, j))
                    if kappa is None:
                        e_e = float(gauss_energy(r, qq, g))
                        dedr += float(gauss_dedr(r, qq, g))
                    else:
                        e_e = float(pme_direct_energy(r, qq, g, kappa))
                        h = 1.0e-6
                        dedr += float(
                            (pme_direct_energy(r + h, qq, g, kappa)
                             - pme_direct_energy(r - h, qq, g, kappa)) / (2 * h)
                        )

            if e_v == 0.0 and e_e == 0.0 and dedr == 0.0:
                continue

            evdw += e_v
            eelec += e_e
            fmag = -dedr / r
            forces[j] += fmag * d
            forces[i] -= fmag * d
            pairs.append((i, j, r, e_v, e_e))

    return {"evdw": evdw, "eelec": eelec, "forces": forces, "pairs": pairs}


def nb14(top, crd, box):
    """Scaled 1-4 interactions, evaluated with the DEGAUSS pair functions."""
    crd = np.asarray(crd, dtype=float)
    box = np.asarray(box, dtype=float)
    forces = np.zeros((top.natom, 3))
    evdw14 = 0.0
    eelec14 = 0.0

    for (i, j, scee, scnb) in top.pairs14:
        d = minimum_image(crd[j] - crd[i], box)
        r = float(np.sqrt(d @ d))
        if r == 0.0:
            continue
        k = top.type_index(i, j)
        e_v = 0.0
        dedr = 0.0
        if k >= 0 and top.eps[k] > 1.0e-20:
            e_v = float(de_energy(r, top.eps[k], top.rmin[k],
                                  top.alpha[k], top.beta[k])) / scnb
            dedr += float(de_dedr(r, top.eps[k], top.rmin[k],
                                  top.alpha[k], top.beta[k])) / scnb
        qq = float(top.charge[i] * top.charge[j])
        e_e = 0.0
        if qq != 0.0:
            g = float(top.gamma_ij(i, j))
            e_e = float(gauss_energy(r, qq, g)) / scee
            dedr += float(gauss_dedr(r, qq, g)) / scee

        evdw14 += e_v
        eelec14 += e_e
        fmag = -dedr / r
        forces[j] += fmag * d
        forces[i] -= fmag * d

    return {"evdw14": evdw14, "eelec14": eelec14, "forces": forces}
