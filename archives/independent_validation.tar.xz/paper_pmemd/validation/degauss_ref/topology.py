"""Independent parser for AMBER prmtop files carrying DEGAUSS parameters.

DEGAUSS prmtop sections (all optional; when absent the mdin defaults apply):

    GAUSS_RADII_LIST          natom   per-atom Gaussian width w
    DOUBLE_EXPONENTIAL_A      nttyp   alpha
    DOUBLE_EXPONENTIAL_C      nttyp   beta
    DOUBLE_EXPONENTIAL_EPS0   nttyp   eps
    DOUBLE_EXPONENTIAL_RMIN   nttyp   r_m

Width convention.  The stored/mdin value is a *width* w, not the effective
Gaussian radius.  The engine forms gbeta = 2*w**2 and gamma_ij =
1/sqrt(gbeta_i + gbeta_j).  Requiring that to equal the SI's combination rule
1/gamma_ij**2 = R_i**2 + R_j**2 gives gbeta_i == R_i**2, hence

    R_i = sqrt(2) * w

so the production input w = 0.2 A corresponds to an effective radius of
0.2828 A.  This module keeps the two names distinct on purpose.
"""

import re
import numpy as np

from .functions import de_coefficients

_FLAG = re.compile(r"^%FLAG\s+(\S+)")
_FORMAT = re.compile(r"^%FORMAT\((\d+)([aAiIeEfF])([\d.]+)\)")


def _read_sections(path):
    """Return {flag: [raw fixed-width tokens]} for every %FLAG block."""
    sections, flag, width = {}, None, None
    with open(path) as fh:
        for line in fh:
            m = _FLAG.match(line)
            if m:
                flag = m.group(1)
                sections[flag] = []
                width = None
                continue
            m = _FORMAT.match(line)
            if m:
                spec = m.group(3)
                width = int(spec.split(".")[0])
                continue
            if flag is None or width is None:
                continue
            row = line.rstrip("\n")
            trimmed = row.rstrip()
            sections[flag].extend(
                row[k:k + width] for k in range(0, len(trimmed), width)
            )
    return sections


class DegaussTopology:
    def __init__(self, **kw):
        self.__dict__.update(kw)

    @classmethod
    def from_prmtop(cls, path, gscale=1.0, width=0.2, adbexp=18.17, cdbexp=3.65):
        sec = _read_sections(path)

        def ints(flag):
            return np.array([int(t) for t in sec[flag]], dtype=int)

        def reals(flag):
            return np.array([float(t) for t in sec[flag]], dtype=float)

        pointers = ints("POINTERS")
        natom, ntypes = int(pointers[0]), int(pointers[1])
        nttyp = ntypes * (ntypes + 1) // 2

        charge = reals("CHARGE") * gscale
        iac = ints("ATOM_TYPE_INDEX") - 1
        ico = ints("NONBONDED_PARM_INDEX")
        cn1_lj = reals("LENNARD_JONES_ACOEF")
        cn2_lj = reals("LENNARD_JONES_BCOEF")

        widths = (reals("GAUSS_RADII_LIST") if "GAUSS_RADII_LIST" in sec
                  else np.full(natom, float(width)))
        alpha = (reals("DOUBLE_EXPONENTIAL_A") if "DOUBLE_EXPONENTIAL_A" in sec
                 else np.full(nttyp, float(adbexp)))
        beta = (reals("DOUBLE_EXPONENTIAL_C") if "DOUBLE_EXPONENTIAL_C" in sec
                else np.full(nttyp, float(cdbexp)))
        eps = (reals("DOUBLE_EXPONENTIAL_EPS0") if "DOUBLE_EXPONENTIAL_EPS0" in sec
               else np.zeros(nttyp))
        rmin = (reals("DOUBLE_EXPONENTIAL_RMIN") if "DOUBLE_EXPONENTIAL_RMIN" in sec
                else np.zeros(nttyp))

        # LJ fallback, mirroring read_degauss_prmtop's documented behaviour.
        for k in range(nttyp):
            if rmin[k] < 1.0e-20:
                if cn2_lj[k] > 1.0e-10:
                    rmin[k] = (2.0 * cn1_lj[k] / cn2_lj[k]) ** (1.0 / 6.0)
                    eps[k] = cn2_lj[k] ** 2 / (4.0 * cn1_lj[k])
                else:
                    rmin[k], eps[k] = 1.0, 0.0
                alpha[k], beta[k] = float(adbexp), float(cdbexp)

        cn1 = np.zeros(nttyp)
        cn2 = np.zeros(nttyp)
        for k in range(nttyp):
            if abs(alpha[k] - beta[k]) > 1.0e-10:
                cn1[k], cn2[k] = de_coefficients(eps[k], rmin[k], alpha[k], beta[k])

        gbeta = 2.0 * widths ** 2
        effective_radius = np.sqrt(gbeta)

        return cls(natom=natom, ntypes=ntypes, nttyp=nttyp, iac=iac, ico=ico,
                   charge=charge, widths=widths, gbeta=gbeta,
                   effective_radius=effective_radius,
                   alpha=alpha, beta=beta, eps=eps, rmin=rmin,
                   cn1=cn1, cn2=cn2, cn1_lj=cn1_lj, cn2_lj=cn2_lj,
                   excluded=cls._build_exclusions(sec, natom),
                   pairs14=cls._build_14(sec))

    @staticmethod
    def _build_exclusions(sec, natom):
        nexcl = np.array([int(t) for t in sec["NUMBER_EXCLUDED_ATOMS"]], dtype=int)
        lst = np.array([int(t) for t in sec["EXCLUDED_ATOMS_LIST"]], dtype=int)
        excluded = [set() for _ in range(natom)]
        pos = 0
        for i in range(natom):
            for k in range(nexcl[i]):
                j = int(lst[pos + k]) - 1
                if j >= 0:
                    excluded[i].add(j)
                    excluded[j].add(i)
            pos += int(nexcl[i])
        return excluded

    @staticmethod
    def _build_14(sec):
        """Return [(i, j, scee, scnb)] for dihedral-derived 1-4 pairs.

        AMBER encodes atom indices as (index-1)*3.  A negative third index
        suppresses the 1-4 (end group); a negative fourth index marks an
        improper, which has no 1-4 partner.
        """
        out = []
        for key in ("DIHEDRALS_INC_HYDROGEN", "DIHEDRALS_WITHOUT_HYDROGEN"):
            if key not in sec:
                continue
            vals = np.array([int(t) for t in sec[key]], dtype=int)
            scee = np.array([float(t) for t in sec["SCEE_SCALE_FACTOR"]]) \
                if "SCEE_SCALE_FACTOR" in sec else None
            scnb = np.array([float(t) for t in sec["SCNB_SCALE_FACTOR"]]) \
                if "SCNB_SCALE_FACTOR" in sec else None
            for k in range(0, len(vals), 5):
                i, j, kk, ll, idx = vals[k:k + 5]
                if kk < 0 or ll < 0:
                    continue
                e = scee[idx - 1] if scee is not None else 1.2
                n = scnb[idx - 1] if scnb is not None else 2.0
                out.append((abs(int(i)) // 3, abs(int(ll)) // 3, float(e), float(n)))
        return out

    def type_index(self, i, j):
        """0-based index into the nttyp arrays for atoms i and j."""
        k = self.ico[self.ntypes * self.iac[i] + self.iac[j]]
        return int(k) - 1

    def gamma_ij(self, i, j):
        return 1.0 / np.sqrt(self.gbeta[i] + self.gbeta[j])
