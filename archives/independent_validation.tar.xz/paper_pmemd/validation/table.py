#!/usr/bin/env python3
"""Final hydration free energy table, two-step protocol."""
import sys
for _m in ('jax','jaxlib'): sys.modules[_m] = None
sys.path.insert(0, '.')
import numpy as np
from pathlib import Path
from analyze import parse_mbar, KT
from pymbar import MBAR

R = Path('runs_freesolv')
NV = {'classical': 16, 'degauss': 16, 'degauss_pref': 24}
GMX = {'benzene': (-0.761, 0.005), 'methanol': (-3.521, 0.028), 'ethanol': (-3.467, 0.009)}
FS  = {'benzene': -0.81, 'methanol': -3.49, 'ethanol': -3.39}
EXP = {'benzene': -0.90, 'methanol': -5.10, 'ethanol': -5.00}

def leg(sol, mod, chan, n, skip=0.20):
    vals = []
    for rep in range(3):
        u, N, ok = [], [], True
        for k in range(n):
            f = R/sol/mod/chan/f'replica_{rep}'/f'lambda_{k:02d}'/'output.out'
            if not (f.parent/'DONE').exists(): ok = False; break
            e = parse_mbar(f, n)
            if len(e) < 50: ok = False; break
            e = e[int(skip*len(e)):]
            u.append(e/KT); N.append(len(e))
        if not ok: continue
        m = MBAR(np.concatenate(u, axis=0).T, np.asarray(N))
        vals.append(m.compute_free_energy_differences()['Delta_f'][0, -1]*KT)
    if not vals: return None
    a = np.asarray(vals)
    return a.mean(), (a.std(ddof=1)/np.sqrt(len(a)) if len(a) > 1 else float('nan'))

print()
print("Hydration free energy (kcal/mol) -- two-step decoupling, 5 ns/window, 3 replicas")
print("=" * 112)
print(f"{'solute':9s} {'AMBER':>16s} {'DEGAUSS':>16s} {'DEGAUSS':>16s} {'GROMACS':>16s} {'FreeSolv':>9s} {'expt':>7s}")
print(f"{'':9s} {'classical':>16s} {'direct':>16s} {'prefactor':>16s} {'classical':>16s} {'GAFF':>9s} {'':>7s}")
print("-" * 112)
for sol in ('benzene', 'methanol', 'ethanol'):
    cells = []
    for mod in ('classical', 'degauss', 'degauss_pref'):
        em = 'degauss' if mod == 'degauss_pref' else mod
        es, eg = leg(sol, em, 'elec', 5), leg(sol, em, 'elec_gas', 5)
        vd = leg(sol, mod, 'vdw', NV[mod])
        if not (es and eg and vd):
            cells.append("      --        "); continue
        dg = -((es[0]-eg[0]) + vd[0])
        err = np.sqrt(es[1]**2 + eg[1]**2 + vd[1]**2)
        cells.append(f"{dg:+7.3f} +/- {err:5.3f}")
    g = f"{GMX[sol][0]:+7.3f} +/- {GMX[sol][1]:5.3f}"
    print(f"{sol:9s} {cells[0]:>16s} {cells[1]:>16s} {cells[2]:>16s} {g:>16s} "
          f"{FS[sol]:+9.2f} {EXP[sol]:+7.2f}", flush=True)
print("=" * 112)
