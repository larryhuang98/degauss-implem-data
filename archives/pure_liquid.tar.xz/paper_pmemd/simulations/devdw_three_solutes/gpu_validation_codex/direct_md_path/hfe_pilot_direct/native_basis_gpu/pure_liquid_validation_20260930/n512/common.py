import os, re, json, time, hashlib, subprocess
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

HERE=Path(__file__).resolve().parent
SIM=Path('/home8/larry/project/alchemical/hfe/paper_pmemd/simulations/devdw_three_solutes')
B=SIM/'gpu_validation_codex/direct_md_path/hfe_pilot_direct/native_basis_gpu'
PREV=B/'cpu_gpu_properties_20260928'
EXES={'cpu':PREV/'pmemd.cpu.reference',
      'spfp':B/'parallel_bonded_clear/pmemd.cuda_SPFP.bonded',
      'dpfp':B/'parallel_bonded_clear/pmemd.cuda_DPFP.bonded'}
SOLUTES=['methanol','ethanol','benzene']
NMOLEC=512

def dump(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=Path(str(p)+'.tmp');tmp.write_text(json.dumps(x,indent=2,allow_nan=False));tmp.replace(p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stamp(p):Path(p).write_text(time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())+'\n')
def env_for():
    e={k:v for k,v in os.environ.items() if not k.startswith('DEGAUSS_')}
    e.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',CUDA_VISIBLE_DEVICES='0')
    return e
def records(p):
    t=Path(p).read_text().split('A V E R A G E S')[0];out=[]
    for m in re.finditer(r'NSTEP\s*=\s*(\d+)\s+TIME\(PS\)\s*=\s*([-+\d.Ee]+)(.*?)(?=NSTEP\s*=|\Z)',t,re.S):
        row={'step':int(m[1]),'time_ps':float(m[2])}
        for k,v in re.findall(r'([A-Za-z0-9()_ /-]+?)\s*=\s*([-+]?\d+(?:\.\d*)?(?:[Ee][-+]?\d+)?)',m[3]):row[k.strip()]=float(v)
        out.append(row)
    return out

def mdin(steps=600000, seed=70101, phase='liquid', restart=True, dt=.002, fixed=False, gascut=400):
    gas=phase=='gas'; npt=phase=='liquid' and not fixed
    return f'''DEGAUSS pure-liquid validation {phase}
 &cntrl
 imin=0, nstlim={steps}, dt={dt:.12g}, ig={seed},
 irest={int(restart)}, ntx={5 if restart else 1},
 ntt={0 if fixed else 3}, temp0=300, tempi=300, gamma_ln={0 if fixed else 2},
 ntb={2 if npt else 1}, ntp={1 if npt else 0},
 {('barostat=2, pres0=1.0, taup=2.0,') if npt else ''}
 ips={1 if gas else 0}, cut={gascut if gas else 8.0},
 ntc={1 if fixed else 2}, ntf=1, tol=0.0000001, nscm={0 if fixed else 1000},
 ioutfm=1, ntxo=2, iwrap=0, ntpr={steps if fixed else 100}, ntwr={steps},
 ntwx={0 if fixed else (1000 if not gas else 5000)}, ntwe=0,
 idegauss=1, icfe=0, gbeta=0.2, adbexp=18.17, cdbexp=3.65, gscale=1.0,
 /
 {'&ewald order=4, nfft1=8, nfft2=8, nfft3=8, a=1000, b=1000, c=1000, /' if gas else '&ewald order=4, nfft1=48, nfft2=48, nfft3=48, vdwmeth=1, /'}
'''

def check_parameters(p,gas=False):
    text=Path(str(p)+'.out').read_text()
    for flag,value in [('GAUSS_RADII_LIST',.2),('DOUBLE_EXPONENTIAL_A',18.17),('DOUBLE_EXPONENTIAL_C',3.65)]:
        m=re.search(r'^\s*'+flag+r'\s*\n([^\n]+)',text,re.M)
        assert m and abs(float(m[1].split()[0])-value)<1e-6,(p,flag)
    if not gas:
        m=re.search(r'NFFT1\s*=\s*(\d+).*?NFFT2\s*=\s*(\d+).*?NFFT3\s*=\s*(\d+)',text,re.S|re.I)
        assert m and tuple(map(int,m.groups()))==(48,48,48),(p,'FFT mesh')

def run(engine,inp,top,coord,p,steps=None,minimize=False):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    if Path(str(p)+'.complete').exists():return Path(str(p)+'.rst')
    if Path(str(p)+'.out').exists():raise RuntimeError('Refusing to overwrite incomplete attempt '+str(p))
    if engine!='cpu':
        # Do not interrupt external workloads or race an occupied exclusive GPU.
        while subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip():
            time.sleep(30)
    Path(str(p)+'.in').write_text(inp)
    cmd=[str(EXES[engine]),'-O','-i',str(p)+'.in','-p',str(top),'-c',str(coord),'-o',str(p)+'.out','-r',str(p)+'.rst','-x',str(p)+'.nc','-inf',str(p)+'.info']
    start=time.time()
    with Path(str(p)+'.log').open('w') as f:rc=subprocess.run(cmd,env=env_for(),stdout=f,stderr=subprocess.STDOUT).returncode
    dump(str(p)+'.run.json',{'engine':engine,'command':cmd,'returncode':rc,'wall_seconds':time.time()-start,'binary_sha256':sha(EXES[engine])})
    if rc:raise RuntimeError(str(p)+' exit '+str(rc)+'\n'+Path(str(p)+'.log').read_text()[-1200:])
    t=Path(str(p)+'.out').read_text()
    # Near-zero fixed-coordinate dt legitimately overflows seconds/ns timing.
    if re.search(r'\b(NaN|Infinity)\b',t,re.I) or re.search(r'=\s*\*{4}',t.split('A V E R A G E S')[0]):
        raise RuntimeError('Nonfinite/overflow '+str(p))
    if not minimize:
        rows=records(str(p)+'.out')
        assert rows and rows[-1]['step']==steps,(p,'incomplete',steps)
        check_parameters(p,gas='ips=1' in inp)
    with Dataset(str(p)+'.rst') as f:
        for name in ['coordinates','velocities','cell_lengths']:
            if name in f.variables:assert np.isfinite(f[name][:]).all(),(p,name)
    stamp(str(p)+'.complete')
    print(engine,p.name,'complete',round(time.time()-start,1),flush=True)
    return Path(str(p)+'.rst')
