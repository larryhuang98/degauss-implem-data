# DEGAUSS pure-liquid CPU/GPU validation

Authorized 2026-09-30 (America/Los_Angeles). This is a separate addition to the
paper; the interrupted aqueous-property campaign remains paused. No source,
selected binary, force-field parameter, or existing trajectory is overwritten.

## Systems and estimands

Methanol, ethanol and benzene: 512 molecules per cubic liquid box. Monomers are
extracted from the paper's existing GAFF/AM1-BCC solute topologies without
refitting bonded/nonbonded parameters. The original methanol/ethanol charge sums
are +0.00010/-0.00010 e from charge rounding. Subtract this residual uniformly
over each monomer's atoms before replication, identically for liquid and gas;
benzene is already neutral. This preparation correction is recorded in the
manifest and is not a fitted charge change. Use DE alpha=18.17, beta=3.65,
Gaussian input radius=0.2 A, full coupling. Verify replicated parameters and
neutrality, molecule counts, PME meshes, constraints and actual printed DE
parameters. The existing immutable CPU/SPFP/DPFP executables are used.

Liquid settings: 300 K, 1 bar, Monte Carlo barostat, Langevin gamma=2/ps, 2 fs,
SHAKE hydrogen bonds with tolerance 1e-7, ntf=1, cutoff 8 A, PME order 4 with
explicit common 48x48x48 meshes and the same dispersion-tail treatment. Use
ordinary NPT MD; no alchemical coefficient collector. Pack independently of
production outcomes, minimize on CPU, heat for 50 ps and equilibrate for 200 ps
NPT on CPU. From the common liquid configuration, run four independently seeded
replicas per backend, 1.2 ns each, discard the first 0.2 ns. Save thermodynamic
records every 0.2 ps and liquid coordinates every 2 ps.

The vaporization enthalpy is the classical fixed-charge model estimate

    Hvap = <U_gas> - <U_liquid>/512 + RT - p<V_liquid>/512.

Use kcal/mol and include the small liquid pV term. Kinetic contributions cancel
for the same molecular degrees of freedom. No experimental polarization or
quantum correction is applied in this implementation comparison. Four independent
CPU single-molecule gas references are shared across the three liquid backends.
Thus GPU results test condensed-phase evaluation/sampling, not GPU vacuum support.
Gas runs: same T, timestep, constraints and thermostat; 2.2 ns each, discard
0.2 ns; energy output every 0.2 ps. Before production, the nonperiodic CPU IPS
pilot failed (input-bound checks, then a segmentation fault). Logs are retained.
Use the supported periodic IPS path for one neutral molecule in a 1000 A cube,
so periodic copies lie beyond both tested interaction spheres. First check the
large-cutoff limit at 200 and 400 A on common conformations. Require
energy differences <0.001 kcal/mol and force RMS <0.0001 kcal/mol/A before using
400 A gas production. Repeat the same checks on the final configuration of each
gas replica before using the references in the paper. If this fails, investigate;
do not
silently substitute classical gas energies or a different Hamiltonian. The large
box is an isolated-molecule approximation with a measured IPS-cutoff control,
not a validation of the unsupported nonperiodic DEGAUSS entry point.

## Numerical and statistical checks (fixed before production)

On each equilibrated liquid, compare CPU/SPFP/DPFP near-fixed-coordinate energy
and forces with identical meshes and zero starting velocities. Gates: SPFP force
RMS <=0.001 kcal/mol/A, DPFP <=1e-5; total-energy differences <=0.05 and 0.001
kcal/mol respectively. Finite values and complete step/sample counts are required.

Replica means, not individual frames, are the independent observations. Report
backend means with Student-t 95% CIs. Compare GPU minus CPU using four replica
differences paired by index (seed labels do not imply equal random streams).
Practical equivalence margins: density +/-0.5% of CPU, Hvap +/-0.10 kcal/mol.
The shared gas-reference contribution cancels in CPU/GPU Hvap differences; include
gas uncertainty in absolute Hvap CIs. Report temperature and liquid energy per
molecule as diagnostics. An interval within the margin establishes equivalence
at that margin; crossing a margin is inconclusive, not proof of agreement.

Inspect density/energy time series, early/late halves and 100 ps block means for
equilibration and uncertainty. If equivalence is inconclusive or there is drift,
one bounded extension adds 1 ns to ALL four replicas of the affected system and
all liquid backends. Do not adjust margins after looking at outcomes. Any remaining
uncertainty is reported explicitly. These checks do not validate every fitted
parameter set, dielectric constants, heat capacities or experimental accuracy.

## Reporting

Add protocols and results to the existing single SI PDF, with a short main-text
sentence once justified. Preserve the user's TOC and scientific terminology.
Compile/render both PDFs, update the submission ZIP and push focused paper
changes to the existing GitHub master branch. Raw calculation data remain under
this separate validation directory. Reference methodology: Caleman et al., JCTC
2012, 8, 61-74, DOI 10.1021/ct200731v.

## Box-size amendment before any GPU property data

The 216-molecule GPU methanol pilot was rejected by Amber's neighbor-list
small-box check before force evaluation. On 2026-10-01 (America/Los_Angeles),
the liquid campaign was moved into this separate n512 directory, with 512
molecules and common 48^3 PME meshes for all backends and all three systems.
The 8 A cutoff, force-field parameters, ensembles, sampling lengths, number of
replicas and statistical margins are unchanged. No AllowSmallBox override is
used. Original incomplete 216-molecule CPU trajectories are preserved and are
excluded from the matched backend comparison. The original gas references are preserved separately; see the refinement below.

## Gas-cutoff refinement before use of property estimates

The original 100/200 A test on final gas snapshots found one methanol force
RMS difference of 1.00981e-4 kcal/mol/A, just above the unchanged 1e-4 bound.
Its energy difference was 0.0002 kcal/mol. The 200 A gas results remain archived
and are not used for the final estimates. Run fresh gas references for all three
solutes at 400 A in a 1000 A cube; compare 200/400 A on initial and final
conformations with the same original force/energy criteria. The force field,
T, trajectory lengths, replica counts and statistical margins are unchanged.

## Prespecified methanol extension, 2026-10-01 16:02 UTC

The original 48 trajectories completed and passed integrity and gas-cutoff checks.
All twelve CPU/GPU density and vaporization-enthalpy comparisons satisfied the
original equivalence margins. The methanol density nevertheless decreased by
about 0.25% from the first to the second analyzed 0.5 ns in all three backends;
the SPFP early/late density and energy intervals excluded zero. DECISION.json
in extension_methanol records these diagnostic values before continuation.
Use the protocol's single permitted extension: continue all four methanol
replicas in each backend for 1 ns from their own final coordinates and velocities,
with distinct continuation seeds and identical physical settings. Preserve all
original trajectories. Ethanol, benzene and gas references are unchanged.

For methanol, combine the original analyzed 1 ns with the new 1 ns; retain the
original 0.2 ns discard, giving 2 ns analyzed per replica. Do not select samples
after examining extension results. Report original and extended estimates
separately, inspect 100 ps blocks, first/second 1 ns means, and the extension-only
half means. The same four-replica 95% intervals and equivalence margins apply.
No further automatic extension is authorized by this protocol. If residual
drift or uncertainty remains, report it explicitly.
