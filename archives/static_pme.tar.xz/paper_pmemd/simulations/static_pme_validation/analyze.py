#!/usr/bin/env python3
"""Compare matched-coordinate DEGAUSS PME energies and force arrays."""

from __future__ import annotations

import json
import math
from pathlib import Path
import re

import numpy as np
from scipy.io import netcdf_file


HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"
MODES = ("cpu", "gpu_dpfp", "gpu_spfp")


def initial_energies(path: Path) -> dict[str, float]:
    text = path.read_text(errors="replace")
    header = re.search(r"NSTEP\s+ENERGY\s+RMS\s+GMAX", text)
    if header is None:
        raise RuntimeError(f"No minimization energy block in {path}")
    body = text[header.end() :]

    def value(label: str) -> float:
        match = re.search(
            rf"{re.escape(label)}\s*=\s*"
            r"([+-]?(?:\d+\.\d*|\.\d+)(?:[Ee][+-]?\d+)?)",
            body,
        )
        if match is None:
            raise RuntimeError(f"No {label} value in the energy block of {path}")
        return float(match.group(1))

    components = {
        label: value(label)
        for label in (
            "BOND",
            "ANGLE",
            "DIHED",
            "VDWAALS",
            "EEL",
            "HBOND",
            "1-4 VDW",
            "1-4 EEL",
            "RESTRAINT",
        )
    }
    return {
        "potential_kcal_mol": float(sum(components.values())),
        "electrostatic_kcal_mol": components["EEL"] + components["1-4 EEL"],
        "vdw_kcal_mol": components["VDWAALS"] + components["1-4 VDW"],
    }


def force_array(path: Path) -> np.ndarray:
    with netcdf_file(path, "r", mmap=False) as trajectory:
        if "forces" not in trajectory.variables:
            raise RuntimeError(f"No forces variable in {path}")
        values = np.asarray(trajectory.variables["forces"].data, dtype=float)
    if values.ndim != 3 or values.shape[0] < 1 or values.shape[2] != 3:
        raise RuntimeError(f"Unexpected force-array shape {values.shape} in {path}")
    return values[0]


def main() -> None:
    energies = {
        mode: initial_energies(RESULTS / mode / "energy.out") for mode in MODES
    }
    forces = {
        mode: force_array(RESULTS / mode / "forces.nc") for mode in MODES
    }
    if len({array.shape for array in forces.values()}) != 1:
        raise RuntimeError("CPU and GPU force-array shapes differ")

    cpu_energy = energies["cpu"]
    cpu_force = forces["cpu"]
    summary: dict[str, object] = {
        "atoms": int(cpu_force.shape[0]),
        "force_components": int(cpu_force.size),
        "cpu_mean_atomic_force_magnitude_kcal_mol_a": float(
            np.mean(np.linalg.norm(cpu_force, axis=1))
        ),
        "energies": energies,
        "comparisons_to_cpu": {},
    }
    comparisons = summary["comparisons_to_cpu"]
    assert isinstance(comparisons, dict)
    for mode in ("gpu_dpfp", "gpu_spfp"):
        difference = forces[mode] - cpu_force
        atom_norm = np.linalg.norm(difference, axis=1)
        comparisons[mode] = {
            "potential_energy_difference_kcal_mol": (
                energies[mode]["potential_kcal_mol"]
                - cpu_energy["potential_kcal_mol"]
            ),
            "electrostatic_energy_difference_kcal_mol": (
                energies[mode]["electrostatic_kcal_mol"]
                - cpu_energy["electrostatic_kcal_mol"]
            ),
            "vdw_energy_difference_kcal_mol": (
                energies[mode]["vdw_kcal_mol"] - cpu_energy["vdw_kcal_mol"]
            ),
            "force_component_rms_kcal_mol_a": float(
                math.sqrt(np.mean(difference * difference))
            ),
            "force_component_max_abs_kcal_mol_a": float(
                np.max(np.abs(difference))
            ),
            "per_atom_force_difference_norm_rms_kcal_mol_a": float(
                math.sqrt(np.mean(atom_norm * atom_norm))
            ),
        }

    output = HERE / "comparison.json"
    output.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    print(f"Wrote {output}")


if __name__ == "__main__":
    main()
