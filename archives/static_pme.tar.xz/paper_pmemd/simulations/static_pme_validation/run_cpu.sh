#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
AMBER="/home8/larry/ambers/amber_merge_degauss_pmemd"
SYSTEM="$AMBER/test/cuda/4096wat"
PMEMD="$AMBER/build/src/pmemd/src/pmemd"

mkdir -p "$HERE/results/cpu"
cd "$HERE/results/cpu"
"$PMEMD" -O \
  -i "$HERE/energy_mdin" \
  -p "$SYSTEM/prmtop" \
  -c "$SYSTEM/restrt" \
  -o energy.out \
  -r energy.rst7 \
  -inf energy.mdinfo
"$PMEMD" -O \
  -i "$HERE/mdin" \
  -p "$SYSTEM/prmtop" \
  -c "$SYSTEM/restrt" \
  -o output.out \
  -r output.rst7 \
  -frc forces.nc \
  -inf mdinfo
