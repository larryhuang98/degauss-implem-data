#!/usr/bin/env python3
import os,sys,re,json,subprocess
from pathlib import Path
D=Path('/home8/larry/project/alchemical/hfe/paper_pmemd/simulations/devdw_three_solutes/gpu_validation_codex/direct_md_path/hfe_pilot_direct')
B=D/'native_basis_gpu'
R=Path('/home8/larry/ambers/amber_merge_degauss_pmemd')
sys.path.insert(0,str(D.parent))
from scale_topology import read_values,put_values,scale
exe=Path(os.environ.get('DE_BASIS_VALIDATE_GPU',str(R/'build/src/pmemd/src/pmemd.cuda_SPFP')))
cpu=R/'build/src/pmemd/src/pmemd'
def run(cmd,log,env=None):
    with log.open('w') as f:
        rc=subprocess.run(list(map(str,cmd)),stdout=f,stderr=subprocess.STDOUT,env=env).returncode
    if rc:raise RuntimeError(f'{log}: {log.read_text()[-1800:]}')
def state_top(ref,dest,wq,wv):
    scale(ref,dest,wv)
    t=dest.read_text()
    q=read_values(ref.read_text(),'CHARGE',float)
    ns=read_values(t,'RESIDUE_POINTER',int)[1]-1
    q[:ns]=[v*wq for v in q[:ns]]
    dest.write_text(put_values(t,'CHARGE',q))
def energy(engine,mdin,top,coord,prefix,env=None):
    run([engine,'-O','-i',mdin,'-p',top,'-c',coord,'-o',str(prefix)+'.out',
         '-r',str(prefix)+'.rst','-inf',str(prefix)+'.info'],Path(str(prefix)+'.log'),env)
    output=Path(str(prefix)+'.out').read_text()
    return float(re.search(r'NSTEP\s*=\s*1\b.*?EPtot\s*=\s*([-+0-9.Ee]+)',output,re.S)[1])
def coeff_config(ref,dest,wq,wv,vdw=False):
    cmd=[sys.executable,B/'make_basis_config.py',ref,dest,'--wq',wq,'--wv',wv,'--stride',1]
    if vdw:cmd+=['--vdw-only']
    run(cmd,Path(str(dest)+'.log'))
results={}
solutes=sys.argv[1:] or ['methanol','ethanol','benzene','small_benzene']
for sol in solutes:
    out=B/os.environ.get('DE_BASIS_VALIDATE_FOLDER','validation')/sol
    out.mkdir(parents=True,exist_ok=True)
    small=sol=='small_benzene'
    base_sol=sol.split('_')[0] if '_' in sol and sol!='small_benzene' else sol
    ref=D.parent/('benzene_w1.0.prmtop' if small else base_sol+'_24a.prmtop')
    if sol=='methanol_charge_order6':
        source=ref.read_text()
        q=read_values(source,'CHARGE',float);q[0]+=18.2223
        ref=out/'charged_reference.prmtop'
        ref.write_text(put_values(source,'CHARGE',q))
    coord=D/'paper_benzene_2505/force/source_zero.rst' if small else D/'force_kernel_check'/base_sol/'source.rst'
    if sol.endswith('_uncoupled'):
        candidates=[D/'dense'/base_sol/'solvent/w00'/name for name in ['ext3.rst','ext2.rst','ext.rst','prod.rst']]
        coord=next(path for path in candidates if path.exists())
    mdin=out/'zero.in'
    mdin.write_text((B/'zero.in').read_text().replace('cut=10.0','cut=8.0') if small else (B/'zero.in').read_text())
    if sol=='methanol_charge_order6':
        mdin.write_text(mdin.read_text()+' &ewald order=6, /\n')
    if sol=='methanol_notail':
        mdin.write_text(mdin.read_text()+' &ewald vdwmeth=0, /\n')
    states=[(0,0),(.5,0),(1,0),(0,1),(.5,.5),(1,1),(.3,.7)]
    ec,eg={},{}
    for wq,wv in states:
        key=f'q{wq:g}_v{wv:g}'
        top=out/(key+'.prmtop');state_top(ref,top,wq,wv)
        ec[key]=energy(cpu,mdin,top,coord,out/(key+'_cpu'))
        eg[key]=energy(exe,mdin,top,coord,out/(key+'_gpu'))
    native={}
    for wq,wv in [(0,0),(.5,.5),(1,1),(.3,.7)]:
        key=f'q{wq:g}_v{wv:g}'
        config=out/(key+'.config')
        coeff_config(ref,config,wq,wv)
        env=os.environ.copy()
        env['DEGAUSS_BASIS_CONFIG']=str(config)
        env['DEGAUSS_BASIS_OUTPUT']=str(out/(key+'.basis'))
        energy(exe,mdin,out/(key+'.prmtop'),coord,out/(key+'_collect'),env)
        rows=[list(map(float,s.split())) for s in Path(env['DEGAUSS_BASIS_OUTPUT']).read_text().splitlines() if not s.startswith('#')]
        assert len(rows)==1
        native[key]=rows[0][1:4]
    coeff={}
    for kind,e in [('cpu',ec),('gpu',eg)]:
        c=2*(e['q1_v0']+e['q0_v0']-2*e['q0.5_v0'])
        b=e['q1_v0']-e['q0_v0']-c
        v=e['q0_v1']-e['q0_v0']
        coeff[kind]=[v,b,c]
    errors={}
    for key,co in native.items():
        errors[key]={kind:[co[i]-coeff[kind][i] for i in range(3)] for kind in coeff}
    recon={}
    co=native['q0.5_v0.5']
    for kind,e in [('cpu',ec),('gpu',eg)]:
        recon[kind]={}
        for wq,wv in states:
            key=f'q{wq:g}_v{wv:g}'
            reconstructed=wv*co[0]+wq*co[1]+wq*wq*co[2]
            recon[kind][key]=reconstructed-(e[key]-e['q0_v0'])
    results[sol]={'cpu':ec,'gpu':eg,'finite_difference_coefficients':coeff,
                  'native':native,'coefficient_errors':errors,'reconstruction_errors':recon}
    (out/'result.json').write_text(json.dumps(results[sol],indent=2))
    print(sol,json.dumps({'native':native['q0.5_v0.5'],'CPU coefficient error':errors['q0.5_v0.5']['cpu'],
                         'GPU coefficient error':errors['q0.5_v0.5']['gpu'],'reconstruction':recon}),flush=True)
(B/os.environ.get('DE_BASIS_VALIDATE_FOLDER','validation')/'results.json').write_text(json.dumps(results,indent=2))
