#!/usr/bin/env python3
"""Prepare 4 ns continuations of all completed 40-window benzene runs."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "benzene_40window_production"
RUNS = HERE / "runs"
STEPS = 2_000_000
EXPECTED_RECORDS = 4_000
PMEMD = Path(
    "/home8/larry/ambers/amber_merge_degauss_pmemd/"
    "build_mpi_codex/src/pmemd/src/pmemd"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def continuation_mdin(source: Path, path_name: str, replica: int, window: int) -> str:
    text = source.read_text()
    text, count = re.subn(r"nstlim\s*=\s*550000", f"nstlim={STEPS}", text, count=1)
    if count != 1:
        raise RuntimeError(f"Could not replace nstlim in {source}")
    lines = text.splitlines()
    lines[0] = (
        f"Benzene 4 ns extension; {path_name}; replica {replica}; "
        f"window {window:02d}"
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    topology = PARENT / "runs" / "benzene.parm7"
    source_tasks = PARENT / "tasks.tsv"
    if not PMEMD.is_file() or not topology.is_file() or not source_tasks.is_file():
        raise FileNotFoundError("Executable, topology, or parent task table is missing")

    tasks: list[dict[str, object]] = []
    for line in source_tasks.read_text().splitlines()[1:]:
        task_text, path_name, replica_text, window_text, lambda_text, directory_text = (
            line.split("\t")
        )
        source_directory = Path(directory_text)
        if not (source_directory / "DONE").is_file():
            raise RuntimeError(f"Parent trajectory is incomplete: {source_directory}")
        source_restart = source_directory / "output.rst7"
        source_mdin = source_directory / "mdin.npt"
        if not source_restart.is_file() or not source_mdin.is_file():
            raise FileNotFoundError(f"Missing parent restart or input in {source_directory}")

        task_id = int(task_text)
        replica = int(replica_text)
        window = int(window_text)
        directory = (
            RUNS / path_name / f"replica_{replica}" / "windows" / f"lambda_{window:02d}"
        )
        directory.mkdir(parents=True, exist_ok=True)
        mdin = directory / "mdin.4ns"
        expected = continuation_mdin(source_mdin, path_name, replica, window)
        if mdin.exists() and mdin.read_text() != expected:
            raise RuntimeError(f"Refusing to replace different input: {mdin}")
        mdin.write_text(expected)
        tasks.append(
            {
                "task_id": task_id,
                "path": path_name,
                "replica": replica,
                "window": window,
                "lambda": float(lambda_text),
                "source_directory": str(source_directory),
                "directory": str(directory),
            }
        )

    if len(tasks) != 480:
        raise RuntimeError(f"Expected 480 continuations, found {len(tasks)}")

    header = "task_id\tpath\treplica\twindow\tlambda\tsource_directory\tdirectory"
    rows = [header]
    for task in tasks:
        rows.append(
            "\t".join(
                (
                    str(task["task_id"]),
                    str(task["path"]),
                    str(task["replica"]),
                    str(task["window"]),
                    f'{float(task["lambda"]):.12f}',
                    str(task["source_directory"]),
                    str(task["directory"]),
                )
            )
        )
    (HERE / "tasks.tsv").write_text("\n".join(rows) + "\n")
    (HERE / "slurm").mkdir(exist_ok=True)

    manifest = {
        "description": "Four-nanosecond continuation of every benzene 40-window trajectory",
        "parent_campaign": str(PARENT),
        "task_count": len(tasks),
        "paths": sorted({str(task["path"]) for task in tasks}),
        "replicas": 3,
        "windows_per_path": 40,
        "steps_per_window": STEPS,
        "time_step_ps": 0.002,
        "extension_ns_per_window": STEPS * 0.002 / 1000.0,
        "bar_interval_steps": 500,
        "expected_energy_records": EXPECTED_RECORDS,
        "periodic_method": "PME",
        "topology": str(topology),
        "topology_sha256": sha256(topology),
        "pmemd": str(PMEMD),
        "pmemd_sha256": sha256(PMEMD),
        "tasks": tasks,
    }
    (HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"Prepared and validated {len(tasks)} continuations")


if __name__ == "__main__":
    main()
