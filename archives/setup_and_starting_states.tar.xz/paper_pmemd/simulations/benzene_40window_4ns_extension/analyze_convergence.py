#!/usr/bin/env python3
"""Detailed BAR convergence analysis for the 4 ns benzene continuations."""

from __future__ import annotations

import csv
import json
import os
import re
import sys
import warnings
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-benzene-4ns")
os.environ.setdefault("XDG_CACHE_HOME", "/tmp")
warnings.filterwarnings("ignore", category=RuntimeWarning, module="pymbar")
sys.modules["jax"] = None
sys.modules["jax.numpy"] = None

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from pymbar import MBAR, other_estimators


HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "benzene_40window_production"
PATHS = (
    "classical_softcore",
    "direct_de",
    "cubic_prefactor_de",
    "exponent_scaling_de",
)
LABELS = {
    "classical_softcore": "Classical softcore",
    "direct_de": "Direct DE",
    "cubic_prefactor_de": "DE exponential prefactor",
    "exponent_scaling_de": "DE exponent scaling",
}
COLORS = {
    "classical_softcore": "#d62728",
    "direct_de": "#1f77b4",
    "cubic_prefactor_de": "#ff7f0e",
    "exponent_scaling_de": "#2ca02c",
}
N_STATES = 40
N_REPLICAS = 3
EXTENSION_RECORDS = 4000
ORIGINAL_RECORDS = 1100
ORIGINAL_DISCARD = 110
BLOCK_SIZE = 1000
KT = 0.00198720425864083 * 300.0
ENERGY_RE = re.compile(r"\s*Energy at\s+[-\d.]+\s*=\s*(\S+)")


def read_lambdas(path: Path) -> np.ndarray:
    text = path.read_text()
    match = re.search(r"mbar_lambda=([^\n]+)", text)
    if match is None:
        raise RuntimeError(f"No lambda list in {path}")
    values = [float(value) for value in match.group(1).split(",") if value.strip()]
    if len(values) != N_STATES:
        raise RuntimeError(f"Expected {N_STATES} lambda values in {path}")
    return np.asarray(values)


def parse_window(path: Path, state: int, expected: int) -> dict[str, np.ndarray]:
    """Read only sampled-to-neighbor work from a full energy-matrix output."""
    left: list[float] = []
    right: list[float] = []
    position: int | None = None
    sampled_energy: float | None = None
    left_energy: float | None = None
    right_energy: float | None = None

    with path.open(errors="replace") as handle:
        for line in handle:
            if line.startswith("MBAR Energy analysis:"):
                if position is not None:
                    raise RuntimeError(f"Incomplete energy record in {path}")
                position = 0
                sampled_energy = None
                left_energy = None
                right_energy = None
                continue
            if position is None:
                continue
            match = ENERGY_RE.match(line)
            if match is None:
                continue
            token = match.group(1)
            if "*" in token:
                value = np.nan
            else:
                value = float(token)
            if position == state:
                sampled_energy = value
            if position == state - 1:
                left_energy = value
            if position == state + 1:
                right_energy = value
            position += 1
            if position == N_STATES:
                if sampled_energy is None:
                    raise RuntimeError(f"Missing sampled energy in {path}")
                if state > 0:
                    if left_energy is None:
                        raise RuntimeError(f"Missing left-neighbor energy in {path}")
                    left.append(left_energy - sampled_energy)
                if state < N_STATES - 1:
                    if right_energy is None:
                        raise RuntimeError(f"Missing right-neighbor energy in {path}")
                    right.append(right_energy - sampled_energy)
                position = None

    if position is not None:
        raise RuntimeError(f"Incomplete final energy record in {path}")
    observed = len(right) if state < N_STATES - 1 else len(left)
    if observed != expected:
        raise RuntimeError(f"Expected {expected} records in {path}; found {observed}")
    result: dict[str, np.ndarray] = {}
    if state > 0:
        result["left"] = np.asarray(left)
    if state < N_STATES - 1:
        result["right"] = np.asarray(right)
    if any(not np.isfinite(values).all() for values in result.values()):
        raise RuntimeError(f"Nonfinite adjacent work in {path}")
    return result


def load_replica(path_name: str, replica: int, extension: bool) -> list[dict[str, np.ndarray]]:
    windows: list[dict[str, np.ndarray]] = []
    for state in range(N_STATES):
        if extension:
            path = (
                HERE / "runs" / path_name / f"replica_{replica}" / "windows"
                / f"lambda_{state:02d}" / "output.4ns.out"
            )
            values = parse_window(path, state, EXTENSION_RECORDS)
        else:
            path = (
                PARENT / "runs" / path_name / f"replica_{replica}" / "windows"
                / f"lambda_{state:02d}" / "output.out"
            )
            values = {
                key: array[ORIGINAL_DISCARD:]
                for key, array in parse_window(path, state, ORIGINAL_RECORDS).items()
            }
        windows.append(values)
    return windows


def concatenate_windows(
    first: list[dict[str, np.ndarray]], second: list[dict[str, np.ndarray]]
) -> list[dict[str, np.ndarray]]:
    return [
        {
            key: np.concatenate((first[state][key], second[state][key]))
            for key in first[state]
        }
        for state in range(N_STATES)
    ]


def bar_profile(
    windows: list[dict[str, np.ndarray]], sample_slice: slice, overlap: bool = False
) -> dict[str, object]:
    increments = np.zeros(N_STATES - 1)
    formal = np.zeros(N_STATES - 1)
    overlaps = np.full(N_STATES - 1, np.nan)
    for state in range(N_STATES - 1):
        forward = windows[state]["right"][sample_slice] / KT
        reverse = windows[state + 1]["left"][sample_slice] / KT
        estimate = other_estimators.bar(forward, reverse)
        increments[state] = float(estimate["Delta_f"]) * KT
        formal[state] = float(estimate["dDelta_f"]) * KT
        if overlap:
            reduced = np.vstack(
                (
                    np.concatenate((np.zeros(len(forward)), reverse)),
                    np.concatenate((forward, np.zeros(len(reverse)))),
                )
            )
            reduced -= reduced.min(axis=0)
            estimator = MBAR(
                reduced,
                np.asarray((len(forward), len(reverse))),
                solver_protocol="robust",
                verbose=False,
            )
            overlaps[state] = float(estimator.compute_overlap()["scalar"])
    cumulative = np.concatenate(([0.0], np.cumsum(increments)))
    return {
        "increments": increments,
        "formal": formal,
        "overlaps": overlaps,
        "cumulative": cumulative,
        "endpoint": float(cumulative[-1]),
        "endpoint_formal": float(np.sqrt(np.sum(formal**2))),
    }


def analyze_path(path_name: str) -> dict[str, object]:
    mdin = HERE / "runs" / path_name / "replica_0" / "windows" / "lambda_00" / "mdin.4ns"
    lambdas = read_lambdas(mdin)
    original_endpoints = []
    extension_endpoints = []
    combined_endpoints = []
    extension_formal = []
    minimum_overlaps = []
    block_endpoints = np.zeros((N_REPLICAS, 4))
    prefix_endpoints = np.zeros((N_REPLICAS, 4))
    tail_endpoints = np.zeros((N_REPLICAS, 2))
    cumulative_profiles = []
    minimum_overlap_details: list[dict[str, object]] = []

    for replica in range(N_REPLICAS):
        original = load_replica(path_name, replica, extension=False)
        extension = load_replica(path_name, replica, extension=True)
        combined = concatenate_windows(original, extension)

        original_result = bar_profile(original, slice(None))
        extension_result = bar_profile(extension, slice(None), overlap=True)
        combined_result = bar_profile(combined, slice(None))
        original_endpoints.append(original_result["endpoint"])
        extension_endpoints.append(extension_result["endpoint"])
        combined_endpoints.append(combined_result["endpoint"])
        extension_formal.append(extension_result["endpoint_formal"])
        cumulative_profiles.append(extension_result["cumulative"])

        overlap_array = np.asarray(extension_result["overlaps"])
        pair = int(np.argmin(overlap_array))
        minimum_overlaps.append(float(overlap_array[pair]))
        minimum_overlap_details.append(
            {
                "replica": replica,
                "pair": pair,
                "lambda_left": float(lambdas[pair]),
                "lambda_right": float(lambdas[pair + 1]),
                "overlap": float(overlap_array[pair]),
            }
        )

        for block in range(4):
            start = block * BLOCK_SIZE
            stop = (block + 1) * BLOCK_SIZE
            block_endpoints[replica, block] = bar_profile(
                extension, slice(start, stop)
            )["endpoint"]
            prefix_endpoints[replica, block] = bar_profile(
                extension, slice(0, stop)
            )["endpoint"]
        tail_endpoints[replica, 0] = bar_profile(
            extension, slice(BLOCK_SIZE, None)
        )["endpoint"]
        tail_endpoints[replica, 1] = bar_profile(
            extension, slice(2 * BLOCK_SIZE, None)
        )["endpoint"]

    original_array = np.asarray(original_endpoints)
    extension_array = np.asarray(extension_endpoints)
    combined_array = np.asarray(combined_endpoints)
    formal_array = np.asarray(extension_formal)
    profiles = np.asarray(cumulative_profiles)
    worst = min(minimum_overlap_details, key=lambda row: float(row["overlap"]))

    return {
        "path": path_name,
        "label": LABELS[path_name],
        "lambda_values": lambdas.tolist(),
        "original_endpoints": original_array.tolist(),
        "extension_endpoints": extension_array.tolist(),
        "combined_endpoints": combined_array.tolist(),
        "original_mean": float(original_array.mean()),
        "original_replica_sd": float(original_array.std(ddof=1)),
        "extension_mean": float(extension_array.mean()),
        "extension_replica_sd": float(extension_array.std(ddof=1)),
        "combined_mean": float(combined_array.mean()),
        "combined_replica_sd": float(combined_array.std(ddof=1)),
        "extension_formal_endpoint_by_replica": formal_array.tolist(),
        "extension_formal_se_of_mean": float(np.sqrt(np.sum(formal_array**2)) / N_REPLICAS),
        "minimum_overlap_by_replica": minimum_overlaps,
        "minimum_overlap": float(worst["overlap"]),
        "minimum_overlap_detail": worst,
        "block_endpoints": block_endpoints.tolist(),
        "block_means": block_endpoints.mean(axis=0).tolist(),
        "block_replica_sds": block_endpoints.std(axis=0, ddof=1).tolist(),
        "prefix_endpoints": prefix_endpoints.tolist(),
        "prefix_means": prefix_endpoints.mean(axis=0).tolist(),
        "prefix_replica_sds": prefix_endpoints.std(axis=0, ddof=1).tolist(),
        "tail_endpoints": tail_endpoints.tolist(),
        "tail_means": tail_endpoints.mean(axis=0).tolist(),
        "tail_replica_sds": tail_endpoints.std(axis=0, ddof=1).tolist(),
        "first_last_block_change_by_replica": (
            block_endpoints[:, -1] - block_endpoints[:, 0]
        ).tolist(),
        "last_two_block_change_by_replica": (
            block_endpoints[:, -1] - block_endpoints[:, -2]
        ).tolist(),
        "extension_cumulative_profiles": profiles.tolist(),
        "maximum_cumulative_replica_sd": float(profiles.std(axis=0, ddof=1).max()),
        "maximum_cumulative_replica_sd_lambda": float(
            lambdas[int(np.argmax(profiles.std(axis=0, ddof=1)))]
        ),
    }


def write_csv(results: dict[str, dict[str, object]]) -> None:
    rows: list[dict[str, object]] = []
    for path_name, result in results.items():
        for replica in range(N_REPLICAS):
            row: dict[str, object] = {
                "path": path_name,
                "replica": replica,
                "original_0.99ns": result["original_endpoints"][replica],
                "extension_4ns": result["extension_endpoints"][replica],
                "combined_4.99ns": result["combined_endpoints"][replica],
            }
            for block in range(4):
                row[f"extension_block_{block + 1}_1ns"] = result["block_endpoints"][replica][block]
                row[f"extension_prefix_{block + 1}ns"] = result["prefix_endpoints"][replica][block]
            rows.append(row)
    output = HERE / "endpoint_convergence.csv"
    with output.open("w", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=list(rows[0]), lineterminator="\n"
        )
        writer.writeheader()
        writer.writerows(rows)


def make_figure(results: dict[str, dict[str, object]]) -> None:
    figure, axes = plt.subplots(2, 2, figsize=(9.0, 6.8), sharex=True)
    x = np.arange(1, 5)
    markers = ("o", "s", "^")
    for axis, path_name in zip(axes.flat, PATHS):
        result = results[path_name]
        blocks = np.asarray(result["block_endpoints"])
        for replica in range(N_REPLICAS):
            axis.plot(
                x,
                blocks[replica],
                color=COLORS[path_name],
                marker=markers[replica],
                alpha=0.58,
                linewidth=1.0,
                label=f"Replica {replica + 1}",
            )
        axis.plot(
            x,
            blocks.mean(axis=0),
            color="black",
            marker="D",
            linewidth=1.7,
            label="Block mean",
        )
        axis.axhline(float(result["extension_mean"]), color="0.45", linestyle="--", linewidth=0.9)
        axis.set_title(LABELS[path_name])
        axis.set_xticks(x, ["0--1", "1--2", "2--3", "3--4"])
        axis.grid(alpha=0.2, linewidth=0.5)
        axis.set_ylabel(r"Endpoint $\Delta G_{\mathrm{vdW}}$ (kcal mol$^{-1}$)")
    axes[0, 0].legend(frameon=False, fontsize=8, ncol=2)
    figure.supxlabel("Block within the 4 ns continuation (ns)")
    figure.tight_layout()
    figure.savefig(HERE / "benzene_4ns_block_convergence.png", dpi=250)
    figure.savefig(HERE / "benzene_4ns_block_convergence.pdf")
    plt.close(figure)


def write_report(results: dict[str, dict[str, object]]) -> None:
    lines = [
        "# Benzene 4 ns BAR convergence analysis",
        "",
        "All 4,000 continuation records per window were analyzed. The original comparison uses",
        "the 990 post-discard records from the preceding 1.1 ns campaign. Endpoint values are",
        "sums of adjacent-window BAR estimates. Replica SD and four consecutive 1 ns blocks are",
        "used to assess convergence; formal BAR uncertainty is reported separately.",
        "",
        "| Path | Original mean ± replica SD | 4 ns extension mean ± replica SD | Combined mean ± replica SD | Formal SE of 4 ns mean | Minimum adjacent overlap |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for path_name in PATHS:
        result = results[path_name]
        lines.append(
            f"| {LABELS[path_name]} | {result['original_mean']:+.4f} ± {result['original_replica_sd']:.4f} "
            f"| {result['extension_mean']:+.4f} ± {result['extension_replica_sd']:.4f} "
            f"| {result['combined_mean']:+.4f} ± {result['combined_replica_sd']:.4f} "
            f"| {result['extension_formal_se_of_mean']:.4f} | {result['minimum_overlap']:.3f} |"
        )
    lines.extend(["", "## Replica endpoints from the 4 ns extension", ""])
    for path_name in PATHS:
        result = results[path_name]
        values = ", ".join(f"{value:+.4f}" for value in result["extension_endpoints"])
        lines.append(f"- {LABELS[path_name]}: {values} kcal/mol")
    lines.extend(["", "## Consecutive 1 ns block means and replica SDs", ""])
    for path_name in PATHS:
        result = results[path_name]
        entries = [
            f"{mean:+.4f} ± {sd:.4f}"
            for mean, sd in zip(result["block_means"], result["block_replica_sds"])
        ]
        lines.append(f"- {LABELS[path_name]}: " + "; ".join(entries) + " kcal/mol")
    lines.extend(["", "## Cumulative endpoint means", ""])
    for path_name in PATHS:
        result = results[path_name]
        values = ", ".join(
            f"{value:+.4f}" for value in result["prefix_means"]
        )
        lines.append(
            f"- {LABELS[path_name]} after 1, 2, 3, and 4 ns: {values} kcal/mol"
        )
    lines.extend(["", "## Estimates after removing the beginning of the continuation", ""])
    for path_name in PATHS:
        result = results[path_name]
        lines.append(
            f"- {LABELS[path_name]}: final 3 ns {result['tail_means'][0]:+.4f} ± "
            f"{result['tail_replica_sds'][0]:.4f}; final 2 ns "
            f"{result['tail_means'][1]:+.4f} ± {result['tail_replica_sds'][1]:.4f} kcal/mol"
        )
    lines.extend(
        [
            "",
            "## Path-by-path assessment",
            "",
            "- **Classical softcore: replica convergence is satisfactory at about the 0.03",
            "  kcal/mol level, with mild residual time dependence.** The original and continuation",
            "  means differ by only 0.0098 kcal/mol, and the three 4 ns endpoints span 0.0479",
            "  kcal/mol. The final-3-ns and final-2-ns means differ by 0.0251 kcal/mol, which is",
            "  comparable to their replica SDs rather than evidence for a resolved drift.",
            "- **Direct DE: converged after the early continuation segment at about the 0.04",
            "  kcal/mol level.** The final-3-ns and final-2-ns means differ by only 0.0103",
            "  kcal/mol. However, the continuation mean is 0.1353 kcal/mol below the original",
            "  short-run estimate. The original segment should not be pooled as equilibrated",
            "  production when reporting the revised result.",
            "- **DE exponential prefactor: the aggregated endpoint is stable, although individual",
            "  1 ns blocks are noisy.** The final-3-ns and final-2-ns means are +1.1721 and",
            "  +1.1724 kcal/mol, respectively. Their replica SDs are 0.0486 and 0.0408 kcal/mol.",
            "  One replica changes by -0.2839 kcal/mol between its last two 1 ns blocks, so the",
            "  formal BAR error does not describe the observed temporal fluctuation.",
            "- **DE exponent scaling: converged only after excluding the first continuation",
            "  nanosecond.** All three replicas move upward from the first to the last 1 ns block,",
            "  showing that the early data retain a common time dependence. After that segment,",
            "  the final-3-ns and final-2-ns means are +1.2477 and +1.2584 kcal/mol, with replica",
            "  SDs of 0.0234 and 0.0432 kcal/mol. These tail estimates agree, whereas the original",
            "  +1.3366 kcal/mol estimate and the full-continuation average should not be treated",
            "  as equally equilibrated estimates.",
            "",
            "The maximum replica SD along the cumulative profiles occurs near the end of",
            "the path for classical softcore, direct DE, and DE exponent scaling (lambda = 0.974,",
            "0.999999, and 1.000, respectively). For the DE exponential-prefactor path it occurs",
            "near lambda = 0.744. Adjacent-window overlap remains high in every case (minimum",
            "0.899--0.982), so overlap is not the source of the remaining time dependence.",
        ]
    )
    lines.extend(
        [
            "",
            "## Interpretation rule",
            "",
            "Good adjacent overlap is necessary but is not used as proof of convergence. A path is",
            "considered stable only when the consecutive block estimates show no systematic drift",
            "and the three replica endpoints agree on the scale relevant to the manuscript. The",
            "formal BAR errors are much smaller than the observed run-to-run and block-to-block",
            "variation and therefore are not used as the convergence criterion.",
            "",
        ]
    )
    (HERE / "CONVERGENCE_REPORT.md").write_text("\n".join(lines))


def main() -> None:
    results: dict[str, dict[str, object]] = {}
    for path_name in PATHS:
        print(f"Analyzing {path_name}", flush=True)
        results[path_name] = analyze_path(path_name)
    (HERE / "convergence_analysis.json").write_text(json.dumps(results, indent=2) + "\n")
    write_csv(results)
    make_figure(results)
    write_report(results)
    print(HERE / "CONVERGENCE_REPORT.md")


if __name__ == "__main__":
    main()
