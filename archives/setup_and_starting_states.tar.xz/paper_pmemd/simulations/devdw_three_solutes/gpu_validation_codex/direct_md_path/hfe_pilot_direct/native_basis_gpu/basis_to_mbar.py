#!/usr/bin/env python3
"""Expand native GPU coefficients into MBAR reduced potentials without energy replay."""
import argparse
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('basis',type=Path)
p.add_argument('output',type=Path)
group=p.add_mutually_exclusive_group(required=True)
group.add_argument('--lambda-values',type=float,nargs='+',help='Use w=1-lambda for this convenience path')
group.add_argument('--weights-file',type=Path,help='Two whitespace-separated columns: wq wv')
p.add_argument('--temperature',type=float,default=300.0)
p.add_argument('--path',choices=['coupled','vdw'],default='coupled')
p.add_argument('--fixed-charge-weight',type=float,default=0.0)
a=p.parse_args()
data=np.loadtxt(a.basis,ndmin=2)
assert a.temperature>0
if a.weights_file:
    weights=np.loadtxt(a.weights_file,ndmin=2)
    assert weights.shape[1]==2
    wq,wv=weights[:,0],weights[:,1]
    lam=np.full(len(wq),np.nan)
else:
    lam=np.asarray(a.lambda_values)
    assert np.all((lam>=0)&(lam<=1))
    wv=1-lam
    wq=wv if a.path=='coupled' else np.full_like(wv,a.fixed_charge_weight)
assert np.all((wq>=0)&(wq<=1)&(wv>=0)&(wv<=1))
if 'mode=vdw' in a.basis.read_text()[:1024] and np.ptp(wq)>0:
    raise ValueError('VdW-only coefficients cannot reconstruct changing charge weights')
energy=wv[:,None]*data[:,1]+wq[:,None]*data[:,2]+wq[:,None]**2*data[:,3]
# A state-independent additive constant per sample cancels in MBAR.
energy-=energy[:1,:]
u_kn=energy/(0.00198720425864083*a.temperature)
np.savez(a.output,u_kn=u_kn,steps=data[:,0].astype(int),lambda_values=lam,
         wq=wq,wv=wv,temperature=a.temperature,energy_units='kcal/mol')
print(f'{u_kn.shape[0]} states x {u_kn.shape[1]} frames -> {a.output}')
