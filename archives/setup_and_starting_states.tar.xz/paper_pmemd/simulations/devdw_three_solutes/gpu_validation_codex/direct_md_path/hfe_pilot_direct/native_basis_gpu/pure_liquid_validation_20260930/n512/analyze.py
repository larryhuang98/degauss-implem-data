"""Replica-level thermodynamic estimates; no inference from incomplete runs."""
from common import *
from scipy.stats import t

R_KCAL=0.00198720425864083
PV_KCAL_PER_A3=1e5*1e-30*6.02214076e23/4184

def estimate(vals):
    a=np.asarray(vals,dtype=float);n=len(a)
    if not n:return {'n':0}
    mean=float(a.mean());half=float(t.ppf(.975,n-1)*a.std(ddof=1)/np.sqrt(n)) if n>1 else None
    return {'n':n,'mean':mean,'ci95':None if half is None else [mean-half,mean+half],'replicas':a.tolist()}

def run_metrics(p,steps,gas=False):
    if not Path(str(p)+'.complete').exists():return None
    rows=records(str(p)+'.out');assert rows[-1]['step']==steps
    used=[r for r in rows if r['step']>100000]
    assert len(used)==(steps-100000)//100,(p,len(used))
    for r in used:
        assert all(np.isfinite(v) for v in r.values()),p
    d={'path':str(p),'samples':len(used),'steps':steps,'temperature':float(np.mean([r['TEMP(K)'] for r in used])),
       'energy':float(np.mean([r['EPtot'] for r in used]))}
    if not gas:
        d['density']=float(np.mean([r['Density'] for r in used]))
        d['volume']=float(np.mean([r['VOLUME'] for r in used]))
    for key,col in [('energy','EPtot'),('density','Density')]:
        if col not in used[0]:continue
        arr=np.array([r[col] for r in used]);mid=len(arr)//2
        d[key+'_early_late']=[float(arr[:mid].mean()),float(arr[mid:].mean())]
        d[key+'_100ps_blocks']=[float(arr[i:i+500].mean()) for i in range(0,len(arr),500)]
    with Dataset(str(p)+'.nc') as f:
        expected=steps//(5000 if gas else 1000)
        assert len(f.dimensions['frame'])==expected,(p,'frames')
        for key in ['coordinates','cell_lengths','cell_angles']:
            if key in f.variables:assert np.isfinite(f[key][:]).all(),(p,key)
    return d

def classify(delta,margin):
    d=estimate(delta);d['margin']=margin
    if d['n']!=4:d['status']='incomplete'
    elif d['ci95'][0]>=-margin and d['ci95'][1]<=margin:d['status']='equivalent_at_margin'
    elif d['ci95'][0]>margin or d['ci95'][1]<-margin:d['status']='outside_margin'
    else:d['status']='inconclusive'
    return d

def main():
    manifest=json.loads((HERE/'manifest.json').read_text());errors=[];out={};counts={'gas':0,'cpu':0,'spfp':0,'dpfp':0}
    for e,p in EXES.items():assert sha(p)==manifest['executables'][e]['sha256'],(e,'binary')
    for sol in SOLUTES:
        for name in ['liquid','gas','gasbox','gasbox1000']:assert sha(HERE/'systems'/sol/(name+'.prmtop'))==manifest['systems'][sol][name+'_top_sha256']
        gas={};liq={e:{} for e in EXES}
        for r in range(1,5):
            p=HERE/'gas'/sol/('r'+str(r))
            try:g=run_metrics(p,1100000,True)
            except Exception as ex:errors.append(str(ex));g=None
            if g:gas[r]=g;counts['gas']+=1
            for e in EXES:
                p=HERE/'liquid'/sol/e/('r'+str(r))
                try:l=run_metrics(p,600000)
                except Exception as ex:errors.append(str(ex));l=None
                if l:liq[e][r]=l;counts[e]+=1
        summary={};comparison={}
        for e in EXES:
            for r,l in liq[e].items():
                if r in gas:
                    l['hvap']=gas[r]['energy']-l['energy']/NMOLEC+R_KCAL*300-PV_KCAL_PER_A3*l['volume']/NMOLEC
            summary[e]={k:estimate([l[k] for l in liq[e].values() if k in l]) for k in ['density','hvap','temperature','energy']}
        for e in ['spfp','dpfp']:
            common=sorted(set(liq[e])&set(liq['cpu']))
            if common:
                cpu_mean=summary['cpu']['density']['mean']
                density_delta=[100*(liq[e][r]['density']-liq['cpu'][r]['density'])/cpu_mean for r in common]
                # Shared gas energy cancels exactly. Do not add its uncertainty twice.
                h_delta=[-(liq[e][r]['energy']-liq['cpu'][r]['energy'])/NMOLEC-PV_KCAL_PER_A3*(liq[e][r]['volume']-liq['cpu'][r]['volume'])/NMOLEC for r in common]
                comparison[e]={'density_relative_percent':classify(density_delta,.5),'hvap_kcal_mol':classify(h_delta,.10)}
        out[sol]={'gas_replicas':gas,'liquid_replicas':liq,'summary':summary,'comparison':comparison}
    result={'counts':counts,'complete':counts=={'gas':12,'cpu':12,'spfp':12,'dpfp':12},'errors':errors,'systems':out,
       'definition':'Ugas-Uliq/N+RT-pVliq/N; common independent CPU gas reference',
       'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    dump(HERE/'summary.json',result)
    print(json.dumps({'counts':counts,'complete':result['complete'],'errors':errors},indent=2))
    if errors:raise RuntimeError(errors)
    if result['complete']:stamp(HERE/'analysis_complete')

if __name__=='__main__':main()
