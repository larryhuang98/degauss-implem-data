"""Property comparisons with independent replicas as the unit of uncertainty."""
import sys
from scipy.stats import t as student_t
from scipy.spatial import cKDTree
from common import *

def autocorr_sum(x):
    n=len(x); nf=1 << (2*n-1).bit_length()
    ft=np.fft.rfft(x,n=nf,axis=0)
    power=np.sum(ft.real**2+ft.imag**2,axis=tuple(range(1,ft.ndim)))
    return np.fft.irfft(power,n=nf)[:n]

def msd(x,maxlag):
    x=np.asarray(x,dtype=np.float64);x=x-x[0]
    n=len(x);nmol=x.shape[1]
    q=np.sum(x*x,axis=(1,2));cs=np.r_[0,np.cumsum(q)]
    lag=np.arange(maxlag+1)
    return (cs[n-lag]+cs[n]-cs[lag]-2*autocorr_sum(x)[lag])/((n-lag)*nmol)

def unwrap(x,box):
    dx=np.diff(x,axis=0);dx-=box*np.rint(dx/box)
    return np.concatenate([x[:1],x[:1]+np.cumsum(dx,axis=0)],axis=0)

def c2(u,maxlag):
    u=u/np.linalg.norm(u,axis=-1,keepdims=True)
    n=len(u);nmol=u.shape[1];corr=np.zeros(n)
    # Sum the tensor autocorrelations in chunks to keep memory bounded.
    for start in range(0,nmol,64):
        v=u[:,start:start+64]
        x=np.stack([v[:,:,0]**2,v[:,:,1]**2,v[:,:,2]**2,
                    2**.5*v[:,:,0]*v[:,:,1],2**.5*v[:,:,0]*v[:,:,2],
                    2**.5*v[:,:,1]*v[:,:,2]],axis=-1)
        corr+=autocorr_sum(x)
    lag=np.arange(maxlag+1)
    return 1.5*corr[lag]/((n-lag)*nmol)-.5

def nvt_dynamics(sol,prefix):
    top=(HERE/'systems'/sol/'reference.prmtop').read_text()
    masses=values(top,'MASS');ns=values(top,'RESIDUE_POINTER',int)[1]-1
    with Dataset(str(prefix)+'.nc') as f:
        times=np.asarray(f['time'][:],float);dt=float(np.median(np.diff(times)))
        elapsed=times-times[0]+dt;sel=elapsed>40+1e-6
        xyz=np.asarray(f['coordinates'][sel],float)
        cells=np.asarray(f['cell_lengths'][sel],float)
    box=cells[0];assert np.max(np.abs(cells-box))<1e-5
    assert (len(masses)-ns)%3==0
    waters=np.arange(ns,len(masses)).reshape(-1,3)
    assert np.all(masses[waters[:,0]]>15) and np.all(masses[waters[:,1:]]<2)
    oxygen=unwrap(xyz[:,waters[:,0]],box)
    rel=xyz[:,:ns]-xyz[:,0:1];rel-=box*np.rint(rel/box)
    mol=xyz[:,0:1]+rel
    com=np.sum(mol*masses[None,:ns,None],axis=1,keepdims=True)/masses[:ns].sum()
    com=unwrap(com,box)
    oh1=xyz[:,waters[:,1]]-xyz[:,waters[:,0]];oh1-=box*np.rint(oh1/box)
    oh2=xyz[:,waters[:,2]]-xyz[:,waters[:,0]];oh2-=box*np.rint(oh2/box)
    water_u=oh1+oh2
    heavy=np.flatnonzero(masses[:ns]>2)
    if sol=='benzene':u=np.cross(rel[:,heavy[1]]-rel[:,heavy[0]],rel[:,heavy[2]]-rel[:,heavy[0]])[:,None,:]
    else:u=(rel[:,heavy[1]]-rel[:,heavy[0]])[:,None,:]
    lag=np.arange(round(40/dt)+1)*dt
    wm=msd(oxygen,len(lag)-1);sm=msd(com,len(lag)-1)
    water_fit=(lag>=5)&(lag<=20);solute_fit=(lag>=10)&(lag<=40)
    # A^2/ps -> 10^-9 m^2/s is a factor of 10.
    dw=float(np.polyfit(lag[water_fit],wm[water_fit],1)[0]/6*10)
    ds=float(np.polyfit(lag[solute_fit],sm[solute_fit],1)[0]/6*10)
    wrot=c2(water_u,round(10/dt));srot=c2(u,round(40/dt))
    rt=np.arange(len(wrot))*dt;st=np.arange(len(srot))*dt
    metrics={'water_D_1e9_m2s':dw,'solute_D_1e9_m2s':ds,
             'water_C2_integral_0_10ps':float(np.trapezoid(wrot,rt)),
             'solute_C2_integral_0_40ps':float(np.trapezoid(srot,st)),
             'water_C2_at_10ps':float(wrot[-1]),'solute_C2_at_40ps':float(srot[-1])}
    # Structural diagnostic; normalize each pair histogram to ideal-gas shell counts.
    edges=np.arange(0,6.0001,.05);hist=np.zeros(len(edges)-1);count=0
    nw=len(waters)
    for frame in xyz[::20]:
        o=np.mod(frame[waters[:,0]],box)
        pairs=cKDTree(o,boxsize=box).query_pairs(6,output_type='ndarray')
        delta=o[pairs[:,0]]-o[pairs[:,1]];delta-=box*np.rint(delta/box)
        hist+=np.histogram(np.linalg.norm(delta,axis=1),bins=edges)[0];count+=1
    shell=4*np.pi/3*np.diff(edges**3)
    rdf=hist/(count*nw*(nw-1)/2*shell/np.prod(box))
    np.savez_compressed(str(prefix)+'.analysis.npz',msd_time_ps=lag,water_msd=wm,solute_msd=sm,
                        water_c2_t=rt,water_c2=wrot,solute_c2_t=st,solute_c2=srot,rdf_r=(edges[1:]+edges[:-1])/2,rdf=rdf)
    return metrics

def run_metrics(sol,engine,ensemble,rep):
    p=HERE/'production'/sol/engine/(ensemble+'_r'+str(rep))
    out=Path(str(p)+'.metrics.json')
    if out.exists():return json.loads(out.read_text())
    if not Path(str(p)+'.complete').exists():return None
    rows=records(str(p)+'.out');n=len(values((HERE/'systems'/sol/'reference.prmtop').read_text(),'MASS'))
    if ensemble=='nve':
        x=np.array([r['time_ps'] for r in rows]);e=np.array([r['Etot'] for r in rows]);x-=x[0]
        slope=np.polyfit(x,e,1)[0]
        m={'drift_kcal_mol_atom_ns':float(slope*1000/n),
           'energy_range_kcal_mol_atom':float(np.ptp(e)/n),
           'energy_rms_kcal_mol_atom':float(np.std(e)/n),'duration_ps':float(x[-1]-x[0])}
    else:
        rows=[r for r in rows if r['step']>20000]
        u=np.array([r['EPtot'] for r in rows]);temp=np.array([r['TEMP(K)'] for r in rows])
        m={'temperature_K':float(temp.mean()),'potential_kcal_mol_atom':float(u.mean()/n),
           'potential_variance_kcal2_mol2':float(u.var(ddof=1)), 'samples':len(rows)}
        if ensemble=='npt':
            m.update(density_g_cm3=float(np.mean([r['Density'] for r in rows])),
                     volume_A3=float(np.mean([r['VOLUME'] for r in rows])))
        else:m.update(nvt_dynamics(sol,p))
    dump_json(out,m);return m

def compare(a,b,margin,relative=False):
    a=np.array(a,float);b=np.array(b,float);delta=b-a;n=len(delta)
    mean=float(delta.mean());se=float(delta.std(ddof=1)/np.sqrt(n));h=float(student_t.ppf(.975,n-1)*se)
    tol=abs(float(a.mean()))*margin if relative else margin
    low,high=mean-h,mean+h
    status=('equivalent_at_margin' if low>-tol and high<tol else
            ('outside_margin' if low>tol or high<-tol else 'inconclusive'))
    return {'cpu_mean':float(a.mean()),'gpu_mean':float(b.mean()),'difference':mean,
            'relative_percent':float(100*mean/a.mean()) if a.mean()!=0 else None,
            'ci95_difference':[low,high],'equivalence_margin':tol,'replicas':n,
            'status':status}

def fixed_summary(directory='fixed', filename='fixed_summary.json'):
    results={}
    for p in (HERE/directory).glob('*/*/cpu.result.json'):
        d=p.parent;cpu=json.loads(p.read_text());cf=np.load(d/'cpu.forces.npy');key=str(d.relative_to(HERE/directory))
        r={}
        for e in ['spfp','dpfp']:
            if not (d/(e+'.result.json')).exists():continue
            g=json.loads((d/(e+'.result.json')).read_text());gf=np.load(d/(e+'.forces.npy'));df=gf-cf
            rm=float(np.sqrt(np.mean(df**2)))
            r[e]={'force_rms_kcal_mol_A':rm,'force_max_kcal_mol_A':float(np.max(np.abs(df))),
                  'relative_force_rms':rm/float(np.sqrt(np.mean(cf**2))),
                  'EPtot_difference_kcal_mol':g['last_record']['EPtot']-cpu['last_record']['EPtot'],
                  'parameters':g['observed_parameters']}
            for q in ['VIRIAL','PRESS']:
                if q in cpu['last_record']:r[e][q+'_difference']=g['last_record'][q]-cpu['last_record'][q]
        results[key]=r
    dump_json(HERE/filename,results)

def main():
    fixed_summary()
    if (HERE/'fixed_matched_mesh').exists():
        fixed_summary('fixed_matched_mesh','fixed_matched_mesh_summary.json')
    allmetrics={};comparisons={}
    margins={'temperature_K':(1.,False),'potential_kcal_mol_atom':(.01,False),
             'density_g_cm3':(.005,True),'water_D_1e9_m2s':(.05,True),
             'solute_D_1e9_m2s':(.15,True),'water_C2_integral_0_10ps':(.05,True),
             'solute_C2_integral_0_40ps':(.15,True)}
    for sol in ['methanol','ethanol','benzene']:
        for ensemble in ['nvt','npt','nve']:
            key=sol+'/'+ensemble;allmetrics[key]={}
            for e in ['cpu','spfp','dpfp']:
                allmetrics[key][e]=[run_metrics(sol,e,ensemble,r) for r in (range(1,5) if ensemble!='nve' else [1])]
            comparisons[key]={}
            if ensemble=='nve':continue
            cpu=allmetrics[key]['cpu']
            if any(x is None for x in cpu):continue
            for e in ['spfp','dpfp']:
                gpu=allmetrics[key][e]
                if any(x is None for x in gpu):continue
                comparisons[key][e]={m:compare([x[m] for x in cpu],[x[m] for x in gpu],*rule)
                                     for m,rule in margins.items() if m in cpu[0]
                                     and not (ensemble=='npt' and m=='potential_kcal_mol_atom')}
    dump_json(HERE/'property_metrics.json',allmetrics);dump_json(HERE/'property_comparisons.json',comparisons)
    print(json.dumps(comparisons,indent=2))

if __name__=='__main__':main()
