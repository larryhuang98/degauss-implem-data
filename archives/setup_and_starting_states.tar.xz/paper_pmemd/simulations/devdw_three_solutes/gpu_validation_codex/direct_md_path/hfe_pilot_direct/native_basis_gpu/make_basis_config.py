#!/usr/bin/env python3
"""Reference sidecar for native GPU basis collection.
Matches read_degauss_prmtop, including its LJ fallback behavior.
The sampling topology must scale first-residue charges and cross DE amplitudes.
"""
import argparse,math,re
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('reference',type=Path)
p.add_argument('output',type=Path)
p.add_argument('--wq',type=float,default=.5)
p.add_argument('--wv',type=float,default=.5)
p.add_argument('--stride',type=int,default=500)
p.add_argument('--vdw-only',action='store_true')
p.add_argument('--adbexp',type=float,default=18.17)
p.add_argument('--cdbexp',type=float,default=3.65)
p.add_argument('--gbeta',type=float,default=.2)
p.add_argument('--gscale',type=float,default=1)
a=p.parse_args()
text=a.reference.read_text()
def values(flag,cast=float,default=None):
    m=re.search(r'^%FLAG\s+'+re.escape(flag)+r'\s*\n%FORMAT[^\n]*\n(.*?)(?=^%FLAG|\Z)',text,re.M|re.S)
    if not m:
        if default is not None:return list(default)
        raise ValueError(flag)
    return list(map(cast,m[1].split()))
n,nt=values('POINTERS',int)[:2]
res=values('RESIDUE_POINTER',int)
ns=res[1]-1 if len(res)>1 else n
assert 0<ns<n
types=[i-1 for i in values('ATOM_TYPE_INDEX',int)]
q=[v*a.gscale for v in values('CHARGE')]
radii=values('GAUSS_RADII_LIST',default=[a.gbeta]*n)
ico=values('NONBONDED_PARM_INDEX',int)
assert min(ico)>0,'10-12 HBond terms are not supported'
la,lb=values('LENNARD_JONES_ACOEF'),values('LENNARD_JONES_BCOEF')
np=len(la)
de_a=values('DOUBLE_EXPONENTIAL_A',default=[a.adbexp]*np)
de_c=values('DOUBLE_EXPONENTIAL_C',default=[a.cdbexp]*np)
rmin=values('DOUBLE_EXPONENTIAL_RMIN',default=[0]*np)
eps=values('DOUBLE_EXPONENTIAL_EPS0',default=[0]*np)
for i in range(np):
    if rmin[i]<1e-20:
        rmin[i]=(2*la[i]/lb[i])**(1/6) if lb[i]>1e-10 else 1
        eps[i]=lb[i]**2/(4*la[i]) if lb[i]>1e-10 else 0
        de_a[i],de_c[i]=a.adbexp,a.cdbexp
pairs=[]
for slot in ico:
    k=slot-1
    assert rmin[k]>.1 and de_a[k]>de_c[k]>0
    A=eps[k]*de_c[k]*math.exp(de_a[k])/(de_a[k]-de_c[k])
    C=eps[k]*de_a[k]*math.exp(de_c[k])/(de_a[k]-de_c[k])
    pairs.append((A,C,de_a[k]/rmin[k],de_c[k]/rmin[k]))
ex=[[0.,0.] for i in range(ns*ns)]
counts=values('NUMBER_EXCLUDED_ATOMS',int)
lst=values('EXCLUDED_ATOMS_LIST',int)
pos=0
for i,cnt in enumerate(counts):
    for j1 in lst[pos:pos+cnt]:
        if j1<=0:continue
        j=j1-1
        assert (i<ns)==(j<ns),'Cross-region exclusion unsupported'
        if i<ns:
            ex[i*ns+j][0]=1
            ex[j*ns+i][0]=1
    pos+=cnt
scee=values('SCEE_SCALE_FACTOR')
for section in ('DIHEDRALS_INC_HYDROGEN','DIHEDRALS_WITHOUT_HYDROGEN'):
    data=values(section,int)
    for ai,aj,ak,al,k1 in zip(*(iter(data),)*5):
        if ak<0 or al<0:continue
        i,j=abs(ai)//3,abs(al)//3
        assert (i<ns)==(j<ns),'Cross-region dihedral unsupported'
        if i<ns and scee[k1-1]>0:
            ex[i*ns+j][1]=ex[j*ns+i][1]=1/scee[k1-1]
with a.output.open('w') as f:
    f.write(f'1 {n} {ns} {nt} {a.stride} {int(a.vdw_only)} {a.wq:.17g} {a.wv:.17g}\n')
    for i in range(n):f.write(f'{q[i]:.17g} {2*radii[i]**2:.17g} {types[i]}\n')
    for row in pairs:f.write(' '.join(f'{v:.17g}' for v in row)+'\n')
    for row in ex:f.write(' '.join(f'{v:.17g}' for v in row)+'\n')
print(a.output,n,ns,nt)
