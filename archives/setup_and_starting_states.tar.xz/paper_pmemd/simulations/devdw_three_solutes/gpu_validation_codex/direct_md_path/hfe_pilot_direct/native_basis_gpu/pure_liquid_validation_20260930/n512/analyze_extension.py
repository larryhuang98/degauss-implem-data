"""Combine the prespecified methanol continuation without changing the discard."""
from common import *
from analyze import estimate, classify, R_KCAL, PV_KCAL_PER_A3
import copy

EXT = HERE / 'extension_methanol'

def metrics(rows, paths):
    assert len(rows) == 10000
    assert all(np.isfinite(v) for row in rows for v in row.values())
    d = {'paths': [str(p) for p in paths], 'samples': len(rows),
         'steps': 1100000, 'analyzed_ns': 2.0}
    for key, label in [('temperature', 'TEMP(K)'), ('energy', 'EPtot'),
                       ('density', 'Density'), ('volume', 'VOLUME')]:
        values = np.array([r[label] for r in rows])
        d[key] = float(values.mean())
        if key in ['density', 'energy']:
            d[key + '_early_late'] = [float(values[:5000].mean()), float(values[5000:].mean())]
            d[key + '_extension_early_late'] = [float(values[5000:7500].mean()), float(values[7500:].mean())]
            d[key + '_100ps_blocks'] = [float(values[i:i+500].mean()) for i in range(0, len(values), 500)]
    return d

def main():
    assert (EXT / 'cpu_complete').exists() and (EXT / 'gpu_complete').exists()
    original = json.loads((HERE / 'summary.json').read_text())
    assert original['complete'] and not original['errors']
    data = copy.deepcopy(original)
    system = data['systems']['methanol']
    stationarity = {}
    for engine in EXES:
        for r in range(1, 5):
            base = HERE / 'liquid' / 'methanol' / engine / ('r' + str(r))
            continued = EXT / 'liquid' / 'methanol' / engine / ('r' + str(r))
            assert Path(str(continued) + '.complete').exists()
            extension_rows = [x for x in records(str(continued) + '.out') if x['step'] > 0]
            assert [x['step'] for x in extension_rows] == list(range(100, 500001, 100))
            original_rows = [x for x in records(str(base) + '.out') if x['step'] > 100000]
            assert len(original_rows) == 5000
            d = metrics(original_rows + extension_rows, [base, continued])
            gas_energy = system['gas_replicas'][str(r)]['energy']
            d['hvap'] = gas_energy - d['energy']/NMOLEC + R_KCAL*300 - PV_KCAL_PER_A3*d['volume']/NMOLEC
            system['liquid_replicas'][engine][str(r)] = d
        reps = system['liquid_replicas'][engine]
        system['summary'][engine] = {k: estimate([v[k] for v in reps.values()])
                                      for k in ['density', 'hvap', 'temperature', 'energy']}
        stationarity[engine] = {}
        for span in ['early_late', 'extension_early_late']:
            stationarity[engine][span] = {}
            for k in ['density', 'energy']:
                vals = [(d[k+'_'+span][1] - d[k+'_'+span][0]) / (NMOLEC if k == 'energy' else 1)
                        for d in reps.values()]
                stationarity[engine][span][k] = estimate(vals)
    liq = system['liquid_replicas']
    cpu_density = system['summary']['cpu']['density']['mean']
    for engine in ['spfp', 'dpfp']:
        density_diff = [100*(liq[engine][str(r)]['density']-liq['cpu'][str(r)]['density'])/cpu_density for r in range(1, 5)]
        enthalpy_diff = [-(liq[engine][str(r)]['energy']-liq['cpu'][str(r)]['energy'])/NMOLEC
                         - PV_KCAL_PER_A3*(liq[engine][str(r)]['volume']-liq['cpu'][str(r)]['volume'])/NMOLEC for r in range(1, 5)]
        system['comparison'][engine] = {'density_relative_percent': classify(density_diff, .5),
                                         'hvap_kcal_mol': classify(enthalpy_diff, .10)}
    data.update(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), extension_segments=12,
                original_summary_sha256=sha(HERE/'summary.json'),
                extension_decision_sha256=sha(EXT/'DECISION.json'),
                analyzed_liquid_ns={'methanol': 2.0, 'ethanol': 1.0, 'benzene': 1.0})
    dump(EXT/'summary.json', data)
    dump(EXT/'stationarity.json', stationarity)
    stamp(EXT/'analysis_complete')
    print(json.dumps({'complete': True, 'extension_segments': 12, 'methanol': system['comparison']}, indent=2))

if __name__ == '__main__':
    main()
