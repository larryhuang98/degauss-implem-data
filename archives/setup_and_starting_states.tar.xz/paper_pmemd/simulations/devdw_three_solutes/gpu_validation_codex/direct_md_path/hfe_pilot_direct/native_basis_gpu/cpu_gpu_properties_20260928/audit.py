"""Read-only integrity audit; missing backends stay explicitly incomplete."""
from common import *


def numeric_summary(text, flag):
    match = re.search(r'^' + re.escape(flag) + r'\s*\n((?:[ \t]+[-+\d.Ee]+(?:[ \t]+[-+\d.Ee]+)*[ \t]*\n)+)', text, re.M)
    if not match:
        raise ValueError('missing printed parameter: ' + flag)
    return np.array([float(x) for x in match.group(1).split()])


def finite_netcdf(path, natom, trajectory=False, expected_frames=None):
    result = {}
    with Dataset(path) as f:
        coords = f['coordinates']
        assert coords.shape[-2:] == (natom, 3), (path, coords.shape)
        if trajectory:
            assert coords.shape[0] == expected_frames, (path, coords.shape[0], expected_frames)
        for name in ['coordinates', 'velocities', 'cell_lengths', 'cell_angles', 'time']:
            if name not in f.variables:
                continue
            v = f[name]
            if trajectory and v.ndim and v.dimensions[0] == 'frame':
                for start in range(0, len(v), 100):
                    a = np.ma.asarray(v[start:start + 100])
                    assert not np.any(np.ma.getmaskarray(a)), (path, name, 'masked')
                    assert np.isfinite(a).all(), (path, name, 'nonfinite')
            else:
                a = np.ma.asarray(v[:])
                assert not np.any(np.ma.getmaskarray(a)), (path, name, 'masked')
                assert np.isfinite(a).all(), (path, name, 'nonfinite')
        if trajectory:
            t = np.asarray(f['time'][:], float)
            assert np.all(np.diff(t) > 0), path
            result.update(frames=len(t), first_time_ps=float(t[0]), last_time_ps=float(t[-1]),
                          spacing_ps=float(np.median(np.diff(t))))
        box = np.asarray(f['cell_lengths'][:], float)
        assert np.all(box > 0), path
        angles = np.asarray(f['cell_angles'][:], float)
        assert np.all(np.abs(angles - 90) < 1e-5), (path, 'nonorthorhombic')
        result.update(min_box_A=float(box.min()), max_box_A=float(box.max()))
    return result


def production_audit(prefix):
    sol, engine, name = prefix.parts[-3:]
    ensemble = name.split('_')[0]
    steps = 25000 if ensemble == 'nve' else 120000
    natom = len(values((HERE/'systems'/sol/'reference.prmtop').read_text(), 'MASS'))
    result = json.loads(Path(str(prefix) + '.run.json').read_text())
    assert result['returncode'] == 0, prefix
    text = Path(str(prefix) + '.out').read_text()
    assert not re.search(r'\b(?:nan|infinity)\b|\*{5,}', text, re.I), prefix
    rows = records(str(prefix) + '.out')
    # Initial state may be printed at step 0; only positive steps are samples.
    rows = [r for r in rows if r['step'] > 0]
    assert [r['step'] for r in rows] == list(range(50, steps + 1, 50)), prefix
    for row in rows:
        assert all(np.isfinite(v) for v in row.values()), prefix
        for key in ['Etot', 'EKtot', 'EPtot', 'TEMP(K)']:
            assert key in row, (prefix, key)
        if ensemble == 'npt':
            assert row['Density'] > 0 and row['VOLUME'] > 0, prefix
    printed = {flag: numeric_summary(text, flag) for flag in
               ['GAUSS_RADII_LIST', 'DOUBLE_EXPONENTIAL_A', 'DOUBLE_EXPONENTIAL_C']}
    for flag, target in zip(printed, [.2, 18.17, 3.65]):
        assert np.allclose(printed[flag], target, rtol=0, atol=1e-6), (prefix, flag)
    result = {'steps': rows[-1]['step'], 'thermo_records': len(rows),
              'analyzed_records': sum(r['step'] > 20000 for r in rows) if ensemble != 'nve' else len(rows),
              'restart': finite_netcdf(str(prefix) + '.rst', natom),
              'printed_parameters': {k: v.tolist() for k, v in printed.items()}}
    if ensemble != 'nve':
        stride = 50 if ensemble == 'nvt' else 500
        info = finite_netcdf(str(prefix) + '.nc', natom, True, steps // stride)
        assert abs(info['spacing_ps'] - stride * .002) < 1e-3, prefix
        assert abs(info['last_time_ps'] - rows[-1]['time_ps']) < 1e-3, prefix
        result['trajectory'] = info
        if ensemble == 'nvt':
            with Dataset(str(prefix) + '.nc') as f:
                boxes = np.asarray(f['cell_lengths'][:], float)
                assert np.max(np.abs(boxes - boxes[0])) < 1e-5, prefix
    basis = Path(str(prefix) + '.basis')
    if engine != 'cpu' and ensemble == 'nvt':
        b = np.loadtxt(basis)
        assert b.shape == (steps // 500, 10), (prefix, b.shape)
        assert np.array_equal(b[:, 0], np.arange(500, steps + 1, 500)), prefix
        assert np.isfinite(b).all(), prefix
        header = basis.read_text().splitlines()[:4]
        assert any('wq=1 wv=1 stride=500' in x for x in header), prefix
        result['basis_records'] = len(b)
    elif ensemble == 'npt':
        assert not basis.exists(), (prefix, 'unexpected NPT collector')
    return result


def main():
    audit = {'executables': {}, 'production': {}, 'fixed': {}, 'fixed_matched_mesh': {}, 'errors': {}}
    manifest = json.loads((HERE/'manifest.json').read_text())
    for engine, item in manifest['executables'].items():
        h = hashlib.sha256()
        with Path(item['path']).open('rb') as f:
            for chunk in iter(lambda: f.read(4 << 20), b''):
                h.update(chunk)
        audit['executables'][engine] = {'sha256': h.hexdigest(), 'matches_manifest': h.hexdigest() == item['sha256']}
        if h.hexdigest() != item['sha256']:
            audit['errors']['executable/' + engine] = 'manifest hash mismatch'
    for marker in sorted((HERE/'production').glob('*/*/*.complete')):
        prefix = marker.with_suffix('')
        key = str(prefix.relative_to(HERE/'production'))
        try:
            audit['production'][key] = production_audit(prefix)
        except Exception as e:
            audit['errors'][key] = str(e)
    fixed_paths = list((HERE/'fixed').glob('*/*/*.result.json'))
    fixed_paths += list((HERE/'fixed_matched_mesh').glob('*/*/*.result.json'))
    for p in sorted(fixed_paths):
        directory = p.parents[2].name
        key = str(p.relative_to(HERE/directory))
        try:
            r = json.loads(p.read_text())
            assert r['last_record']['step'] == 20, p
            assert all(np.isfinite(v) for v in r['last_record'].values()), p
            f = np.load(str(p).replace('.result.json', '.forces.npy'))
            assert np.isfinite(f).all(), p
            with Dataset(r['coordinate']) as initial:
                v0 = np.asarray(initial['velocities'][:], float)
                assert np.all(v0 == 0), (p, 'force extraction requires zero initial velocities')
            # Confirm all printed heterogeneous entries, not only the first value.
            if p.parent.name == 'heterogeneous':
                top = Path(r['topology']).read_text()
                out = Path(str(p).replace('.result.json', '.out')).read_text()
                for flag in ['GAUSS_RADII_LIST', 'DOUBLE_EXPONENTIAL_A', 'DOUBLE_EXPONENTIAL_C',
                             'DOUBLE_EXPONENTIAL_EPS0', 'DOUBLE_EXPONENTIAL_RMIN']:
                    observed = numeric_summary(out, flag)
                    expected = values(top, flag)[:len(observed)]
                    assert np.allclose(observed, expected, rtol=2e-8, atol=1e-8), (p, flag)
            if directory == 'fixed_matched_mesh':
                expected_mesh = 64 if key.split('/')[0].endswith('_large') else 32
                assert r['mesh'] == [expected_mesh]*3, (p, 'mesh mismatch')
            audit[directory][key] = {'atoms': len(f), 'finite': True}
        except Exception as e:
            audit['errors'][directory+'/' + key] = str(e)
    audit['counts'] = {e: {'production': sum('/' + e + '/' in k for k in audit['production']),
                            'fixed': sum(k.endswith('/' + e + '.result.json') for k in audit['fixed']),
                            'matched_mesh': sum(k.endswith('/' + e + '.result.json') for k in audit['fixed_matched_mesh'])}
                       for e in ['cpu', 'spfp', 'dpfp']}
    audit['complete'] = all(v['production'] == 27 and v['fixed'] == 33 and v['matched_mesh'] == 33 for v in audit['counts'].values()) and not audit['errors']
    dump_json(HERE/'integrity_audit.json', audit)
    print(json.dumps({k: audit[k] for k in ['counts', 'complete', 'errors']}, indent=2))
    if audit['errors']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
