from common import *
import parmed as pmd
import shutil

def main():
    old=json.loads((PREV/'manifest.json').read_text())
    manifest={'date_local':'2026-09-30','nmolecules':NMOLEC,'executables':{},'systems':{}}
    for e,p in EXES.items():
        h=sha(p);assert h==old['executables'][e]['sha256'],(e,'binary changed')
        manifest['executables'][e]={'path':str(p),'sha256':h}
    for sol,rho in zip(SOLUTES,[.75,.75,.85]):
        s=HERE/'systems'/sol;s.mkdir(parents=True,exist_ok=True)
        src=SIM/'build'/sol
        orig=pmd.load_file(str(src/(sol+'_solv.prmtop')),xyz=str(src/(sol+'_solv.inpcrd')))
        # Convert the stripped AmberParm to Structure, rebuilding compact LJ
        # tables rather than retaining unused water-type entries in old ParmEd.
        stripped=orig[':1'];stripped.box=None
        mono=stripped.copy(pmd.Structure)
        n=len(mono.atoms); mass=sum(a.mass for a in mono.atoms);q=sum(a.charge for a in mono.atoms)
        # Remove the existing mol2 charge-rounding residual before replication.
        assert abs(q)<2e-4,(sol,q)
        for atom in mono.atoms:atom.charge-=q/n
        mono.coordinates-=np.mean(mono.coordinates,axis=0)
        # Reuse exactly the completed gas-reference topologies and coordinates.
        for name in ['gas.prmtop','gas.rst7','gasbox.prmtop','gasbox.rst7','monomer.pdb']:
            shutil.copy2(HERE.parent/'systems'/sol/name,s/name)
        gas=pmd.load_file(str(s/'gas.prmtop'))
        assert np.allclose([a.charge for a in gas.atoms],[a.charge for a in mono.atoms],atol=1e-8)

        L=(NMOLEC*mass/0.602214076/rho)**(1/3)
        pack=f'''tolerance 2.0
filetype pdb
output packed.pdb
seed 91237
structure monomer.pdb
 number {NMOLEC}
 inside box 1.2 1.2 1.2 {L-1.2:.8f} {L-1.2:.8f} {L-1.2:.8f}
end structure
'''
        (s/'packmol.in').write_text(pack)
        with (s/'packmol.in').open() as fi,(s/'packmol.log').open('w') as fo:
            subprocess.run(['/home8/larry/amber25/bin/packmol'],stdin=fi,stdout=fo,stderr=subprocess.STDOUT,cwd=s,check=True)
        coords=pmd.load_file(str(s/'packed.pdb')).coordinates
        assert coords.shape==(n*NMOLEC,3)
        liq=mono*NMOLEC;liq.coordinates=coords;liq.box=[L,L,L,90,90,90]
        liq.save(str(s/'liquid.prmtop'),overwrite=False)
        liq.save(str(s/'packed.rst7'),overwrite=False)
        check=pmd.load_file(str(s/'liquid.prmtop'))
        assert len(check.residues)==NMOLEC
        assert list(check.parm_data['ATOMS_PER_MOLECULE'])==[n]*NMOLEC
        for k in ['charge','mass','rmin','epsilon']:
            assert np.allclose([getattr(a,k) for a in check.atoms],[getattr(a,k) for a in mono.atoms]*NMOLEC,rtol=1e-7,atol=1e-8),(sol,k)
        assert [a.type for a in check.atoms]==[a.type for a in mono.atoms]*NMOLEC
        for i in range(n):
            for j in range(n):
                ia=orig.parm_data['ATOM_TYPE_INDEX'][i]-1;ja=orig.parm_data['ATOM_TYPE_INDEX'][j]-1
                ib=check.parm_data['ATOM_TYPE_INDEX'][i]-1;jb=check.parm_data['ATOM_TYPE_INDEX'][j]-1
                ka=orig.parm_data['NONBONDED_PARM_INDEX'][orig.ptr('ntypes')*ia+ja]-1
                kb=check.parm_data['NONBONDED_PARM_INDEX'][check.ptr('ntypes')*ib+jb]-1
                for flag in ['LENNARD_JONES_ACOEF','LENNARD_JONES_BCOEF']:
                    assert np.isclose(orig.parm_data[flag][ka],check.parm_data[flag][kb],rtol=1e-7,atol=1e-8),(sol,i,j,flag)
        for k in ['bonds','angles','dihedrals']:
            assert len(getattr(check,k))==NMOLEC*len(getattr(mono,k)),(sol,k)
        manifest['systems'][sol]={'natom':n*NMOLEC,'natom_monomer':n,'mass_monomer':mass,'original_net_charge_monomer':q,
          'charge_correction_per_atom':-q/n,'net_charge_monomer':sum(a.charge for a in mono.atoms),'initial_box':L,
          'source_topology':str(src/(sol+'_solv.prmtop')),'source_sha256':sha(src/(sol+'_solv.prmtop')),
          'liquid_top_sha256':sha(s/'liquid.prmtop'),'gas_top_sha256':sha(s/'gas.prmtop'),'gasbox_top_sha256':sha(s/'gasbox.prmtop')}
    manifest['shared_gas_directory']=str(HERE.parent/'gas')
    (HERE/'gas').symlink_to('../gas',target_is_directory=True)
    manifest['protocol_sha256']=sha(HERE/'PROTOCOL.md')
    dump(HERE/'manifest.json',manifest);stamp(HERE/'prepared')

if __name__=='__main__':main()
