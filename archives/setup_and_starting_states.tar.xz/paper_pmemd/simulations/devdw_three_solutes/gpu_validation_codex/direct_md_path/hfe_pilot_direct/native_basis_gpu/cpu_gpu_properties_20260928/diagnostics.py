"""Make diagnostic plots and replica summaries without filling missing backends."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import t as student_t
from common import *

SOLUTES = ['methanol', 'ethanol', 'benzene']
ENGINES = ['cpu', 'spfp', 'dpfp']
COLORS = {'cpu': '#252525', 'spfp': '#1976b5', 'dpfp': '#d25c21'}
DEST = HERE/'diagnostics'
DEST.mkdir(exist_ok=True)
plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})


def interval(v):
    v = np.asarray(v, float)
    if len(v) < 2:
        return {'mean': float(v.mean()), 'n': len(v), 'ci95': None}
    half = student_t.ppf(.975, len(v)-1)*v.std(ddof=1)/np.sqrt(len(v))
    return {'mean': float(v.mean()), 'n': len(v),
            'ci95': [float(v.mean()-half), float(v.mean()+half)]}


def save(fig, name):
    fig.savefig(DEST/(name+'.png'), dpi=180, bbox_inches='tight')
    fig.savefig(DEST/(name+'.pdf'), bbox_inches='tight')
    plt.close(fig)


def main():
    metrics = json.loads((HERE/'property_metrics.json').read_text())
    counts = {e: sum(x is not None for group in metrics.values() for x in group[e]) for e in ENGINES}
    status = 'CPU/GPU comparison' if all(n == 27 for n in counts.values()) else 'INCOMPLETE: '+', '.join(f'{e.upper()} {n}/27' for e, n in counts.items())
    summaries = {}
    for key, group in metrics.items():
        summaries[key] = {}
        for engine, rows in group.items():
            rows = [x for x in rows if x is not None]
            if rows:
                summaries[key][engine] = {k: interval([x[k] for x in rows]) for k in rows[0] if k != 'samples'}
    dump_json(HERE/'replica_summary.json', summaries)

    for category, specs in [
        ('msd', [('msd_time_ps', 'water_msd', 'Water oxygen MSD', r'MSD ($\AA^2$)'),
                 ('msd_time_ps', 'solute_msd', 'Solute COM MSD', r'MSD ($\AA^2$)')]),
        ('orientation', [('water_c2_t', 'water_c2', 'Water dipole', r'$C_2(t)$'),
                         ('solute_c2_t', 'solute_c2', 'Solute orientation', r'$C_2(t)$')])]:
        fig, axs = plt.subplots(2, 3, figsize=(12, 6), constrained_layout=True)
        for col, sol in enumerate(SOLUTES):
            for row, (xt, yt, title, ylabel) in enumerate(specs):
                ax = axs[row, col]
                for engine in ENGINES:
                    traces = []
                    for rep in range(1, 5):
                        p = HERE/'production'/sol/engine/f'nvt_r{rep}.analysis.npz'
                        if p.exists():
                            with np.load(p) as data:
                                x, y = data[xt], data[yt]
                                traces.append(y.copy())
                            ax.plot(x, y, color=COLORS[engine], lw=.6, alpha=.22)
                    if traces:
                        ax.plot(x, np.mean(traces, axis=0), color=COLORS[engine], lw=1.8,
                                label=f'{engine.upper()} (n={len(traces)})')
                if category == 'msd':
                    ax.axvspan(5 if row == 0 else 10, 20 if row == 0 else 40, color='#cccccc', alpha=.16)
                else:
                    ax.axhline(0, lw=.6, color='#aaaaaa')
                ax.set(title=f'{sol.capitalize()}: {title}', xlabel='Lag time (ps)', ylabel=ylabel)
                if row == 0 and col == 0:
                    ax.legend(fontsize=8)
        fig.suptitle(status+'\nThin lines: individual replicas; thick lines: replica means', fontsize=11)
        save(fig, category)

    fig, axs = plt.subplots(2, 3, figsize=(12, 6), constrained_layout=True)
    for col, sol in enumerate(SOLUTES):
        natom = len(values((HERE/'systems'/sol/'reference.prmtop').read_text(), 'MASS'))
        for engine in ENGINES:
            traces = []
            for rep in range(1, 5):
                p = HERE/'production'/sol/engine/f'nvt_r{rep}.analysis.npz'
                if p.exists():
                    with np.load(p) as data:
                        x, y = data['rdf_r'], data['rdf']
                        traces.append(y.copy())
                    axs[0,col].plot(x, y, color=COLORS[engine], lw=.6, alpha=.22)
            if traces:
                axs[0,col].plot(x, np.mean(traces, axis=0), color=COLORS[engine], label=engine.upper())
            p = HERE/'production'/sol/engine/'nve_r1'
            if Path(str(p)+'.complete').exists():
                rows = records(str(p)+'.out')
                t = np.array([r['time_ps'] for r in rows]); t -= t[0]
                energy = np.array([r['Etot'] for r in rows]); energy = (energy-energy[0])/natom
                axs[1,col].plot(t, energy, color=COLORS[engine], lw=.7, label=engine.upper())
        axs[0,col].set(title=sol.capitalize()+': water O–O RDF', xlabel=r'Distance ($\AA$)', ylabel='g(r)')
        axs[1,col].set(title=sol.capitalize()+': NVE, 2 fs', xlabel='Elapsed time (ps)', ylabel=r'$\Delta E$/atom (kcal mol$^{-1}$)')
        axs[1,col].ticklabel_format(axis='y', style='sci', scilimits=(0,0))
    axs[0,0].legend(fontsize=8)
    fig.suptitle(status+'\nStructure and energy-conservation diagnostics', fontsize=11)
    save(fig, 'structure_nve')
    print(json.dumps({'counts': counts, 'plots': str(DEST)}, indent=2))


if __name__ == '__main__':
    main()
