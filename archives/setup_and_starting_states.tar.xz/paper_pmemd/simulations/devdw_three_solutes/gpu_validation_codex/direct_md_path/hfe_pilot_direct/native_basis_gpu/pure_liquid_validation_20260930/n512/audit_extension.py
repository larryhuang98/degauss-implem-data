"""Independently audit continuation files and combined averages."""
from common import *
from scipy.stats import t

EXT = HERE / 'extension_methanol'

def parse(path):
    entries = []; entry = None
    for line in Path(path).read_text().splitlines():
        if 'A V E R A G E S' in line:
            break
        if re.match(r'^\s*NSTEP\s*=', line):
            if entry is not None:
                entries.append(entry)
            entry = {}
        if entry is not None:
            for label in ['NSTEP','TIME(PS)','TEMP(K)','EPtot','BOND','ANGLE','DIHED','1-4 NB','1-4 EEL','VDWAALS','EELEC','EHBOND','RESTRAINT','VOLUME','Density']:
                m = re.search(r'(?<![A-Za-z0-9_-])'+re.escape(label)+r'\s*=\s*([-+0-9.Ee]+)', line)
                if m:
                    entry[label] = float(m[1])
    if entry is not None:
        entries.append(entry)
    return entries

def main():
    manifest = json.loads((HERE/'manifest.json').read_text())
    original = json.loads((HERE/'summary.json').read_text())
    data = json.loads((EXT/'summary.json').read_text())
    prior_audit = json.loads((HERE/'integrity_audit.json').read_text())
    assert prior_audit['count'] == 48 and prior_audit['errors'] == []
    assert data['original_summary_sha256'] == sha(HERE/'summary.json')
    for sol in ['ethanol', 'benzene']:
        assert data['systems'][sol] == original['systems'][sol]
    assert data['systems']['methanol']['gas_replicas'] == original['systems']['methanol']['gas_replicas']
    mass = manifest['systems']['methanol']['mass_monomer']*NMOLEC
    checks = []
    for engine in EXES:
        assert sha(EXES[engine]) == manifest['executables'][engine]['sha256']
        for r in range(1, 5):
            base = HERE/'liquid'/'methanol'/engine/('r'+str(r))
            p = EXT/'liquid'/'methanol'/engine/('r'+str(r))
            info = json.loads(Path(str(p)+'.run.json').read_text())
            prov = json.loads(Path(str(p)+'.continuation.json').read_text())
            assert info['returncode'] == 0 and info['binary_sha256'] == sha(EXES[engine])
            assert prov['previous_restart_sha256'] == sha(str(base)+'.rst')
            assert info['command'][info['command'].index('-c')+1] == str(base)+'.rst'
            assert prov['topology_sha256'] == sha(HERE/'systems'/'methanol'/'liquid.prmtop')
            inp = Path(str(p)+'.in').read_text()
            for required in ['nstlim=500000','dt=0.002','irest=1','ntx=5','ntc=2','ntf=1','tol=0.0000001','ntt=3','gamma_ln=2','temp0=300','ntpr=100','icfe=0','cut=8.0','ips=0','ntb=2','ntp=1','barostat=2','pres0=1.0']:
                assert required in inp, (p, required)
            check_parameters(p)
            rows = [x for x in parse(str(p)+'.out') if x['NSTEP'] > 0]
            assert [int(x['NSTEP']) for x in rows] == list(range(100, 500001, 100))
            assert abs(rows[0]['TIME(PS)']-1200.2) < 1e-6 and abs(rows[-1]['TIME(PS)']-2200) < 1e-6
            assert np.allclose(np.diff([x['TIME(PS)'] for x in rows]), .2, atol=1e-7)
            assert all(np.isfinite(v) for row in rows for v in row.values())
            terms = ['BOND','ANGLE','DIHED','1-4 NB','1-4 EEL','VDWAALS','EELEC','EHBOND','RESTRAINT']
            residual = max(abs(x['EPtot']-sum(x[k] for k in terms)) for x in rows)
            assert residual < .002
            for x in rows:
                rho_lo = mass/(.602204*(x['VOLUME']+.00005))
                rho_hi = mass/(.602204*(x['VOLUME']-.00005))
                assert rho_lo <= x['Density']+.00005+1e-12 and rho_hi >= x['Density']-.00005-1e-12
            combined = [x for x in parse(str(base)+'.out') if x['NSTEP'] > 100000] + rows
            assert len(combined) == 10000
            cached = data['systems']['methanol']['liquid_replicas'][engine][str(r)]
            for key, label in [('energy','EPtot'),('temperature','TEMP(K)'),('density','Density'),('volume','VOLUME')]:
                assert abs(sum(x[label] for x in combined)/len(combined)-cached[key]) < 1e-8
            with Dataset(str(p)+'.rst') as f:
                for key in ['coordinates','velocities','cell_lengths','cell_angles']:
                    assert np.isfinite(f[key][:]).all()
            with Dataset(str(p)+'.nc') as f:
                assert len(f.dimensions['atom']) == 3072 and len(f.dimensions['frame']) == 500
                assert np.isfinite(f['coordinates'][:]).all()
                assert np.isfinite(f['cell_lengths'][:]).all() and np.all(f['cell_lengths'][:] > 0)
                assert np.allclose(f['cell_angles'][:], 90)
            checks.append({'engine':engine, 'replica':r, 'max_energy_sum_residual':residual,
                           'output_sha256':sha(str(p)+'.out'), 'restart_sha256':sha(str(p)+'.rst')})
    # Recalculate the reported difference CIs independently from the stored replica means.
    s = data['systems']['methanol']; liq = s['liquid_replicas']
    cpu_density = sum(d['density'] for d in liq['cpu'].values())/4
    for engine in ['spfp','dpfp']:
        for key in ['density_relative_percent','hvap_kcal_mol']:
            if key.startswith('density'):
                vals = [100*(liq[engine][str(r)]['density']-liq['cpu'][str(r)]['density'])/cpu_density for r in range(1,5)]
            else:
                vals = [liq[engine][str(r)]['hvap']-liq['cpu'][str(r)]['hvap'] for r in range(1,5)]
            m = sum(vals)/4
            variance = sum((v-m)**2 for v in vals)/3
            half = float(t.ppf(.975,3))*math_sqrt(variance/4)
            record = s['comparison'][engine][key]
            assert abs(m-record['mean']) < 1e-10
            assert np.allclose([m-half,m+half],record['ci95'],atol=1e-10,rtol=0)
    dump(EXT/'integrity_audit.json', {'original_trajectories':48,'extension_segments':checks,'count':len(checks),'errors':[]})
    stamp(EXT/'audit_complete')
    print('Audited 12 continuation segments and combined averages; original 48 trajectories retained.')

def math_sqrt(v):
    return v**.5

if __name__ == '__main__':
    main()
