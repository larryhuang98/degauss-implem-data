from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

data=json.loads((HERE/'summary.json').read_text());assert not data['errors']
out=HERE/'figures';out.mkdir(exist_ok=True)
colors={'cpu':'#707C86','spfp':'#087E8B','dpfp':'#365DA0'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,axs=plt.subplots(1,2,figsize=(9,3.8),layout='constrained')
for ax,key,label in zip(axs,['density','hvap'],[r'Density (g cm$^{-3}$)',r'$\Delta H_{vap}$ (kcal mol$^{-1}$)']):
    for j,e in enumerate(EXES):
        for i,sol in enumerate(SOLUTES):
            d=data['systems'][sol]['summary'][e][key]
            if not d['n']:continue
            err=None if d['ci95'] is None else [[d['mean']-d['ci95'][0]],[d['ci95'][1]-d['mean']]]
            ax.errorbar(i+(j-1)*.15,d['mean'],yerr=err,fmt='o',ms=5,capsize=3,color=colors[e],label=e.upper() if i==0 else None)
    ax.set_xticks(range(3),[s.capitalize() for s in SOLUTES]);ax.set_ylabel(label);ax.legend(frameon=False)
fig.savefig(out/'density_hvap.png',dpi=220);fig.savefig(out/'density_hvap.pdf');plt.close(fig)
fig,axs=plt.subplots(3,2,figsize=(10,8),layout='constrained')
for i,sol in enumerate(SOLUTES):
    for e in EXES:
        for j,(r,d) in enumerate(data['systems'][sol]['liquid_replicas'][e].items()):
            for ax,key in zip(axs[i],['density','energy']):
                y=np.array(d[key+'_100ps_blocks'])/(NMOLEC if key=='energy' else 1)
                ax.plot(np.arange(len(y))*.1+.25,y,color=colors[e],alpha=.55,lw=.8,label=e.upper() if j==0 else None)
    axs[i,0].set_ylabel(sol.capitalize()+'\nDensity (g cm$^{-3}$)')
    axs[i,1].set_ylabel(r'$U/N$ (kcal mol$^{-1}$)')
    for ax in axs[i]:ax.set_xlabel('Time (ns)');ax.legend(frameon=False,ncol=3,fontsize=8)
fig.savefig(out/'liquid_blocks.png',dpi=180);fig.savefig(out/'liquid_blocks.pdf');plt.close(fig)
