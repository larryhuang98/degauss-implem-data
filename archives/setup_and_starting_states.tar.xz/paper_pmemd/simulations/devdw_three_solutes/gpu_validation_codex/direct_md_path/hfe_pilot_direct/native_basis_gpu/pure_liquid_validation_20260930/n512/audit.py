"""Independent output identities and trajectory integrity for paper use."""
from common import *

def parse_independently(path):
    entries=[];entry=None
    for line in Path(path).read_text().splitlines():
        if 'A V E R A G E S' in line:break
        if re.match(r'^\s*NSTEP\s*=',line):
            if entry is not None:entries.append(entry)
            entry={}
        if entry is not None:
            for label in ['NSTEP','TIME(PS)','TEMP(K)','EPtot','BOND','ANGLE','DIHED','1-4 NB','1-4 EEL','VDWAALS','EELEC','EHBOND','RESTRAINT','VOLUME','Density']:
                m=re.search(r'(?<![A-Za-z0-9_-])'+re.escape(label)+r'\s*=\s*([-+0-9.Ee]+)',line)
                if m:entry[label]=float(m[1])
    if entry is not None:entries.append(entry)
    return entries

manifest=json.loads((HERE/'manifest.json').read_text())
summary=json.loads((HERE/'summary.json').read_text())
assert summary['complete'] and not summary['errors']
checked=[]
for sol in SOLUTES:
    mass=manifest['systems'][sol]['mass_monomer']*NMOLEC
    entries=[('gas','cpu',r,1100000,HERE/'gas'/sol/('r'+str(r))) for r in range(1,5)]
    entries += [('liquid',e,r,600000,HERE/'liquid'/sol/e/('r'+str(r))) for e in EXES for r in range(1,5)]
    for phase,engine,r,steps,p in entries:
        audit={'solute':sol,'phase':phase,'engine':engine,'replica':r,'path':str(p)}
        runinfo=json.loads(Path(str(p)+'.run.json').read_text())
        assert runinfo['returncode']==0 and runinfo['binary_sha256']==sha(EXES[engine]),p
        inp=Path(str(p)+'.in').read_text()
        for required in ['dt=0.002','ntc=2','ntf=1','tol=0.0000001','ntt=3','gamma_ln=2','temp0=300','ntpr=100','icfe=0']:
            assert required in inp,(p,required)
        assert ('cut=400' if phase=='gas' else 'cut=8.0') in inp,p
        assert ('ips=1' if phase=='gas' else 'ips=0') in inp,p
        assert not any('AllowSmallBox' in a for a in runinfo['command']),p
        check_parameters(p,gas=phase=='gas')
        rows=parse_independently(str(p)+'.out')
        used=[x for x in rows if x['NSTEP']>100000]
        assert [int(x['NSTEP']) for x in used]==list(range(100100,steps+1,100)),p
        assert all(np.isfinite(v) for row in rows for v in row.values()),p
        assert np.allclose(np.diff([x['TIME(PS)'] for x in used]),.2,atol=1e-7),p
        cached=summary['systems'][sol]['gas_replicas'][str(r)] if phase=='gas' else summary['systems'][sol]['liquid_replicas'][engine][str(r)]
        for key,label in [('energy','EPtot'),('temperature','TEMP(K)')]+([] if phase=='gas' else [('density','Density'),('volume','VOLUME')]):
            calculated=sum(x[label] for x in used)/len(used)
            assert abs(calculated-cached[key])<1e-8,(p,key,calculated,cached[key])
        terms=['BOND','ANGLE','DIHED','1-4 NB','1-4 EEL','VDWAALS','EELEC','EHBOND','RESTRAINT']
        audit['max_energy_sum_residual']=max(abs(x['EPtot']-sum(x[k] for k in terms)) for x in used)
        assert audit['max_energy_sum_residual']<.002,(p,audit)
        if phase=='liquid':
            audit['max_density_mass_volume_residual']=max(abs(x['Density']-mass*1.66053906660/x['VOLUME']) for x in used)
            # runmd.F90 uses mass/(0.602204*V); runfiles.F90 prints density
            # and volume to four decimal places. Check overlapping rounding
            # intervals with that exact conversion, retaining the SI-constant
            # residual above as a separate diagnostic. This is an output-format
            # identity check, not the prespecified +/-0.5% equivalence margin.
            audit['max_density_amber_mass_volume_residual']=max(abs(x['Density']-mass/(.602204*x['VOLUME'])) for x in used)
            for x in used:
                rho_lo=mass/(.602204*(x['VOLUME']+0.00005))
                rho_hi=mass/(.602204*(x['VOLUME']-0.00005))
                assert rho_lo <= x['Density']+0.00005+1e-12 and rho_hi >= x['Density']-0.00005-1e-12,(p,x,'density rounding identity')
        with Dataset(str(p)+'.rst') as f:
            for key in ['coordinates','velocities','cell_lengths','cell_angles']:assert np.isfinite(f[key][:]).all(),(p,key)
        with Dataset(str(p)+'.nc') as f:
            n=manifest['systems'][sol]['natom_monomer'] if phase=='gas' else manifest['systems'][sol]['natom']
            assert len(f.dimensions['atom'])==n,(p,'atoms')
            assert len(f.dimensions['frame'])==steps//(5000 if phase=='gas' else 1000),(p,'frames')
            assert np.isfinite(f['coordinates'][:]).all(),p
            cells=np.asarray(f['cell_lengths'][:]);angles=np.asarray(f['cell_angles'][:])
            assert np.isfinite(cells).all() and np.all(cells>0) and np.allclose(angles,90),p
            audit['box_length_range_angstrom']=[float(cells.min()),float(cells.max())]
            if phase=='gas':assert np.allclose(cells,1000),p
        checked.append(audit)
dump(HERE/'integrity_audit.json',{'trajectories':checked,'count':len(checked),'errors':[]})
assert len(checked)==48
stamp(HERE/'audit_complete')
print('Audited',len(checked),'complete trajectories with no integrity errors.')
