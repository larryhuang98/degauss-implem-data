from production import force_case
from common import *
results={}
for sol in SOLUTES:
    results[sol]={}
    for r in [1,2,3,4]:
        coord=HERE/'gas'/sol/('r'+str(r)+'.rst')
        assert coord.with_suffix('.complete').exists(),coord
        e1,f1=force_case('cpu',sol,True,200,coordinate=coord,tag='r'+str(r)+'_')
        e2,f2=force_case('cpu',sol,True,400,coordinate=coord,tag='r'+str(r)+'_')
        d={'energy_abs_difference':abs(e1-e2),'force_rms_difference':float(np.sqrt(np.mean((f1-f2)**2)))}
        d['passed']=bool(d['energy_abs_difference']<.001 and d['force_rms_difference']<.0001)
        results[sol][r]=d
dump(HERE/'gas_sample_check.json',results)
assert all(d['passed'] for s in results.values() for d in s.values()),results
stamp(HERE/'gas_sample_check_complete')
