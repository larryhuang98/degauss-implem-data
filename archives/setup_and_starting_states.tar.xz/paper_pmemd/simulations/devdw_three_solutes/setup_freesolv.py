#!/usr/bin/env python3
"""Mobley's FreeSolv protocol, transcribed for AMBER.

Taken from FreeSolv gromacs_mdpfiles/DG_mdp (prod.X.mdp and the three
equilibration files).  The pieces that carry over:

  20 windows   electrostatics off over lambda 0, 0.25, 0.5, 0.75, 1.0 with the
               van der Waals interaction untouched, then van der Waals off over
               0.05 ... 1.0.  AMBER scales both channels with one clambda, so
               each stage is run as its own leg.
  5 ns/window  2,500,000 steps at 2 fs.
  equilibration 3 stages of 25,000 steps (NVT, NPT, NPT) at that window's lambda.
  nonbonded    rlist/rcoulomb 1.2 nm, van der Waals switched 0.9 -> 1.0 nm,
               PME order 6, ewald tolerance 1e-6, dispersion correction on.
  softcore     Beutler-style, sc-alpha 0.5, applied to van der Waals only
               (sc-coul = no), which is AMBER's ifsc=1 with charges already off.

GROMACS switches the van der Waals between 0.9 and 1.0 nm; AMBER has no vdW
switch with PME, so the closest match is a 10 A cutoff with the analytic
dispersion correction, and that difference is recorded rather than hidden.
"""
from __future__ import annotations
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUILD, RUNS = HERE / "build", HERE / "runs_freesolv"
SOLUTES = ("benzene", "methanol", "ethanol")
NREP = 3

import math
ELEC = [0.00, 0.25, 0.50, 0.75, 1.00]
ONE  = [k/19 for k in range(20)]          # one-step: both channels on one lambda

# Direct DEGAUSS scaling keeps the pair energies finite but large at contact, and
# the sampled separations change fastest as the solute vanishes.  Uniform spacing
# leaves the last window with no phase-space overlap, so the windows are placed
# exponentially toward the decoupled end, as in Paper I.  The concentration is
# a = 4, as in Paper I.  The requirement is set by the DE contact value: a water
# sitting on the vanishing solute contributes (1-lambda)*u(0) with u(0) of order
# 2e6 kcal/mol, so the final spacing must reach ~1e-6 for that term to fall below
# a few kT.  a = 3 leaves it at 2e-4, which is still several hundred kT and
# destroys the overlap of the last window.
def _exp_lambdas(n, a=4.0):
    den = 1.0 - math.exp(-a*a)
    return [(1.0 - math.exp(-((a*k/(n-1))**2)))/den for k in range(n)]

ONE_DG = _exp_lambdas(20)
VDW_DG = _exp_lambdas(16)
VDW  = [0.00, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60,
        0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1.00]
# The prefactor path uses the same 16-window schedule as the classical and
# direct calculations, so the three are compared at matched sampling cost.
VDW_PREF = VDW

NB = """   cut=10.0,
   ntc=2, ntf=1,"""
EW = """ &ewald
   order=6, dsum_tol=1.0e-6, vdwmeth=1, netfrc=0,
 /"""

STAGES = [("eq1", 25000, "ntt=3, temp0=300.0, gamma_ln=2.0, ntb=1, ntp=0,", 0),
          ("eq2", 25000, "ntt=3, temp0=300.0, gamma_ln=2.0, ntb=2, ntp=1, pres0=1.01325, taup=10.0,", 1),
          ("eq3", 25000, "ntt=3, temp0=300.0, gamma_ln=2.0, ntb=2, ntp=1, pres0=1.01325, taup=10.0,", 1),
          ("prod", 2500000, "ntt=3, temp0=300.0, gamma_ln=2.0, ntb=1, ntp=0,", 0)]

def mdin(title, stage, nsteps, tctl, flags, clam, lams, seed):
    return f"""{title} [{stage}]
 &cntrl
   imin=0, nstlim={nsteps}, dt=0.002, ig={seed},
   irest={0 if stage=='eq1' else 1}, ntx={1 if stage=='eq1' else 5},
   {tctl}
{NB}
   ioutfm=1, iwrap=1,
   ntpr=500, ntwr=5000, ntwx=0, ntwe=0,
   {flags}
   clambda={clam:.6f},
   ifmbar=1, bar_intervall=500,
   mbar_states={len(lams)},
   mbar_lambda={", ".join(f"{x:.6f}" for x in lams)},
 /
{EW}
"""

def main():
    tasks = []
    for solute in SOLUTES:
        for model in ("classical", "degauss", "degauss_pref"):
            deg = "idegauss=1, " if model.startswith("degauss") else ""
            pref = model == "degauss_pref"
            # prefactor path: cubic shift inside both DE exponents
            dgv = ("ifsc_q=0, ifsc_v=1, de_prefactor_k=3.0, de_prefactor_j=3.0,"
                   if pref else "ifsc_q=0, ifsc_v=0,")
            legs = {
              # electrostatics: dual topology, charges off copy 2, no softcore
              "elec": (f"{deg}icfe=1, ifsc=0, timask1=':1', timask2=':2', crgmask=':2',",
                       ELEC, f"{solute}_dual.prmtop", "deq.rst"),
              "elec_gas": (f"{deg}icfe=1, ifsc=0, timask1=':1', timask2=':2', crgmask=':2',",
                       ELEC, f"{solute}_gasbox.prmtop", f"{solute}_gasbox.rst7"),
              # van der Waals: single topology decoupling, charges already off
              # one-step: charged solute, everything removed together
              "onestep": ((f"{deg}icfe=1, ifsc=0, {dgv} timask1=':1', timask2='',"
                       if model.startswith("degauss") else
                       "icfe=1, ifsc=1, timask1=':1', timask2='', scmask1=':1', scmask2='',"
                       " scalpha=0.5, scbeta=12.0,"),
                      (ONE if (pref or model == "classical") else ONE_DG),
                      f"{solute}_solv.prmtop", "ceq.rst"),
              "vdw": ((f"{deg}icfe=1, ifsc=0, {dgv} timask1=':1', timask2='', crgmask=':1',"
                       if model.startswith("degauss") else
                       "icfe=1, ifsc=1, timask1=':1', timask2='', scmask1=':1', scmask2='',"
                       " crgmask=':1', scalpha=0.5, scbeta=12.0,"),
                      (VDW_PREF if pref else (VDW if model == "classical" else VDW_DG)),
                      f"{solute}_solv.prmtop", "ceq.rst"),
            }
            for chan, (flags, lams, top, start) in legs.items():
                prm = (BUILD / solute / top).resolve()
                crd = (BUILD / solute / start).resolve()
                if not prm.exists() or not crd.exists():
                    raise SystemExit(f"missing {prm if not prm.exists() else crd}")
                for rep in range(NREP):
                    for k, clam in enumerate(lams):
                        wd = RUNS/solute/model/chan/f"replica_{rep}"/f"lambda_{k:02d}"
                        wd.mkdir(parents=True, exist_ok=True)
                        for stage, nst, tctl, _ in STAGES:
                            n = nst if chan != "elec_gas" or stage == "prod" else nst
                            (wd/f"{stage}.in").write_text(mdin(
                                f"FreeSolv protocol; {solute}; {model}; {chan}; rep {rep}; w{k:02d}",
                                stage, n, tctl, flags, clam, lams,
                                220000 + 1000*rep + 10*k + len(solute)))
                        tasks.append((str(wd), str(prm), str(crd)))
    out = RUNS/"tasks.tsv"
    out.write_text("".join("\t".join(t)+"\n" for t in tasks))
    print(f"  {len(tasks)} windows (3 solutes x 2 models x 3 legs x 3 reps)")
    print(f"  elec {len(ELEC)} windows, vdw {len(VDW)} windows, 5 ns each + 150 ps equilibration")
    print(f"  -> {out}")

if __name__ == "__main__":
    main()
