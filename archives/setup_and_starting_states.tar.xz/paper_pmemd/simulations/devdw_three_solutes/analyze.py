#!/usr/bin/env python3
"""Cumulative BAR free-energy profiles for the de-vdW campaign.

Reads the per-window MBAR energy blocks pmemd writes, drops the first quarter
of each window (1 ns of 4 ns), and accumulates adjacent-window BAR estimates.

Works are converted to reduced units before pymbar and the result converted
back, which is the correction applied on 2026-07-06; passing kcal/mol straight
into pymbar understates the magnitude.
"""
from __future__ import annotations
import re, sys
from pathlib import Path
import numpy as np
from pymbar import other_estimators

KT = 0.0019872041 * 300.0          # kcal/mol at 300 K
SKIP = 0.25                        # discard first 1 ns of each 4 ns window

def parse_mbar(path: Path, n: int) -> np.ndarray:
    if not path.exists():
        return np.zeros((0, n))
    blocks, cur, on = [], [], False
    with path.open() as f:
        for line in f:
            if "MBAR Energy analysis" in line:
                on, cur = True, []
                continue
            if on:
                m = re.match(r"\s*Energy at\s+[-\d.]+\s*=\s*([-\d.Ee+]+)", line)
                if m:
                    cur.append(float(m.group(1)))
                    if len(cur) == n:
                        blocks.append(cur); on = False; cur = []
                elif line.strip() and not line.startswith(" "):
                    on = False
    return np.asarray(blocks)

def pairwise_bar(E, idx):
    """BAR between consecutive entries of idx, using columns idx."""
    out = []
    for a, b in zip(idx[:-1], idx[1:]):
        Ea, Eb = E[a], E[b]
        if len(Ea) < 50 or len(Eb) < 50:
            out.append(np.nan); continue
        wf = (Ea[:, b] - Ea[:, a]) / KT
        wr = (Eb[:, a] - Eb[:, b]) / KT
        try:
            out.append(other_estimators.bar(wf, wr)["Delta_f"] * KT)
        except Exception:
            out.append(np.nan)
    return np.asarray(out)

def load_replica(window_paths, n):
    E = []
    for p in window_paths:
        e = parse_mbar(p, n)
        E.append(e[int(SKIP * len(e)):] if len(e) else e)
    return E

def profile(window_paths, n, idx=None):
    E = load_replica(window_paths, n)
    if any(len(e) == 0 for e in E):
        return None
    idx = list(range(n)) if idx is None else idx
    d = pairwise_bar(E, idx)
    return np.concatenate([[0.0], np.cumsum(d)])

def report(label, reps, n, idx=None):
    profs = [profile(w, n, idx) for w in reps]
    profs = [p for p in profs if p is not None]
    if not profs:
        print(f"{label:38s}  no data"); return None
    P = np.vstack(profs)
    dg = P[:, -1]
    print(f"{label:38s}  dG = {dg.mean():+7.3f} +/- {dg.std(ddof=1):5.3f} kcal/mol"
          f"   (n={len(profs)} replicas)")
    return P
