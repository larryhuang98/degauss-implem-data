#!/usr/bin/env python3
"""Set up unified 4 ns continuations for the neutral-solute comparison."""

from __future__ import annotations

import json
import re
from pathlib import Path


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
HFE = Path("/home8/larry/project/alchemical/hfe")
CORRECTED_DIRECT = REPO / "simulations" / "neutral_direct_unique20" / "runs"
ISO_ROOT = REPO / "simulations" / "isoleucine_vdw_production" / "runs"

SYSTEMS = ("methane", "O2", "isoleucine")
PATHS = ("direct_de", "cubic_prefactor_de", "exponent_scaling_de", "classical_softcore")
EXTERNAL_NAMES = {
    "cubic_prefactor_de": "prefactor_linlam_rep{replica}",
    "exponent_scaling_de": "steepness_linlam_rep{replica}",
    "classical_softcore": "classical_linlam_rep{replica}",
}


def source_root(system: str, path_name: str, replica: int) -> Path:
    if system in ("methane", "O2"):
        if path_name == "direct_de":
            return CORRECTED_DIRECT / system / f"replica_{replica}"
        return HFE / system / EXTERNAL_NAMES[path_name].format(replica=replica)
    return ISO_ROOT / path_name / f"replica_{replica}"


def topology(system: str, source: Path) -> Path:
    if system == "isoleucine":
        return ISO_ROOT / "isoleucine_zeroq.parm7"
    return source / "prmtop"


def source_restart(system: str, source: Path, window: int) -> Path:
    name = "output.rst7" if system == "isoleucine" else "out.rst"
    return source / "windows" / f"lambda_{window:02d}" / name


def continuation_input(
    source_input: Path,
    system: str,
    path_name: str,
    replica: int,
    window: int,
    seed: int,
) -> str:
    text = source_input.read_text()
    lines = text.splitlines()
    lines[0] = (
        f"Unified 4 ns continuation; {system}; {path_name}; "
        f"replica {replica}; window {window:02d}"
    )
    text = "\n".join(lines) + "\n"
    text, n_nstlim = re.subn(r"nstlim\s*=\s*\d+", "nstlim=2000000", text, count=1)
    text, n_ig = re.subn(r"ig\s*=\s*-?\d+", f"ig={seed}", text, count=1)
    if n_nstlim != 1 or n_ig != 1:
        raise RuntimeError(f"Could not update nstlim/ig in {source_input}")

    required = (
        "dt=0.002",
        "irest=1",
        "ntx=5",
        "temp0=300.0",
        "ntb=1",
        "cut=9.0",
        "ntpr=500",
        "bar_intervall=500",
        "mbar_states=20",
    )
    compact = text.replace(" ", "")
    for token in required:
        if token.replace(" ", "") not in compact:
            raise RuntimeError(f"Missing required protocol token {token!r} in {source_input}")
    return text


def smoke_input(production: str) -> str:
    return (
        production.replace("nstlim=2000000", "nstlim=100")
        .replace("ntpr=500", "ntpr=100")
        .replace("ntwr=2000", "ntwr=100")
        .replace("bar_intervall=500", "bar_intervall=100")
    )


def replace_symlink(link: Path, target: Path) -> None:
    if link.is_symlink() or link.exists():
        link.unlink()
    link.symlink_to(target.absolute())


def main() -> None:
    rows = {"ready": [], "direct": []}
    source_manifest: list[dict[str, object]] = []
    group_ids = {"ready": 0, "direct": 0}

    for system_index, system in enumerate(SYSTEMS):
        for path_index, path_name in enumerate(PATHS):
            for replica in range(3):
                source = source_root(system, path_name, replica)
                group = "direct" if system in ("methane", "O2") and path_name == "direct_de" else "ready"
                source_manifest.append(
                    {
                        "system": system,
                        "path": path_name,
                        "replica": replica,
                        "group": group,
                        "source": str(source),
                    }
                )
                for window in range(20):
                    source_window = source / "windows" / f"lambda_{window:02d}"
                    source_input = source_window / "mdin.npt"
                    if not source_input.exists():
                        raise FileNotFoundError(source_input)
                    restart = source_restart(system, source, window)
                    if group == "ready" and not restart.exists():
                        raise FileNotFoundError(restart)

                    destination = (
                        HERE
                        / "runs"
                        / system
                        / path_name
                        / f"replica_{replica}"
                        / "windows"
                        / f"lambda_{window:02d}"
                    )
                    destination.mkdir(parents=True, exist_ok=True)
                    replace_symlink(destination / "prmtop", topology(system, source))
                    replace_symlink(destination / "start.rst", restart)
                    seed = (
                        910001
                        + system_index * 100000
                        + path_index * 10000
                        + replica * 1000
                        + window * 2
                    )
                    production = continuation_input(
                        source_input, system, path_name, replica, window, seed
                    )
                    (destination / "mdin.4ns").write_text(production)
                    if (
                        (system, path_name, replica, window)
                        in {
                            ("methane", "cubic_prefactor_de", 0, 10),
                            ("isoleucine", "direct_de", 0, 10),
                        }
                    ):
                        (destination / "smoke.in").write_text(smoke_input(production))

                    task_id = group_ids[group]
                    rows[group].append(
                        f"{task_id}\t{system}\t{path_name}\t{replica}\t{window}\t{destination}"
                    )
                    group_ids[group] += 1

    header = "task_id\tsystem\tpath\treplica\twindow\tworkdir"
    for group, group_rows in rows.items():
        (HERE / f"tasks_{group}.tsv").write_text(
            header + "\n" + "\n".join(group_rows) + "\n"
        )
    manifest = {
        "protocol": {
            "continuation_ns": 4.0,
            "discard_ns": 1.0,
            "analyzed_ns": 3.0,
            "temperature_K": 300.0,
            "ensemble": "NVT",
            "dt_fs": 2.0,
            "cutoff_A": 9.0,
            "windows": 20,
            "replicas": 3,
            "energy_interval_ps": 1.0,
        },
        "task_counts": {group: len(group_rows) for group, group_rows in rows.items()},
        "sources": source_manifest,
    }
    (HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"ready tasks: {len(rows['ready'])}")
    print(f"dependent direct-DE tasks: {len(rows['direct'])}")


if __name__ == "__main__":
    main()
