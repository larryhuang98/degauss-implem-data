import re,numpy as np
NAT=12288; D="/home8/larry/project/alchemical/hfe/_overnight"
def stats(f):
    pre=open(f).read().split("A V E R A G E S")[0]
    ti=np.array([float(x) for x in re.findall(r"TIME\(PS\)\s*=\s*([-\d.]+)",pre)])
    e =np.array([float(x) for x in re.findall(r"Etot\s*=\s*([-\d.]+)",pre)])
    n=min(len(ti),len(e)); ti,e=ti[:n],e[:n]; m=ti>=ti[0]+20; ti,e=ti[m],e[m]
    return np.polyfit(ti,e,1)[0]/NAT,(e-np.polyval(np.polyfit(ti,e,1),ti)).std(),e.mean(),len(e),ti[-1]
runs=[("DEGAUSS PME SPFP","deg_pme_spfp.out"),("DEGAUSS PME DPFP","deg_pme_dpfp.out"),
      ("Classic PME SPFP","cl_pme_spfp.out"),("Classic PME DPFP","cl_pme_dpfp.out")]
print("HIGH-STANDARD PME (dsum_tol=1e-6, 64^3, order6):")
for lab,f in runs:
    try:
        d,r,m,n,tl=stats(f); print(f"  {lab}: drift={d:+.2e}  RMS={r:.2f}  <Etot>={m:.1f}  ({n} pts, to {tl:.0f}ps)")
    except Exception as ex: print(f"  {lab}: not ready")
print("(loose default was: DEG PME +2.7e-7/+2.5e-7, CL PME +2.1e-7/+1.7e-7)")
