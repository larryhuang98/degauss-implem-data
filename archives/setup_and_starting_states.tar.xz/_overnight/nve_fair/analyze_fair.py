import re,numpy as np
NAT=12288; D="/home8/larry/project/alchemical/hfe"
def st(f):
    pre=open(f).read().split("A V E R A G E S")[0]
    ti=np.array([float(x) for x in re.findall(r"TIME\(PS\)\s*=\s*([-\d.]+)",pre)])
    e =np.array([float(x) for x in re.findall(r"Etot\s*=\s*(-?[\d.]+)",pre)])
    n=min(len(ti),len(e)); ti,e=ti[:n],e[:n]; m=ti>=ti[0]+20; ti,e=ti[m],e[m]
    return np.polyfit(ti,e,1)[0]/NAT,(e-np.polyval(np.polyfit(ti,e,1),ti)).std(),e.mean(),len(e)
rows=[("DEGAUSS-of-TIP3P","IPS","SPFP","raw_ips_spfp.out"),
      ("DEGAUSS-of-TIP3P","IPS","DPFP","raw_ips_dpfp.out"),
      ("DEGAUSS-of-TIP3P","PME","SPFP","raw_pme_spfp.out"),
      ("DEGAUSS-of-TIP3P","PME","DPFP","raw_pme_dpfp.out")]
print("FAIR COMPARISON (DEGAUSS-of-TIP3P = TIP3P charges + DE fit to TIP3P LJ):")
for ff,lr,pr,f in rows:
    try:
        d,r,m,n=st(f); print(f"  {ff} {lr} {pr}: drift={d:+.2e} RMS={r:.2f} <Etot>={m:.1f} n={n}")
    except: print(f"  {ff} {lr} {pr}: not ready")
print("classical TIP3P (have): IPS SPFP +4.4e-8 / DPFP -3.0e-10 ; PME SPFP +3.5e-8 / DPFP +5.6e-9")
