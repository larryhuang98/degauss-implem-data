import re, sys, numpy as np
NAT=12288
def parse(out):
    t=open(out).read().split("A V E R A G E S")[0]
    times=[float(x) for x in re.findall(r"TIME\(PS\)\s*=\s*([-\d.]+)", t)]
    etot =[float(x) for x in re.findall(r"Etot\s*=\s*([-\d.]+)", t)]
    n=min(len(times),len(etot)); times=np.array(times[:n]); etot=np.array(etot[:n])
    m=times>=(times[0]+20.0); tt=times[m]; ee=etot[m]            # discard first 20 ps
    sl=np.polyfit(tt,ee,1)[0]                                     # kcal/mol/ps
    resid=ee-np.polyval(np.polyfit(tt,ee,1),tt)
    return dict(mean=ee.mean(), drift_atom=sl/NAT, rms=resid.std(), npts=len(ee), span=tt[-1]-tt[0])
for tag,f in [("PME","nve_pme.out"),("IPS","nve_ips.out")]:
    try:
        d=parse(f)
        print(f"classical-{tag}: drift={d['drift_atom']:+.2e} /atom/ps  RMS={d['rms']:.2f}  <Etot>={d['mean']:.1f}  n={d['npts']} span={d['span']:.0f}ps")
    except Exception as e:
        print(f"classical-{tag}: not ready ({e})")
