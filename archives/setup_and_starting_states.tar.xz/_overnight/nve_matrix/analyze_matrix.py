import re,numpy as np
NAT=12288; D="/home8/larry/project/alchemical/hfe/_overnight"
def stats(f):
    txt=open(f).read(); pre=txt.split("A V E R A G E S")[0]
    ti=np.array([float(x) for x in re.findall(r"TIME\(PS\)\s*=\s*([-\d.]+)",pre)])
    e =np.array([float(x) for x in re.findall(r"Etot\s*=\s*([-\d.]+)",pre)])
    T =np.array([float(x) for x in re.findall(r"TEMP\(K\)\s*=\s*([-\d.]+)",pre)])
    n=min(len(ti),len(e)); ti,e=ti[:n],e[:n]; m=ti>=ti[0]+20; ti,e=ti[m],e[m]
    sl=np.polyfit(ti,e,1)[0]; rms=(e-np.polyval(np.polyfit(ti,e,1),ti)).std()
    return dict(drift=sl/NAT,rms=rms,mean=e.mean(),T=T[m].mean() if len(T)>=n else np.nan,span=(ti[0],ti[-1]),n=len(e))
runs=[
 ("DEGAUSS","IPS","SPFP",f"{D}/nve10ns/nve_spfp.out"),
 ("DEGAUSS","IPS","DPFP",f"{D}/nve_matrix/deg_ips_dpfp.out"),
 ("DEGAUSS","PME","SPFP",f"{D}/nve_matrix/deg_pme_spfp.out"),
 ("DEGAUSS","PME","DPFP",f"{D}/nve_matrix/deg_pme_dpfp.out"),
 ("Classical","IPS","SPFP",f"{D}/nve_classical/nve_ips.out"),
 ("Classical","IPS","DPFP",f"{D}/nve_matrix/cl_ips_dpfp.out"),
 ("Classical","PME","SPFP",f"{D}/nve_classical/nve_pme.out"),
 ("Classical","PME","DPFP",f"{D}/nve_matrix/cl_pme_dpfp.out"),
]
print(f"{'FF':10s} {'LR':4s} {'prec':5s} {'drift(/atom/ps)':16s} {'RMS':6s} {'<Etot>':10s} {'<T>':7s} span")
for ff,lr,pr,f in runs:
    try:
        s=stats(f); print(f"{ff:10s} {lr:4s} {pr:5s} {s['drift']:+.2e}        {s['rms']:.2f}   {s['mean']:9.1f} {s['T']:6.2f}  {s['span'][0]:.0f}-{s['span'][1]:.0f}ps n={s['n']}")
    except Exception as ex:
        print(f"{ff:10s} {lr:4s} {pr:5s}  --- not ready ({type(ex).__name__})")
