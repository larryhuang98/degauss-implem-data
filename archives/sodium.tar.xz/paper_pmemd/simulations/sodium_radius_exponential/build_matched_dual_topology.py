#!/usr/bin/env python3
"""Build a two-Na TI topology from the original 1033-atom sodium system."""

from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

import numpy as np


DATA_ROOT = Path("/home8/larry/project/alchemical/hfe/Na")
SOURCE_TOP = DATA_ROOT / "degauss_exp_windows" / "prmtop"
SOURCE_RST = DATA_ROOT / "degauss_exp_windows" / "eq.rst"
SOURCE_PDB = DATA_ROOT / "na_wat.pdb"
OUTPUT_ROOT = DATA_ROOT / "degauss_charge_mbar_matched"
OUTPUT_TOP = OUTPUT_ROOT / "dual.prmtop"
OUTPUT_RST = OUTPUT_ROOT / "dual.rst7"
DE_FLAGS = (
    "DOUBLE_EXPONENTIAL_A",
    "DOUBLE_EXPONENTIAL_C",
    "DOUBLE_EXPONENTIAL_EPS0",
    "DOUBLE_EXPONENTIAL_RMIN",
)


def patch_numpy_for_parmed() -> None:
    """Work around ParmEd's NumPy-1 copy=False call under NumPy 2."""

    original = np.array

    def compatible_array(obj, *args, **kwargs):
        if kwargs.get("copy") is False:
            kwargs.pop("copy")
            kwargs.pop("subok", None)
            return np.asarray(obj, *args, **kwargs)
        return original(obj, *args, **kwargs)

    np.array = compatible_array


def dual_pdb_text(source: str) -> str:
    """Duplicate the first Na residue and shift all following indices by one."""

    output: list[str] = []
    duplicated = False
    for line in source.splitlines():
        if line.startswith("CRYST1"):
            output.append(line)
            continue
        if line.startswith(("ATOM  ", "HETATM")):
            serial = int(line[6:11])
            residue = int(line[22:26])
            if serial == 1 and not duplicated:
                output.append(line)
                duplicate = (
                    f"{line[:6]}{2:5d}{line[11:22]}{2:4d}{line[26:]}"
                )
                output.extend(("TER   ", duplicate, "TER   "))
                duplicated = True
            elif serial > 1:
                output.append(
                    f"{line[:6]}{serial + 1:5d}{line[11:22]}"
                    f"{residue + 1:4d}{line[26:]}"
                )
            continue
        if line.startswith("TER"):
            if duplicated:
                continue
            output.append(line)
        elif line.startswith("END"):
            output.append(line)
    return "\n".join(output) + "\n"


def flag_block(text: str, name: str) -> str:
    start = text.index(f"%FLAG {name}")
    end = text.find("%FLAG ", start + 6)
    if end < 0:
        end = len(text)
    return text[start:end].rstrip() + "\n"


def gaussian_section(natom: int) -> str:
    lines = ["%FLAG GAUSS_RADII_LIST", "%FORMAT(5E16.8)"]
    values = [0.2] * natom
    for start in range(0, natom, 5):
        lines.append(
            "".join(f"{value:16.8E}" for value in values[start : start + 5])
        )
    return "\n".join(lines) + "\n"


def read_natom(text: str) -> int:
    start = text.index("%FLAG POINTERS")
    data = text.index("\n", text.index("%FORMAT", start)) + 1
    return int(text[data:].split()[0])


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    source_topology = SOURCE_TOP.read_text()

    with tempfile.TemporaryDirectory(prefix="degauss-dual-topology-") as tmp:
        root = Path(tmp)
        pdb = root / "dual.pdb"
        leap = root / "tleap.in"
        raw_top = root / "dual.raw.prmtop"
        raw_rst = root / "dual.raw.rst7"
        pdb.write_text(dual_pdb_text(SOURCE_PDB.read_text()))
        leap.write_text(
            "\n".join(
                (
                    "source leaprc.water.tip3p",
                    "loadAmberParams frcmod.ions1lm_126_tip3p",
                    f"system = loadpdb {pdb}",
                    "set system box { 25.763002 25.584490 25.854843 }",
                    f"saveamberparm system {raw_top} {raw_rst}",
                    "quit",
                    "",
                )
            )
        )
        subprocess.run(
            ["/home8/larry/amber25/bin/tleap", "-f", str(leap)],
            check=True,
            cwd=root,
        )

        topology = raw_top.read_text().rstrip() + "\n"
        for name in DE_FLAGS:
            topology += flag_block(source_topology, name)
        natom = read_natom(topology)
        if natom != 1034:
            raise RuntimeError(f"Expected 1034 atoms; tleap produced {natom}")
        topology += gaussian_section(natom)
        OUTPUT_TOP.write_text(topology)

    patch_numpy_for_parmed()
    import parmed as pmd

    source = pmd.load_file(str(SOURCE_TOP), xyz=str(SOURCE_RST))
    coordinates = np.vstack(
        (source.coordinates[0:1], source.coordinates[0:1], source.coordinates[1:])
    )
    restart = pmd.amber.Rst7(natom=coordinates.shape[0])
    restart.coordinates = coordinates
    restart.box = source.box
    restart.write(str(OUTPUT_RST), netcdf=False)

    print(f"topology={OUTPUT_TOP}")
    print(f"restart={OUTPUT_RST}")
    print(f"atoms={coordinates.shape[0]} residues=346")
    print("residues 1 and 2 are coincident Na+; residues 3-346 are the original waters")


if __name__ == "__main__":
    main()
