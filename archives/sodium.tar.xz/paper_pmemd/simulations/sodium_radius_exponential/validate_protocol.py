#!/usr/bin/env python3
"""Validate the charge-only DEGAUSS+IPS Hamiltonian against explicit topologies."""

from __future__ import annotations

import math
import re
import subprocess
import tempfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
DATA_ROOT = Path("/home8/larry/project/alchemical/hfe/Na")
EXE = DATA_ROOT / "eel_ifscq1_lin11_reffexp4_r020_200-pmemd"
PRMTOP = DATA_ROOT / "eel_ifscq1_lin11_reffexp4_r020_200_rep0/prmtop"
RESTART = DATA_ROOT / "ti_degauss_exp/eq.rst"
LAMBDAS = tuple(index / 10.0 for index in range(11))
EXPONENT = 4.0
AMBER_CHARGE = 18.2223
IPS_RADIUS = 8.0
PIPSE0 = -35.0 / 16.0
FULL_SODIUM_IPS_SELF = (
    0.5 * AMBER_CHARGE * AMBER_CHARGE * PIPSE0 / IPS_RADIUS
)

VDW_PATTERN = re.compile(r"VDWAALS\s*=\s*([-\d.Ee+]+)")
EEL_PATTERN = re.compile(r"EELEC\s*=\s*([-\d.Ee+]+)")


def effective_radius(lam: float) -> float:
    schedule = (math.exp(EXPONENT * lam) - 1.0) / (
        math.exp(EXPONENT) - 1.0
    )
    return 0.2 + 19.8 * schedule


def first_energy(path: Path, pattern: re.Pattern[str]) -> float:
    match = pattern.search(path.read_text())
    if match is None:
        raise RuntimeError(f"Missing energy in {path}")
    return float(match.group(1))


def section_bounds(text: str, name: str) -> tuple[int, int, int]:
    flag = text.index(f"%FLAG {name}")
    data = text.index("\n", text.index("%FORMAT", flag)) + 1
    end = text.find("%FLAG ", data)
    if end < 0:
        end = len(text)
    return flag, data, end


def section_values(text: str, name: str) -> list[float]:
    _, data, end = section_bounds(text, name)
    return [float(value) for value in text[data:end].split()]


def replace_float_section(text: str, name: str, values: list[float]) -> str:
    _, data, end = section_bounds(text, name)
    body = "".join(
        "".join(f"{value:16.8E}" for value in values[start : start + 5]) + "\n"
        for start in range(0, len(values), 5)
    )
    return text[:data] + body + text[end:]


def explicit_topology(source: str, lam: float) -> str:
    charges = section_values(source, "CHARGE")
    radii = section_values(source, "GAUSS_RADII_LIST")
    if not math.isclose(charges[0], AMBER_CHARGE, abs_tol=1.0e-6):
        raise RuntimeError("Campaign topology does not contain charged Na+")

    # The explicit reference represents exactly the Hamiltonian sampled by the
    # alchemical module: q_Na(lambda)=(1-lambda)q_Na and the requested R_eff.
    charges[0] = (1.0 - lam) * AMBER_CHARGE
    radii[0] = effective_radius(lam) / math.sqrt(2.0)
    return replace_float_section(
        replace_float_section(source, "CHARGE", charges),
        "GAUSS_RADII_LIST",
        radii,
    )


def mdin(lam: float, scheduled_path: bool) -> str:
    if scheduled_path:
        alchemical_block = f"""
   ifsc=0, ifsc_q=1, ifsc_v=0,
   sigma_max={20.0 / math.sqrt(2.0):.10f},
   elec_schedule=6, elec_schedule_c={EXPONENT:.1f},
   icfe=1, clambda={lam:.6f},
   timask1=':1', timask2='',
   ifmbar=0,"""
    else:
        # Keep TI pair routing active so that both calculations use the same
        # fixed, common-water IPS coefficients.  At clambda=0 the explicit
        # topology is evaluated without any additional scaling.
        alchemical_block = """
   ifsc=0, ifsc_q=0, ifsc_v=0,
   icfe=1, clambda=0.000000,
   timask1=':1', timask2='',
   ifmbar=0,"""
    return f"""DEGAUSS+IPS protocol validation
 &cntrl
   imin=0, nstlim=1, dt=0.001, ig=719999,
   irest=1, ntx=5,
   ntt=3, temp0=298.15, gamma_ln=5.0,
   ntb=1, ntp=0,
   ntc=2, ntf=2, tol=0.000001,
   cut=8.0,
   ntpr=1, ntwr=1, ntwx=0, ntwf=1, ioutfm=0,
   ips=1,
   idegauss=1, gbeta=0.2000000000,{alchemical_block}
 /
"""


def read_ascii_forces(path: Path) -> list[float]:
    lines = path.read_text().splitlines()
    return [
        float(line[start : start + 8])
        for line in lines[1:]
        for start in range(0, len(line), 8)
        if line[start : start + 8].strip()
    ]


def run_energy_force(
    root: Path, label: str, topology: Path, input_text: str
) -> tuple[float, float, list[float]]:
    input_path = root / f"{label}.in"
    output = root / f"{label}.out"
    restart = root / f"{label}.rst"
    force = root / f"{label}.frc"
    info = root / f"{label}.info"
    input_path.write_text(input_text)
    subprocess.run(
        [
            str(EXE),
            "-O",
            "-i",
            str(input_path),
            "-p",
            str(topology),
            "-c",
            str(RESTART),
            "-o",
            str(output),
            "-r",
            str(restart),
            "-frc",
            str(force),
            "-inf",
            str(info),
        ],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
    )
    return (
        first_energy(output, VDW_PATTERN),
        first_energy(output, EEL_PATTERN),
        read_ascii_forces(force),
    )


def main() -> None:
    source = PRMTOP.read_text()
    rows = []
    with tempfile.TemporaryDirectory(prefix="degauss-charge-only-") as temporary:
        root = Path(temporary)
        for lam in LAMBDAS:
            reference_topology = root / f"reference_{lam:.1f}.prmtop"
            reference_topology.write_text(explicit_topology(source, lam))

            module = run_energy_force(
                root, f"module_{lam:.1f}", PRMTOP, mdin(lam, True)
            )
            reference = run_energy_force(
                root,
                f"reference_{lam:.1f}",
                reference_topology,
                mdin(lam, False),
            )
            if len(module[2]) != len(reference[2]):
                raise RuntimeError("Force output lengths differ")
            force_differences = [
                left - right for left, right in zip(module[2], reference[2])
            ]
            force_rms = math.sqrt(
                sum(value * value for value in force_differences)
                / len(force_differences)
            )
            force_max = max(abs(value) for value in force_differences)
            rows.append((lam, effective_radius(lam), module, reference, force_rms, force_max))

    print(
        "lambda  R_eff(A)  module_VDW  reference_VDW  "
        "module_EEL  reference_EEL  EEL_residual  force_RMS  force_max"
    )
    for lam, radius, module, reference, force_rms, force_max in rows:
        weight = 1.0 - lam
        expected_self_offset = weight * (1.0 - weight) * FULL_SODIUM_IPS_SELF
        eel_residual = module[1] - reference[1] - expected_self_offset
        print(
            f"{lam:4.1f}   {radius:8.4f}  {module[0]:10.4f}  "
            f"{reference[0]:13.4f}  {module[1]:10.4f}  "
            f"{reference[1]:13.4f}  {eel_residual:12.3e}  "
            f"{force_rms:9.3e}  {force_max:9.3e}"
        )

    for lam, _, module, reference, force_rms, force_max in rows:
        if abs(module[0] - reference[0]) > 1.0e-4:
            raise RuntimeError("DE van der Waals energy differs from reference")
        weight = 1.0 - lam
        expected_self_offset = weight * (1.0 - weight) * FULL_SODIUM_IPS_SELF
        if abs(module[1] - reference[1] - expected_self_offset) > 2.0e-4:
            raise RuntimeError(
                "Electrostatic energy differs beyond the expected IPS "
                "self-energy convention"
            )
        if force_rms > 1.0e-6 or force_max > 1.0e-5:
            raise RuntimeError("Forces differ from explicit-topology reference")

    print(
        "PASS: all 11 windows match the explicit charge/radius forces; "
        "VDW is unchanged. The reported EEL difference is exactly the "
        "coordinate-independent IPS self-energy from linear interaction coupling."
    )


if __name__ == "__main__":
    main()
