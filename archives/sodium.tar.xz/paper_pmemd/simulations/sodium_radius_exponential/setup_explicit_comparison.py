#!/usr/bin/env python3
"""Prepare sodium charge paths with explicit state topologies.

Every path annihilates only the sodium charge.  The sodium DE van der Waals
parameters are unchanged.  The matched comparison uses uniform lambda
placement for both a fixed effective Gaussian radius and an exponentially
increasing effective radius.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path


DATA_ROOT = Path("/home8/larry/project/alchemical/hfe/Na")
BASE_TOPOLOGY = DATA_ROOT / "degauss_exp_windows" / "prmtop"
INITIAL_RESTART = DATA_ROOT / "degauss_exp_windows" / "eq.rst"
N_REPLICATES = 3
N_STEPS = 1_100_000
EXPONENT = 4.0
R_EFF_MIN = 0.2
R_EFF_MAX = 20.0
R_EFF_INTERMEDIATE = 10.0
AMBER_SODIUM_CHARGE = 18.2223
WATER_INPUT_RADIUS = 0.2


def exponential_lambdas() -> list[float]:
    denominator = 1.0 - math.exp(-(EXPONENT**2))
    return [
        (1.0 - math.exp(-((EXPONENT * index / 10.0) ** 2))) / denominator
        for index in range(11)
    ]


def changing_radius(lam: float, maximum_radius: float = R_EFF_MAX) -> float:
    schedule = (math.exp(EXPONENT * lam) - 1.0) / (
        math.exp(EXPONENT) - 1.0
    )
    return R_EFF_MIN + (maximum_radius - R_EFF_MIN) * schedule


PATHS = {
    "eel_explicit_fixed_exp11_reff020": {
        "lambdas": exponential_lambdas(),
        "radii": [R_EFF_MIN] * 11,
        "description": "fixed R_eff=0.2 A; exponential lambda placement",
    },
    "eel_explicit_radius_lin11_reffexp4_r020_200": {
        "lambdas": [index / 10.0 for index in range(11)],
        "radii": [changing_radius(index / 10.0) for index in range(11)],
        "description": "R_eff=0.2 to 20 A; uniform lambda placement",
    },
    "eel_explicit_fixed_lin11_reff020": {
        "lambdas": [index / 10.0 for index in range(11)],
        "radii": [R_EFF_MIN] * 11,
        "description": "fixed R_eff=0.2 A; uniform lambda placement",
    },
    "eel_explicit_radius_lin11_reffexp4_r020_100": {
        "lambdas": [index / 10.0 for index in range(11)],
        "radii": [
            changing_radius(index / 10.0, R_EFF_INTERMEDIATE)
            for index in range(11)
        ],
        "description": "R_eff=0.2 to 10 A; uniform lambda placement",
    },
}


def section_bounds(text: str, name: str) -> tuple[int, int]:
    flag = text.index(f"%FLAG {name}")
    data = text.index("\n", text.index("%FORMAT", flag)) + 1
    end = text.find("%FLAG ", data)
    if end < 0:
        end = len(text)
    return data, end


def section_values(text: str, name: str) -> list[float]:
    data, end = section_bounds(text, name)
    return [float(value) for value in text[data:end].split()]


def replace_float_section(text: str, name: str, values: list[float]) -> str:
    data, end = section_bounds(text, name)
    body = "".join(
        "".join(f"{value:16.8E}" for value in values[start : start + 5])
        + "\n"
        for start in range(0, len(values), 5)
    )
    return text[:data] + body + text[end:]


def append_float_section(text: str, name: str, values: list[float]) -> str:
    body = "".join(
        "".join(f"{value:16.8E}" for value in values[start : start + 5])
        + "\n"
        for start in range(0, len(values), 5)
    )
    return (
        text.rstrip()
        + f"\n%FLAG {name}\n%FORMAT(5E16.8)\n"
        + body
    )


def state_topology(
    source: str, lam: float, effective_radius: float
) -> str:
    charges = section_values(source, "CHARGE")
    if not math.isclose(
        charges[0], AMBER_SODIUM_CHARGE, rel_tol=0.0, abs_tol=1.0e-6
    ):
        raise ValueError("The base topology does not contain Na+")
    charges[0] = (1.0 - lam) * AMBER_SODIUM_CHARGE
    text = replace_float_section(source, "CHARGE", charges)

    natom = len(charges)
    input_radii = [effective_radius / math.sqrt(2.0)] + [
        WATER_INPUT_RADIUS
    ] * (natom - 1)
    if "%FLAG GAUSS_RADII_LIST" in text:
        text = replace_float_section(text, "GAUSS_RADII_LIST", input_radii)
    else:
        text = append_float_section(text, "GAUSS_RADII_LIST", input_radii)
    return text


def mdin(campaign: str, replica: int, window: int) -> str:
    seed = 730_000 + 1000 * list(PATHS).index(campaign) + 100 * replica + window
    return f"""Explicit sodium charge path; {campaign}; rep {replica}; window {window}
 &cntrl
   imin=0, nstlim={N_STEPS}, dt=0.001, ig={seed},
   irest=1, ntx=5,
   ntt=3, temp0=298.15, gamma_ln=5.0,
   ntb=1, ntp=0,
   ntc=2, ntf=2, tol=0.000001,
   cut=8.0,
   ntpr=1000, ntwr=2000, ntwx=1000, ioutfm=1,
   ips=1, idegauss=1, gbeta={WATER_INPUT_RADIUS:.10f},
 /
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--campaign",
        action="append",
        choices=PATHS,
        help="prepare only the selected campaign (repeatable)",
    )
    arguments = parser.parse_args()
    selected_campaigns = arguments.campaign or list(PATHS)

    source = BASE_TOPOLOGY.read_text()
    if not INITIAL_RESTART.exists():
        raise FileNotFoundError(INITIAL_RESTART)

    for campaign in selected_campaigns:
        definition = PATHS[campaign]
        manifest = {
            "campaign": campaign,
            "protocol": "explicit per-window topology; no TI routing",
            "description": definition["description"],
            "lambda_values": definition["lambdas"],
            "sodium_charge_e": [
                1.0 - value for value in definition["lambdas"]
            ],
            "effective_radius_angstrom": definition["radii"],
            "sodium_vdw": "unchanged at every window",
            "replicates": N_REPLICATES,
            "steps_per_window": N_STEPS,
            "trajectory_interval_steps": 1000,
        }
        for replica in range(N_REPLICATES):
            root = DATA_ROOT / f"{campaign}_rep{replica}"
            topology_directory = root / "topologies"
            window_directory = root / "windows"
            topology_directory.mkdir(parents=True, exist_ok=True)
            window_directory.mkdir(parents=True, exist_ok=True)
            restart = root / "eq.rst"
            if not restart.exists():
                os.symlink(INITIAL_RESTART, restart)
            (root / "campaign_manifest.json").write_text(
                json.dumps(manifest, indent=2) + "\n"
            )

            for window, (lam, radius) in enumerate(
                zip(definition["lambdas"], definition["radii"])
            ):
                topology = topology_directory / f"state_{window:02d}.prmtop"
                topology.write_text(state_topology(source, lam, radius))
                directory = window_directory / f"lambda_{window:02d}"
                directory.mkdir(parents=True, exist_ok=True)
                (directory / "mdin.npt").write_text(
                    mdin(campaign, replica, window)
                )

        print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
