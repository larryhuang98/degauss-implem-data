#!/usr/bin/env python3
"""Create the sodium effective-Gaussian-radius exponential campaign."""

from __future__ import annotations

import json
import math
import os
from pathlib import Path


DATA_ROOT = Path("/home8/larry/project/alchemical/hfe/Na")
SOURCE = DATA_ROOT / "ti_degauss_exp"
CHARGED_PRMTOP = DATA_ROOT / "degauss_exp_windows" / "prmtop"
CAMPAIGN_NAME = "eel_ifscq1_lin11_reffexp4_r020_200"
N_REPLICATES = 3
LAMBDAS = [k / 10.0 for k in range(11)]
R_PHYS = 0.2
R_MAX = 20.0
EXPONENT = 4.0

# pmemd reads the input Gaussian width a and stores R_eff^2 = 2*a^2.
GBETA_INPUT = R_PHYS / math.sqrt(2.0)
SIGMA_MAX_INPUT = R_MAX / math.sqrt(2.0)
WATER_INPUT_RADIUS = 0.2


def radius(lam: float) -> float:
    schedule = (math.exp(EXPONENT * lam) - 1.0) / (
        math.exp(EXPONENT) - 1.0
    )
    return R_PHYS + (R_MAX - R_PHYS) * schedule


def mdin(replica: int, window: int, lam: float) -> str:
    seed = 710_000 + 100 * replica + window
    return f"""Na+ changing effective Gaussian radius; rep {replica}; lambda {lam:.1f}
 &cntrl
   imin=0, nstlim=1100000, dt=0.001, ig={seed},
   irest=1, ntx=5,
   ntt=3, temp0=298.15, gamma_ln=5.0,
   ntb=1, ntp=0,
   ntc=2, ntf=2, tol=0.000001,
   cut=8.0,
   ntpr=1000, ntwr=2000, ntwx=1000, ioutfm=1,
   ips=1,
   idegauss=1, gbeta={WATER_INPUT_RADIUS:.10f},
   ifsc=0, ifsc_q=1, ifsc_v=0,
   sigma_max={SIGMA_MAX_INPUT:.10f},
   elec_schedule=6, elec_schedule_c={EXPONENT:.1f},
   icfe=1, clambda={lam:.6f},
   timask1=':1', timask2='',
   ifmbar=0,
 /
"""


def read_natom(prmtop_text: str) -> int:
    lines = prmtop_text.splitlines()
    for index, line in enumerate(lines):
        if line.strip() == "%FLAG POINTERS":
            values = []
            for data_line in lines[index + 2 :]:
                if data_line.startswith("%FLAG"):
                    break
                values.extend(data_line.split())
            return int(values[0])
    raise ValueError("POINTERS section not found")


def read_first_charge(prmtop_text: str) -> float:
    lines = prmtop_text.splitlines()
    for index, line in enumerate(lines):
        if line.strip() == "%FLAG CHARGE":
            return float(lines[index + 2].split()[0])
    raise ValueError("CHARGE section not found")


def write_campaign_prmtop(source: Path, destination: Path) -> None:
    text = source.read_text()
    if "%FLAG GAUSS_RADII_LIST" in text:
        raise ValueError("Source topology unexpectedly already has GAUSS_RADII_LIST")
    sodium_charge = read_first_charge(text)
    if not math.isclose(sodium_charge, 18.2223, rel_tol=0.0, abs_tol=1.0e-6):
        raise ValueError(
            "The source topology must contain charged Na+ "
            f"(Amber charge 18.2223); found {sodium_charge}"
        )

    natom = read_natom(text)
    values = [GBETA_INPUT] + [WATER_INPUT_RADIUS] * (natom - 1)
    section = [
        "%FLAG GAUSS_RADII_LIST",
        "%FORMAT(5E16.8)",
    ]
    for start in range(0, natom, 5):
        section.append(
            "".join(f"{value:16.8E}" for value in values[start : start + 5])
        )

    if destination.is_symlink():
        destination.unlink()
    destination.write_text(text.rstrip() + "\n" + "\n".join(section) + "\n")


def main() -> None:
    prmtop = CHARGED_PRMTOP
    restart = SOURCE / "eq.rst"
    if not prmtop.exists() or not restart.exists():
        raise FileNotFoundError("The established sodium topology or restart is missing")

    manifest = {
        "campaign": CAMPAIGN_NAME,
        "lambda_values": LAMBDAS,
        "effective_radius_angstrom": [radius(lam) for lam in LAMBDAS],
        "effective_radius_physical_angstrom": R_PHYS,
        "effective_radius_maximum_angstrom": R_MAX,
        "radius_schedule": "(exp(4*lambda)-1)/(exp(4)-1)",
        "gbeta_input_angstrom": GBETA_INPUT,
        "water_input_radius_angstrom": WATER_INPUT_RADIUS,
        "sigma_max_input_angstrom": SIGMA_MAX_INPUT,
        "replicates": N_REPLICATES,
        "steps_per_window": 1_100_000,
        "trajectory_interval_steps": 1_000,
    }

    for replica in range(N_REPLICATES):
        root = DATA_ROOT / f"{CAMPAIGN_NAME}_rep{replica}"
        windows = root / "windows"
        windows.mkdir(parents=True, exist_ok=True)

        write_campaign_prmtop(prmtop, root / "prmtop")
        restart_destination = root / "eq.rst"
        if not restart_destination.exists():
            os.symlink(restart, restart_destination)

        (root / "campaign_manifest.json").write_text(
            json.dumps(manifest, indent=2) + "\n"
        )

        for window, lam in enumerate(LAMBDAS):
            directory = windows / f"lambda_{window:02d}"
            directory.mkdir(parents=True, exist_ok=True)
            (directory / "mdin.npt").write_text(mdin(replica, window, lam))

    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
