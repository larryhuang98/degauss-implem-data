#!/usr/bin/env python3
"""Frame-level regression for the matched sodium IPS/MBAR Hamiltonians."""

from __future__ import annotations

import math
import re
import subprocess
import tempfile
from pathlib import Path


DATA_ROOT = Path("/home8/larry/project/alchemical/hfe/Na")
EXE = Path(
    "/home8/larry/ambers/amber_merge_degauss_pmemd/build/src/pmemd/src/pmemd"
)
DUAL_ROOT = DATA_ROOT / "degauss_charge_mbar_matched"
DUAL_TOP = DUAL_ROOT / "dual.prmtop"
DUAL_RST = DUAL_ROOT / "dual.rst7"
ORIGINAL_TOP = DATA_ROOT / "degauss_exp_windows" / "prmtop"
ORIGINAL_RST = DATA_ROOT / "degauss_exp_windows" / "eq.rst"
TARGETS = (0.0, 0.5, 1.0)

ENERGY = {
    name: re.compile(rf"{name}\s*=\s*([-\d.Ee+]+)")
    for name in ("Etot", "EPtot", "VDWAALS", "EELEC")
}
MBAR = re.compile(r"Energy at\s+([0-9.]+)\s*=\s*([-\d.Ee+]+)")


def mdin(
    lam: float,
    *,
    radius_path: bool,
    mbar: bool,
    original: bool = False,
) -> str:
    if original:
        alchemy = ""
    else:
        width = ""
        if radius_path:
            width = f"""
   sigma_max={20.0 / math.sqrt(2.0):.10f},
   elec_schedule=6, elec_schedule_c=4.0,"""
        alchemy = f"""
   icfe=1, ifsc=1, clambda={lam:.10f},
   timask1=':1', timask2=':2',
   scmask1=':1', scmask2=':2', crgmask=':2',
   ifsc_degauss=0, ifsc_q={1 if radius_path else 0}, ifsc_v=0,{width}
   ifmbar={1 if mbar else 0},"""
        if mbar:
            alchemy += """
   bar_intervall=1, mbar_states=3,
   mbar_lambda=0.0, 0.5, 1.0,"""
    return f"""matched sodium DEGAUSS IPS MBAR regression
 &cntrl
   imin=0, nstlim=1, dt=0.001, irest=0, ntx=1, ig=919191,
   ntt=3, tempi=298.15, temp0=298.15, gamma_ln=5.0,
   ntb=1, ntp=0, ntc=2, ntf=1, tol=0.000001,
   cut=8.0, iwrap=1, nsnb=10,
   ntpr=1, ntwr=1, ntwx=0,
   ips=1, idegauss=1, gbeta=0.2,{alchemy}
 /
"""


def last_value(text: str, pattern: re.Pattern[str]) -> float:
    values = pattern.findall(text)
    if not values:
        raise RuntimeError(f"Pattern {pattern.pattern!r} was not found")
    # The first block is the complete-system energy.  TI output later prints
    # endpoint decompositions and zero-filled bookkeeping blocks with the same
    # labels, which must not be mistaken for the sampled energy.
    return float(values[0])


def run(
    root: Path,
    label: str,
    topology: Path,
    restart: Path,
    input_text: str,
) -> tuple[dict[str, float], dict[float, float]]:
    input_path = root / f"{label}.in"
    output_path = root / f"{label}.out"
    input_path.write_text(input_text)
    subprocess.run(
        [
            str(EXE),
            "-O",
            "-i",
            str(input_path),
            "-p",
            str(topology),
            "-c",
            str(restart),
            "-o",
            str(output_path),
            "-r",
            str(root / f"{label}.rst7"),
            "-inf",
            str(root / f"{label}.info"),
        ],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
    )
    text = output_path.read_text()
    energies = {name: last_value(text, pattern) for name, pattern in ENERGY.items()}
    mbar_values = {float(lam): float(value) for lam, value in MBAR.findall(text)}
    return energies, mbar_values


def check_path(root: Path, radius_path: bool) -> None:
    name = "changing_radius" if radius_path else "fixed_radius"
    sampled, mbar_values = run(
        root,
        f"{name}_sampled",
        DUAL_TOP,
        DUAL_RST,
        mdin(0.5, radius_path=radius_path, mbar=True),
    )
    if set(mbar_values) != set(TARGETS):
        raise RuntimeError(f"{name}: incomplete MBAR matrix row: {mbar_values}")

    direct = {}
    for target in TARGETS:
        direct[target], _ = run(
            root,
            f"{name}_direct_{target:.1f}",
            DUAL_TOP,
            DUAL_RST,
            mdin(target, radius_path=radius_path, mbar=False),
        )

    # Kinetic energy is identical because all target runs start from the same
    # coordinates and random seed.  Therefore MBAR's total energy can be
    # compared directly with an independent target-Hamiltonian evaluation.
    errors = {
        target: mbar_values[target] - direct[target]["Etot"]
        for target in TARGETS
    }
    print(f"{name}: sampled Etot={sampled['Etot']:.10f}")
    for target in TARGETS:
        print(
            f"  lambda={target:.1f} MBAR={mbar_values[target]:.10f} "
            f"direct={direct[target]['Etot']:.10f} error={errors[target]:.3e}"
        )
    if max(abs(value) for value in errors.values()) > 2.0e-5:
        raise RuntimeError(f"{name}: MBAR target energies do not match direct runs")


def main() -> None:
    for required in (EXE, DUAL_TOP, DUAL_RST, ORIGINAL_TOP, ORIGINAL_RST):
        if not required.exists():
            raise FileNotFoundError(required)

    with tempfile.TemporaryDirectory(prefix="matched-sodium-mbar-") as temporary:
        root = Path(temporary)
        original, _ = run(
            root,
            "original_endpoint",
            ORIGINAL_TOP,
            ORIGINAL_RST,
            mdin(0.0, radius_path=False, mbar=False, original=True),
        )
        dual, _ = run(
            root,
            "dual_endpoint",
            DUAL_TOP,
            DUAL_RST,
            mdin(0.0, radius_path=False, mbar=False),
        )
        print("charged endpoint comparison")
        for name in ("EPtot", "VDWAALS", "EELEC"):
            difference = dual[name] - original[name]
            print(
                f"  {name}: original={original[name]:.8f} "
                f"dual={dual[name]:.8f} difference={difference:.3e}"
            )
            if abs(difference) > 2.0e-4:
                raise RuntimeError(f"Dual-topology endpoint mismatch in {name}")

        check_path(root, radius_path=False)
        check_path(root, radius_path=True)

    print("PASS: matched endpoint and both internal MBAR Hamiltonian rows agree.")


if __name__ == "__main__":
    main()
