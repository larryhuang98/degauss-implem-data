#!/usr/bin/env python3
"""Replay explicit Hamiltonians and analyze the sodium charge paths.

Every saved trajectory is evaluated with all 11 explicit state topologies.
The resulting complete energy matrix is analyzed with MBAR.  Pairwise BAR
estimates are also accumulated as an independent local-overlap diagnostic.
The first 10% of each trajectory is discarded.  No TI output or analytic
energy reconstruction is used.
"""

from __future__ import annotations

import argparse
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import math
from pathlib import Path
import re
import subprocess
import sys

import numpy as np
from scipy.optimize import brentq
from scipy.special import expit

# The installed JAX binary predates NumPy 2.  PyMBAR has a supported NumPy
# solver, which is sufficient for these small 11-state matrices.
sys.modules["jax"] = None
from pymbar import MBAR


DATA_ROOT = Path("/home8/larry/project/alchemical/hfe/Na")
REPO_ROOT = Path(__file__).resolve().parents[2]
REPLAY_INPUT = Path(__file__).with_name("energy_replay.in")
SANDER = Path(
    "/home8/larry/ambers/amber_merge_degauss_pmemd/"
    "build/AmberTools/src/sander/sander"
)
CAMPAIGNS = (
    "eel_explicit_fixed_exp11_reff020",
    "eel_explicit_radius_lin11_reffexp4_r020_200",
)
N_REPLICATES = 3
N_WINDOWS = 11
N_RECORDS = 1100
DISCARD_FRACTION = 0.10
KT = 0.00198720425864083 * 298.15
EEL_PATTERN = re.compile(
    r"^\s*VDWAALS\s*=.*?\bEEL\s*=\s*"
    r"([+-]?(?:\d+\.\d*|\.\d+)(?:[Ee][+-]?\d+)?)"
)
VDW_PATTERN = re.compile(
    r"^\s*VDWAALS\s*=\s*"
    r"([+-]?(?:\d+\.\d*|\.\d+)(?:[Ee][+-]?\d+)?)"
)


def run_root(campaign: str, replica: int) -> Path:
    return DATA_ROOT / f"{campaign}_rep{replica}"


def target_states(sampled_state: int) -> range:
    del sampled_state
    return range(N_WINDOWS)


def replay_output(campaign: str, replica: int, sampled: int, target: int) -> Path:
    return (
        run_root(campaign, replica)
        / "windows"
        / f"lambda_{sampled:02d}"
        / "replay"
        / f"state_{target:02d}"
        / "energy.out"
    )


def parse_component(path: Path, pattern: re.Pattern[str]) -> np.ndarray:
    values: list[float] = []
    if not path.exists():
        return np.asarray(values)
    with path.open(errors="ignore") as handle:
        for line in handle:
            match = pattern.search(line)
            if match:
                values.append(float(match.group(1)))
    return np.asarray(values, dtype=float)


def parse_eel(path: Path) -> np.ndarray:
    return parse_component(path, EEL_PATTERN)


def replay_one(task: tuple[str, int, int, int]) -> str:
    campaign, replica, sampled, target = task
    root = run_root(campaign, replica)
    window = root / "windows" / f"lambda_{sampled:02d}"
    output = replay_output(campaign, replica, sampled, target)
    existing = parse_eel(output)
    if len(existing) == N_RECORDS:
        return f"SKIP {campaign} rep{replica} sample{sampled:02d} state{target:02d}"

    work = output.parent
    work.mkdir(parents=True, exist_ok=True)
    command = [
        str(SANDER),
        "-O",
        "-i",
        str(REPLAY_INPUT),
        "-p",
        str(root / "topologies" / f"state_{target:02d}.prmtop"),
        "-c",
        str(window / "out.rst"),
        "-y",
        str(window / "trajectory.nc"),
        "-o",
        str(output),
        "-inf",
        str(work / "mdinfo"),
    ]
    completed = subprocess.run(
        command,
        cwd=work,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    (work / "stdout.log").write_text(completed.stdout)
    if completed.returncode:
        raise RuntimeError(
            f"Replay failed ({completed.returncode}): "
            f"{campaign} rep{replica} sample{sampled} state{target}"
        )
    count = len(parse_eel(output))
    if count != N_RECORDS:
        raise RuntimeError(
            f"Expected {N_RECORDS} replay energies, found {count} in {output}"
        )
    return f"DONE {campaign} rep{replica} sample{sampled:02d} state{target:02d}"


def replay_all(workers: int) -> None:
    if not SANDER.is_file():
        raise FileNotFoundError(SANDER)
    incomplete = []
    tasks = []
    for campaign in CAMPAIGNS:
        for replica in range(N_REPLICATES):
            root = run_root(campaign, replica)
            for sampled in range(N_WINDOWS):
                if not (root / "windows" / f"lambda_{sampled:02d}" / "DONE").exists():
                    incomplete.append(f"{campaign} rep{replica} window{sampled:02d}")
                for target in target_states(sampled):
                    tasks.append((campaign, replica, sampled, target))
    if incomplete:
        raise RuntimeError(
            "Production is incomplete:\n  " + "\n  ".join(incomplete)
        )

    print(f"Running {len(tasks)} all-state energy replays with {workers} workers")
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(replay_one, task): task for task in tasks}
        for number, future in enumerate(as_completed(futures), 1):
            print(f"[{number:3d}/{len(tasks)}] {future.result()}", flush=True)


def bar(work_forward: np.ndarray, work_reverse: np.ndarray) -> float:
    """Return the equal-sample BAR free-energy difference in reduced units."""

    def equation(delta_f: float) -> float:
        return float(
            np.mean(expit(delta_f - work_forward))
            - np.mean(expit(-delta_f - work_reverse))
        )

    scale = max(
        100.0,
        float(np.max(np.abs(work_forward))),
        float(np.max(np.abs(work_reverse))),
    )
    return float(brentq(equation, -2.0 * scale, 2.0 * scale))


def state_energies(
    campaign: str, replica: int, sampled: int, target: int
) -> np.ndarray:
    values = parse_eel(replay_output(campaign, replica, sampled, target))
    discard = max(1, math.floor(DISCARD_FRACTION * len(values)))
    values = values[discard:]
    expected = N_RECORDS - math.floor(DISCARD_FRACTION * N_RECORDS)
    if len(values) != expected:
        raise RuntimeError(
            f"Unexpected post-discard energy count for {campaign}, "
            f"rep{replica}, sampled {sampled}, target {target}: {len(values)}"
        )
    return values


def unchanged_vdw_difference(
    campaign: str,
    replica: int,
    sampled: int,
    first_target: int,
    second_target: int,
) -> float:
    first = parse_component(
        replay_output(campaign, replica, sampled, first_target), VDW_PATTERN
    )
    second = parse_component(
        replay_output(campaign, replica, sampled, second_target), VDW_PATTERN
    )
    count = min(len(first), len(second))
    if count != N_RECORDS:
        raise RuntimeError(
            f"Expected {N_RECORDS} VDW records, found {count}"
        )
    difference = float(np.max(np.abs(first[:count] - second[:count])))
    if difference > 1.0e-6:
        raise RuntimeError(
            f"VDW energy changed by {difference} kcal/mol for {campaign}, "
            f"rep{replica}, sampled window {sampled}"
        )
    return difference


def profile(campaign: str, replica: int) -> tuple[np.ndarray, list[dict[str, float]]]:
    increments = []
    diagnostics = []
    for lower_state in range(N_WINDOWS - 1):
        upper_state = lower_state + 1
        e_ll = state_energies(campaign, replica, lower_state, lower_state)
        e_lu = state_energies(campaign, replica, lower_state, upper_state)
        e_ul = state_energies(campaign, replica, upper_state, lower_state)
        e_uu = state_energies(campaign, replica, upper_state, upper_state)
        count = min(len(e_ll), len(e_lu), len(e_ul), len(e_uu))
        work_forward = (e_lu[:count] - e_ll[:count]) / KT
        work_reverse = (e_ul[:count] - e_uu[:count]) / KT
        max_vdw_difference = max(
            unchanged_vdw_difference(
                campaign, replica, lower_state, lower_state, upper_state
            ),
            unchanged_vdw_difference(
                campaign, replica, upper_state, lower_state, upper_state
            ),
        )
        reduced_delta = bar(work_forward, work_reverse)
        increment = reduced_delta * KT
        increments.append(increment)
        diagnostics.append(
            {
                "lower_window": lower_state,
                "upper_window": upper_state,
                "n_samples": count,
                "delta_g_kcal_mol": increment,
                "mean_forward_work_kcal_mol": float(np.mean(work_forward) * KT),
                "mean_reverse_work_kcal_mol": float(np.mean(work_reverse) * KT),
                "bar_acceptance_forward": float(
                    np.mean(expit(reduced_delta - work_forward))
                ),
                "bar_acceptance_reverse": float(
                    np.mean(expit(-reduced_delta - work_reverse))
                ),
                "max_vdw_difference_kcal_mol": max_vdw_difference,
            }
        )
    return np.concatenate(([0.0], np.cumsum(increments))), diagnostics


def mbar_profile(
    campaign: str, replica: int
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return the MBAR profile, formal uncertainty, and overlap matrix."""

    samples_per_state = N_RECORDS - math.floor(
        DISCARD_FRACTION * N_RECORDS
    )
    sample_count = N_WINDOWS * samples_per_state
    energies = np.empty((N_WINDOWS, sample_count), dtype=float)
    counts = np.full(N_WINDOWS, samples_per_state, dtype=int)

    offset = 0
    for sampled in range(N_WINDOWS):
        stop = offset + samples_per_state
        for target in range(N_WINDOWS):
            energies[target, offset:stop] = state_energies(
                campaign, replica, sampled, target
            )
        offset = stop

    reduced_energies = energies / KT
    # A configuration-dependent shift common to every target Hamiltonian does
    # not affect MBAR.  Removing it keeps the nonlinear solve well scaled.
    reduced_energies -= reduced_energies[0:1, :]
    estimator = MBAR(
        reduced_energies,
        counts,
        solver_protocol="robust",
        verbose=False,
    )
    differences = estimator.compute_free_energy_differences()
    overlap = estimator.compute_overlap()["matrix"]
    profile_values = differences["Delta_f"][0, :] * KT
    uncertainties = differences["dDelta_f"][0, :] * KT
    return profile_values, uncertainties, overlap


def write_analysis() -> None:
    figure_directory = REPO_ROOT / "figures"
    profile_path = figure_directory / "sodium_charge_profiles.csv"
    diagnostic_path = figure_directory / "sodium_charge_bar_diagnostics.csv"
    overlap_path = figure_directory / "sodium_charge_mbar_overlap.csv"
    summary_path = figure_directory / "sodium_charge_summary.json"
    rows = []
    diagnostic_rows = []
    overlap_rows = []
    summary = {}

    for campaign in CAMPAIGNS:
        manifest = json.loads(
            (run_root(campaign, 0) / "campaign_manifest.json").read_text()
        )
        lambdas = manifest["lambda_values"]
        radii = manifest["effective_radius_angstrom"]
        bar_profiles = []
        mbar_profiles = []
        mbar_uncertainties = []
        for replica in range(N_REPLICATES):
            bar_values, diagnostics = profile(campaign, replica)
            mbar_values, mbar_errors, overlap = mbar_profile(
                campaign, replica
            )
            bar_profiles.append(bar_values)
            mbar_profiles.append(mbar_values)
            mbar_uncertainties.append(mbar_errors)
            for item in diagnostics:
                diagnostic_rows.append(
                    {"campaign": campaign, "replica": replica, **item}
                )
            for sampled in range(N_WINDOWS):
                for target in range(N_WINDOWS):
                    overlap_rows.append(
                        {
                            "campaign": campaign,
                            "replica": replica,
                            "sampled_window": sampled,
                            "target_window": target,
                            "overlap": overlap[sampled, target],
                        }
                    )
            for window in range(N_WINDOWS):
                rows.append(
                    {
                        "campaign": campaign,
                        "replica": replica,
                        "window": window,
                        "lambda": lambdas[window],
                        "effective_radius_angstrom": radii[window],
                        "cumulative_delta_g_kcal_mol": bar_values[window],
                        "cumulative_bar_delta_g_kcal_mol": bar_values[window],
                        "cumulative_mbar_delta_g_kcal_mol": mbar_values[window],
                        "mbar_formal_uncertainty_kcal_mol": mbar_errors[window],
                    }
                )
        bar_array = np.asarray(bar_profiles)
        mbar_array = np.asarray(mbar_profiles)
        mbar_error_array = np.asarray(mbar_uncertainties)
        bar_endpoints = bar_array[:, -1]
        mbar_endpoints = mbar_array[:, -1]
        summary[campaign] = {
            "mbar_endpoint_by_replica_kcal_mol": mbar_endpoints.tolist(),
            "mbar_endpoint_mean_kcal_mol": float(np.mean(mbar_endpoints)),
            "mbar_endpoint_replica_sd_kcal_mol": float(
                np.std(mbar_endpoints, ddof=1)
            ),
            "mbar_formal_uncertainty_by_replica_kcal_mol": (
                mbar_error_array[:, -1].tolist()
            ),
            "bar_endpoint_by_replica_kcal_mol": bar_endpoints.tolist(),
            "bar_endpoint_mean_kcal_mol": float(np.mean(bar_endpoints)),
            "bar_endpoint_replica_sd_kcal_mol": float(
                np.std(bar_endpoints, ddof=1)
            ),
            "direction": "lambda=0 Na+ to lambda=1 neutral Na",
            "primary_estimator": "MBAR from complete explicit-state energy replay",
            "diagnostic_estimator": "accumulated adjacent-state BAR",
            "discard_fraction": DISCARD_FRACTION,
        }

    with profile_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    with diagnostic_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=diagnostic_rows[0].keys())
        writer.writeheader()
        writer.writerows(diagnostic_rows)
    with overlap_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=overlap_rows[0].keys())
        writer.writeheader()
        writer.writerows(overlap_rows)
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    print(f"Wrote {profile_path}")
    print(f"Wrote {diagnostic_path}")
    print(f"Wrote {overlap_path}")
    print(f"Wrote {summary_path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--replay",
        action="store_true",
        help="evaluate every trajectory under all 11 explicit topologies",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=24,
        help="maximum simultaneous sander replay processes",
    )
    arguments = parser.parse_args()
    if arguments.replay:
        replay_all(arguments.workers)
    write_analysis()


if __name__ == "__main__":
    main()
