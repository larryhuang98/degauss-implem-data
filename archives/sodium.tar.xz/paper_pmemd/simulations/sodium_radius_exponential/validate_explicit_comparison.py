#!/usr/bin/env python3
"""Validate every explicit topology used by the sodium charge paths."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

from setup_explicit_comparison import (
    AMBER_SODIUM_CHARGE,
    BASE_TOPOLOGY,
    DATA_ROOT,
    N_REPLICATES,
    PATHS,
    WATER_INPUT_RADIUS,
    section_bounds,
    section_values,
)


CHANGED_SECTIONS = {"CHARGE", "GAUSS_RADII_LIST"}
ABSOLUTE_TOLERANCE = 6.0e-7


def sections(text: str) -> dict[str, str]:
    names = [
        line.split(maxsplit=1)[1].strip()
        for line in text.splitlines()
        if line.startswith("%FLAG ")
    ]
    result = {}
    for name in names:
        start, end = section_bounds(text, name)
        result[name] = text[start:end]
    return result


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def close(actual: float, expected: float, label: str) -> None:
    if not math.isclose(
        actual, expected, rel_tol=0.0, abs_tol=ABSOLUTE_TOLERANCE
    ):
        raise RuntimeError(f"{label}: found {actual:.12g}, expected {expected:.12g}")


def main() -> None:
    base_text = BASE_TOPOLOGY.read_text()
    base_sections = sections(base_text)
    base_charges = section_values(base_text, "CHARGE")

    print("campaign,window,lambda,q_Na_e,R_eff_A,topology_sha256")
    for campaign, definition in PATHS.items():
        reference_root = DATA_ROOT / f"{campaign}_rep0"
        manifest = json.loads(
            (reference_root / "campaign_manifest.json").read_text()
        )
        if manifest["lambda_values"] != definition["lambdas"]:
            raise RuntimeError(f"{campaign}: manifest lambda schedule differs")
        if manifest["effective_radius_angstrom"] != definition["radii"]:
            raise RuntimeError(f"{campaign}: manifest radius schedule differs")

        for window, (lam, effective_radius) in enumerate(
            zip(definition["lambdas"], definition["radii"])
        ):
            path = reference_root / "topologies" / f"state_{window:02d}.prmtop"
            text = path.read_text()
            current_sections = sections(text)

            if set(current_sections) != set(base_sections) | {"GAUSS_RADII_LIST"}:
                raise RuntimeError(f"{path}: unexpected topology sections")
            for name, body in base_sections.items():
                if name not in CHANGED_SECTIONS and current_sections[name] != body:
                    raise RuntimeError(f"{path}: unexpected change in %FLAG {name}")

            charges = section_values(text, "CHARGE")
            close(
                charges[0],
                (1.0 - lam) * AMBER_SODIUM_CHARGE,
                f"{path}: sodium charge",
            )
            if charges[1:] != base_charges[1:]:
                raise RuntimeError(f"{path}: a non-sodium charge changed")

            input_radii = section_values(text, "GAUSS_RADII_LIST")
            close(
                input_radii[0] * math.sqrt(2.0),
                effective_radius,
                f"{path}: sodium effective radius",
            )
            for atom, radius in enumerate(input_radii[1:], 2):
                close(radius, WATER_INPUT_RADIUS, f"{path}: atom {atom} radius")

            reference_digest = digest(path)
            for replica in range(1, N_REPLICATES):
                copy = (
                    DATA_ROOT
                    / f"{campaign}_rep{replica}"
                    / "topologies"
                    / path.name
                )
                if digest(copy) != reference_digest:
                    raise RuntimeError(f"{copy}: differs from replica 0")

            print(
                f"{campaign},{window},{lam:.12g},{charges[0] / AMBER_SODIUM_CHARGE:.12g},"
                f"{input_radii[0] * math.sqrt(2.0):.12g},{reference_digest}"
            )

    print("PASS: only sodium charge and GAUSS_RADII_LIST vary; all replicas match")


if __name__ == "__main__":
    main()
