#!/usr/bin/env python3
"""Prepare the matched classical IPS sodium charge path.

The sodium charge is annihilated over 11 uniformly spaced lambda windows.
All Lennard--Jones parameters and all other topology sections are retained.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path

from setup_explicit_comparison import (
    AMBER_SODIUM_CHARGE,
    DATA_ROOT,
    N_REPLICATES,
    N_STEPS,
    replace_float_section,
    section_bounds,
    section_values,
)


CAMPAIGN = "eel_explicit_classical_lin11"
BASE_TOPOLOGY = DATA_ROOT / "classical_eel_bar" / "prmtop"
INITIAL_RESTART = DATA_ROOT / "classical_eel_bar" / "eq.rst"
LAMBDAS = [index / 10.0 for index in range(11)]


def sections(text: str) -> dict[str, str]:
    names = [
        line.split(maxsplit=1)[1].strip()
        for line in text.splitlines()
        if line.startswith("%FLAG ")
    ]
    result = {}
    for name in names:
        start, end = section_bounds(text, name)
        result[name] = text[start:end]
    return result


def state_topology(source: str, lam: float) -> str:
    charges = section_values(source, "CHARGE")
    if not math.isclose(
        charges[0], AMBER_SODIUM_CHARGE, rel_tol=0.0, abs_tol=1.0e-6
    ):
        raise ValueError("The classical base topology does not contain Na+")
    charges[0] = (1.0 - lam) * AMBER_SODIUM_CHARGE
    return replace_float_section(source, "CHARGE", charges)


def mdin(replica: int, window: int) -> str:
    seed = 735_000 + 100 * replica + window
    return f"""Explicit classical IPS sodium charge path; rep {replica}; window {window}
 &cntrl
   imin=0, nstlim={N_STEPS}, dt=0.001, ig={seed},
   irest=1, ntx=5,
   ntt=3, temp0=298.15, gamma_ln=5.0,
   ntb=1, ntp=0,
   ntc=2, ntf=2, tol=0.000001,
   cut=8.0,
   ntpr=1000, ntwr=2000, ntwx=1000, ioutfm=1,
   ips=1,
 /
"""


def validate(source: str) -> None:
    base_sections = sections(source)
    base_charges = section_values(source, "CHARGE")
    for replica in range(N_REPLICATES):
        root = DATA_ROOT / f"{CAMPAIGN}_rep{replica}"
        for window, lam in enumerate(LAMBDAS):
            topology = root / "topologies" / f"state_{window:02d}.prmtop"
            text = topology.read_text()
            current_sections = sections(text)
            if set(current_sections) != set(base_sections):
                raise RuntimeError(f"{topology}: topology sections changed")
            for name, body in base_sections.items():
                if name != "CHARGE" and current_sections[name] != body:
                    raise RuntimeError(
                        f"{topology}: unexpected change in %FLAG {name}"
                    )
            charges = section_values(text, "CHARGE")
            expected = (1.0 - lam) * AMBER_SODIUM_CHARGE
            if not math.isclose(
                charges[0], expected, rel_tol=0.0, abs_tol=6.0e-7
            ):
                raise RuntimeError(f"{topology}: incorrect sodium charge")
            if charges[1:] != base_charges[1:]:
                raise RuntimeError(f"{topology}: a non-sodium charge changed")

    for window in range(11):
        digests = []
        for replica in range(N_REPLICATES):
            path = (
                DATA_ROOT
                / f"{CAMPAIGN}_rep{replica}"
                / "topologies"
                / f"state_{window:02d}.prmtop"
            )
            digests.append(hashlib.sha256(path.read_bytes()).hexdigest())
        if len(set(digests)) != 1:
            raise RuntimeError(f"window {window}: replica topologies differ")


def main() -> None:
    source = BASE_TOPOLOGY.read_text()
    if not INITIAL_RESTART.exists():
        raise FileNotFoundError(INITIAL_RESTART)
    manifest = {
        "campaign": CAMPAIGN,
        "protocol": "explicit per-window topology; no TI routing",
        "description": "classical point-charge IPS; uniform lambda placement",
        "electrostatics": "classical IPS point charge",
        "lambda_values": LAMBDAS,
        "sodium_charge_e": [1.0 - value for value in LAMBDAS],
        "effective_radius_angstrom": [None] * 11,
        "sodium_vdw": "unchanged at every window",
        "replicates": N_REPLICATES,
        "steps_per_window": N_STEPS,
        "trajectory_interval_steps": 1000,
    }

    for replica in range(N_REPLICATES):
        root = DATA_ROOT / f"{CAMPAIGN}_rep{replica}"
        topology_directory = root / "topologies"
        window_directory = root / "windows"
        topology_directory.mkdir(parents=True, exist_ok=True)
        window_directory.mkdir(parents=True, exist_ok=True)
        restart = root / "eq.rst"
        if not restart.exists():
            os.symlink(INITIAL_RESTART, restart)
        (root / "campaign_manifest.json").write_text(
            json.dumps(manifest, indent=2) + "\n"
        )
        for window, lam in enumerate(LAMBDAS):
            topology = topology_directory / f"state_{window:02d}.prmtop"
            topology.write_text(state_topology(source, lam))
            directory = window_directory / f"lambda_{window:02d}"
            directory.mkdir(parents=True, exist_ok=True)
            (directory / "mdin.npt").write_text(mdin(replica, window))

    validate(source)
    print(json.dumps(manifest, indent=2))
    print("PASS: only the sodium charge changes; all replicas match")


if __name__ == "__main__":
    main()
