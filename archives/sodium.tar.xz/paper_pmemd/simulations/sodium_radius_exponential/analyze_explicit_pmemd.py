#!/usr/bin/env python3
"""Offline MBAR/BAR analysis using the pmemd IPS Hamiltonians.

Only the sodium charge and, for two DEGAUSS paths, Gaussian radius change
between the explicit topologies.  All common terms cancel from free-energy
estimators.  This script therefore evaluates the sodium-dependent
electrostatic pair, self, and IPS boundary terms directly from the
production pmemd formulations.

Sander trajectory replay is not used: its eedmeth=6 direct-pair loop uses
the point-charge IPS expression and does not read the pair Gaussian radii,
which is not equivalent when the sodium radius becomes large.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
import sys

import numpy as np
from scipy.io import netcdf_file
from scipy.optimize import brentq
from scipy.special import erf, expit

sys.modules["jax"] = None
from pymbar import MBAR

from setup_explicit_comparison import (
    DATA_ROOT,
    N_REPLICATES,
    section_values,
)


REPO_ROOT = Path(__file__).resolve().parents[2]
CAMPAIGNS = (
    "eel_explicit_classical_lin11",
    "eel_explicit_fixed_lin11_reff020",
    "eel_explicit_radius_lin11_reffexp4_r020_100",
    "eel_explicit_radius_lin11_reffexp4_r020_200",
)
N_WINDOWS = 11
N_RECORDS = 1100
DISCARD_RECORDS = 110
TEMPERATURE = 298.15
KT = 0.00198720425864083 * TEMPERATURE
RIPS = 8.0
RIPS2 = RIPS * RIPS
GBETA_INPUT = 0.2
BETAIJ_CLASSICAL_LIMIT = 100.0

AIPSE = np.asarray((-35.0 / 16.0, 35.0 / 16.0, -21.0 / 16.0, 5.0 / 16.0))
BIPSE = np.asarray((2.0 * AIPSE[1], 4.0 * AIPSE[2], 6.0 * AIPSE[3]))
CLASSICAL_PIPSEC = 1.0 + float(np.sum(AIPSE))
CLASSICAL_PIPSE0 = AIPSE[0] - CLASSICAL_PIPSEC


def gaussian_ips_coefficients() -> tuple[float, np.ndarray, np.ndarray, float, float]:
    """Return the common-environment IPS Gaussian coefficients from pmemd."""

    gbeta_reference = 2.0 * GBETA_INPUT * GBETA_INPUT
    gbetc = RIPS / math.sqrt(2.0 * gbeta_reference)
    gbetc2 = gbetc * gbetc
    exponential = math.exp(-gbetc2)
    root_pi = math.sqrt(math.pi)
    aipseg = np.empty(4)
    aipseg[0] = (
        2.0
        * exponential
        * gbetc
        * (57.0 + gbetc2 * (22.0 + 4.0 * gbetc2))
        / root_pi
        - 105.0 * math.erf(gbetc)
    ) / 48.0
    aipseg[1] = (
        105.0 * math.erf(gbetc)
        - 6.0
        * exponential
        * gbetc
        * (35.0 + gbetc2 * (18.0 + 4.0 * gbetc2))
        / root_pi
    ) / 48.0
    aipseg[2] = (
        6.0
        * exponential
        * gbetc
        * (21.0 + gbetc2 * (14.0 + 4.0 * gbetc2))
        / root_pi
        - 63.0 * math.erf(gbetc)
    ) / 48.0
    aipseg[3] = (
        15.0 * math.erf(gbetc)
        - exponential
        * gbetc
        * (30.0 + gbetc2 * (20.0 + 8.0 * gbetc2))
        / root_pi
    ) / 48.0
    bipseg = np.asarray(
        (2.0 * aipseg[1], 4.0 * aipseg[2], 6.0 * aipseg[3])
    )
    pipsec = math.erf(gbetc) + float(np.sum(aipseg))
    pipse0 = aipseg[0] - pipsec
    return gbetc, aipseg, bipseg, pipsec, pipse0


GBETC, AIPSEG, BIPSEG, PIPSEC, PIPSE0 = gaussian_ips_coefficients()


def run_root(campaign: str, replica: int) -> Path:
    return DATA_ROOT / f"{campaign}_rep{replica}"


def load_trajectory(path: Path) -> tuple[np.ndarray, np.ndarray]:
    with netcdf_file(path, "r", mmap=False) as trajectory:
        coordinates = np.asarray(
            trajectory.variables["coordinates"].data, dtype=np.float64
        )
        cell_lengths = np.asarray(
            trajectory.variables["cell_lengths"].data, dtype=np.float64
        )
        cell_angles = np.asarray(
            trajectory.variables["cell_angles"].data, dtype=np.float64
        )
    if coordinates.shape[0] != N_RECORDS:
        raise RuntimeError(
            f"{path}: found {coordinates.shape[0]} frames, expected {N_RECORDS}"
        )
    if not np.allclose(cell_angles, 90.0, atol=1.0e-8, rtol=0.0):
        raise RuntimeError(f"{path}: only orthorhombic cells are supported")
    if np.any(cell_lengths <= 2.0 * RIPS):
        raise RuntimeError(f"{path}: cell is too short for minimum-image cutoff")
    return coordinates[DISCARD_RECORDS:], cell_lengths[DISCARD_RECORDS:]


def pair_shape(
    distance: np.ndarray,
    gbeta_i: float,
    gbeta_j: np.ndarray,
) -> np.ndarray:
    """Dimensionless pmemd Gaussian-electrostatic IPS pair potential."""

    uips = distance / RIPS
    uips2 = uips * uips
    betaij = 1.0 / np.sqrt(gbeta_i + gbeta_j)
    shape = np.full_like(distance, PIPSEC)

    classical = betaij >= BETAIJ_CLASSICAL_LIMIT
    inside_cutoff = distance < RIPS
    point_region = inside_cutoff & classical

    gaussian = ~classical
    rgc = np.empty_like(distance)
    rgc[gaussian] = GBETC / betaij[gaussian]
    # PMEMD builds the direct pair list with the IPS cutoff.  The Gaussian
    # matching radius can exceed RIPS for broad sites, but it must not admit
    # pairs that are absent from that list.
    gaussian_region = gaussian & inside_cutoff & (distance < rgc)
    point_region |= gaussian & inside_cutoff & ~gaussian_region

    if np.any(point_region):
        u2 = uips2[point_region]
        shape[point_region] = (
            1.0 / uips[point_region]
            + AIPSE[0]
            + u2 * (AIPSE[1] + u2 * (AIPSE[2] + u2 * AIPSE[3]))
        )

    if np.any(gaussian_region):
        radius = rgc[gaussian_region]
        ug = RIPS / radius
        ug2 = ug * ug
        ug4 = ug2 * ug2
        ug6 = ug4 * ug2
        u2 = uips2[gaussian_region]
        uipsg2 = (distance[gaussian_region] / radius) ** 2
        gbetr = betaij[gaussian_region] * distance[gaussian_region]
        coulomb_part = (
            AIPSE[0] * (1.0 - ug)
            + u2
            * (
                AIPSE[1] * (1.0 - ug2 * ug)
                + u2
                * (
                    AIPSE[2] * (1.0 - ug4 * ug)
                    + u2 * AIPSE[3] * (1.0 - ug6 * ug)
                )
            )
        )
        gaussian_part = (
            erf(gbetr) / uips[gaussian_region]
            + ug
            * (
                AIPSEG[0]
                + uipsg2
                * (
                    AIPSEG[1]
                    + uipsg2 * (AIPSEG[2] + uipsg2 * AIPSEG[3])
                )
            )
        )
        shape[gaussian_region] = coulomb_part + gaussian_part

    return shape - PIPSEC


def classical_pair_shape(distance: np.ndarray) -> np.ndarray:
    """Dimensionless classical point-charge IPS pair potential."""

    shape = np.full_like(distance, CLASSICAL_PIPSEC)
    inside_cutoff = distance < RIPS
    if np.any(inside_cutoff):
        uips = distance[inside_cutoff] / RIPS
        uips2 = uips * uips
        shape[inside_cutoff] = (
            1.0 / uips
            + AIPSE[0]
            + uips2
            * (AIPSE[1] + uips2 * (AIPSE[2] + uips2 * AIPSE[3]))
        )
    return shape - CLASSICAL_PIPSEC


def variable_energy_matrix(campaign: str, replica: int) -> np.ndarray:
    """Return U[sampled_window, target_window, retained_frame]."""

    root = run_root(campaign, replica)
    manifest = json.loads((root / "campaign_manifest.json").read_text())
    classical = manifest.get("electrostatics") == "classical IPS point charge"
    topologies = [
        (
            root / "topologies" / f"state_{window:02d}.prmtop"
        ).read_text()
        for window in range(N_WINDOWS)
    ]
    charges = [section_values(text, "CHARGE") for text in topologies]
    environment_charge = np.asarray(charges[0][1:], dtype=float)
    for target in range(N_WINDOWS):
        if charges[target][1:] != charges[0][1:]:
            raise RuntimeError(f"{campaign}: a non-sodium charge changes")

    if classical:
        radii = None
        environment_gbeta = None
    else:
        radii = [
            section_values(text, "GAUSS_RADII_LIST") for text in topologies
        ]
        for target in range(N_WINDOWS):
            if radii[target][1:] != radii[0][1:]:
                raise RuntimeError(f"{campaign}: an environment radius changes")
        environment_gbeta = 2.0 * np.asarray(radii[0][1:], dtype=float) ** 2

    retained = N_RECORDS - DISCARD_RECORDS
    energies = np.empty((N_WINDOWS, N_WINDOWS, retained), dtype=float)

    for sampled in range(N_WINDOWS):
        trajectory = (
            root / "windows" / f"lambda_{sampled:02d}" / "trajectory.nc"
        )
        coordinates, cell_lengths = load_trajectory(trajectory)
        displacement = coordinates[:, 1:, :] - coordinates[:, :1, :]
        displacement -= cell_lengths[:, None, :] * np.rint(
            displacement / cell_lengths[:, None, :]
        )
        distances = np.sqrt(np.sum(displacement * displacement, axis=2))

        for target in range(N_WINDOWS):
            sodium_charge = charges[target][0]
            if classical:
                shape = classical_pair_shape(distances)
                pipse0 = CLASSICAL_PIPSE0
                pipsec = CLASSICAL_PIPSEC
            else:
                sodium_gbeta = 2.0 * radii[target][0] ** 2
                shape = pair_shape(
                    distances,
                    sodium_gbeta,
                    np.broadcast_to(environment_gbeta, distances.shape),
                )
                pipse0 = PIPSE0
                pipsec = PIPSEC
            pair_energy = (
                sodium_charge
                / RIPS
                * np.sum(shape * environment_charge[None, :], axis=1)
            )
            self_energy = (
                0.5 * sodium_charge * sodium_charge * pipse0 / RIPS
            )
            total_charge = sodium_charge + float(np.sum(environment_charge))
            boundary_energy = 0.5 * total_charge * total_charge * pipsec / RIPS
            energies[sampled, target, :] = (
                pair_energy + self_energy + boundary_energy
            )

    return energies


def bar(work_forward: np.ndarray, work_reverse: np.ndarray) -> float:
    def equation(delta_f: float) -> float:
        return float(
            np.mean(expit(delta_f - work_forward))
            - np.mean(expit(-delta_f - work_reverse))
        )

    scale = max(
        100.0,
        float(np.max(np.abs(work_forward))),
        float(np.max(np.abs(work_reverse))),
    )
    return float(brentq(equation, -2.0 * scale, 2.0 * scale))


def analyze_matrix(
    energies: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, list[dict[str, float]]]:
    retained = energies.shape[2]
    counts = np.full(N_WINDOWS, retained, dtype=int)
    reduced = np.concatenate(
        [energies[sampled] for sampled in range(N_WINDOWS)], axis=1
    ) / KT
    reduced -= reduced[0:1, :]
    estimator = MBAR(reduced, counts, solver_protocol="robust", verbose=False)
    differences = estimator.compute_free_energy_differences()
    mbar_profile = differences["Delta_f"][0, :] * KT
    mbar_uncertainty = differences["dDelta_f"][0, :] * KT
    overlap = estimator.compute_overlap()["matrix"]

    increments = []
    diagnostics = []
    for lower in range(N_WINDOWS - 1):
        upper = lower + 1
        forward = (
            energies[lower, upper, :] - energies[lower, lower, :]
        ) / KT
        reverse = (
            energies[upper, lower, :] - energies[upper, upper, :]
        ) / KT
        reduced_delta = bar(forward, reverse)
        increments.append(reduced_delta * KT)
        diagnostics.append(
            {
                "lower_window": lower,
                "upper_window": upper,
                "n_samples": retained,
                "delta_g_kcal_mol": reduced_delta * KT,
                "mean_forward_work_kcal_mol": float(np.mean(forward) * KT),
                "mean_reverse_work_kcal_mol": float(np.mean(reverse) * KT),
                "bar_acceptance_forward": float(
                    np.mean(expit(reduced_delta - forward))
                ),
                "bar_acceptance_reverse": float(
                    np.mean(expit(-reduced_delta - reverse))
                ),
            }
        )
    bar_profile = np.concatenate(([0.0], np.cumsum(increments)))
    return mbar_profile, mbar_uncertainty, bar_profile, overlap, diagnostics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--campaign",
        action="append",
        choices=CAMPAIGNS,
        help="analyze only the selected campaign (repeatable)",
    )
    arguments = parser.parse_args()
    selected_campaigns = arguments.campaign or list(CAMPAIGNS)

    figure_directory = REPO_ROOT / "figures"
    profile_rows = []
    diagnostic_rows = []
    overlap_rows = []
    summary = {}
    matrices = {}

    for campaign in selected_campaigns:
        manifest = json.loads(
            (run_root(campaign, 0) / "campaign_manifest.json").read_text()
        )
        is_classical = (
            manifest.get("electrostatics") == "classical IPS point charge"
        )
        mbar_profiles = []
        bar_profiles = []
        mbar_uncertainties = []
        for replica in range(N_REPLICATES):
            print(f"Evaluating {campaign} replica {replica}", flush=True)
            energies = variable_energy_matrix(campaign, replica)
            matrices[f"{campaign}_rep{replica}"] = energies
            mbar_values, mbar_errors, bar_values, overlap, diagnostics = (
                analyze_matrix(energies)
            )
            mbar_profiles.append(mbar_values)
            mbar_uncertainties.append(mbar_errors)
            bar_profiles.append(bar_values)
            for item in diagnostics:
                diagnostic_rows.append(
                    {"campaign": campaign, "replica": replica, **item}
                )
            for sampled in range(N_WINDOWS):
                for target in range(N_WINDOWS):
                    overlap_rows.append(
                        {
                            "campaign": campaign,
                            "replica": replica,
                            "sampled_window": sampled,
                            "target_window": target,
                            "overlap": overlap[sampled, target],
                        }
                    )
            for window in range(N_WINDOWS):
                radius = manifest["effective_radius_angstrom"][window]
                profile_rows.append(
                    {
                        "campaign": campaign,
                        "replica": replica,
                        "window": window,
                        "lambda": manifest["lambda_values"][window],
                        "effective_radius_angstrom": (
                            float("nan") if radius is None else radius
                        ),
                        "cumulative_mbar_delta_g_kcal_mol": mbar_values[window],
                        "mbar_formal_uncertainty_kcal_mol": mbar_errors[window],
                        "cumulative_bar_delta_g_kcal_mol": bar_values[window],
                    }
                )

        mbar_array = np.asarray(mbar_profiles)
        bar_array = np.asarray(bar_profiles)
        uncertainty_array = np.asarray(mbar_uncertainties)
        summary[campaign] = {
            "mbar_endpoint_by_replica_kcal_mol": mbar_array[:, -1].tolist(),
            "mbar_endpoint_mean_kcal_mol": float(np.mean(mbar_array[:, -1])),
            "mbar_endpoint_replica_sd_kcal_mol": float(
                np.std(mbar_array[:, -1], ddof=1)
            ),
            "mbar_formal_uncertainty_by_replica_kcal_mol": (
                uncertainty_array[:, -1].tolist()
            ),
            "bar_endpoint_by_replica_kcal_mol": bar_array[:, -1].tolist(),
            "bar_endpoint_mean_kcal_mol": float(np.mean(bar_array[:, -1])),
            "bar_endpoint_replica_sd_kcal_mol": float(
                np.std(bar_array[:, -1], ddof=1)
            ),
            "direction": "lambda=0 Na+ to lambda=1 neutral Na",
            "primary_estimator": (
                "MBAR from offline pmemd classical IPS sodium Hamiltonians"
                if is_classical
                else "MBAR from offline pmemd DEGAUSS+IPS sodium Hamiltonians"
            ),
            "diagnostic_estimator": "accumulated adjacent-state BAR",
            "discarded_records_per_window": DISCARD_RECORDS,
        }

    outputs = {
        "sodium_charge_profiles.csv": profile_rows,
        "sodium_charge_bar_diagnostics.csv": diagnostic_rows,
        "sodium_charge_mbar_overlap.csv": overlap_rows,
    }
    for name, rows in outputs.items():
        path = figure_directory / name
        with path.open("w", newline="") as handle:
            writer = csv.DictWriter(
                handle, fieldnames=rows[0].keys(), lineterminator="\n"
            )
            writer.writeheader()
            writer.writerows(rows)
        print(f"Wrote {path}")

    matrix_path = figure_directory / "sodium_charge_pmemd_energy_matrices.npz"
    np.savez_compressed(matrix_path, **matrices)
    summary_path = figure_directory / "sodium_charge_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    print(f"Wrote {matrix_path}")
    print(f"Wrote {summary_path}")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
