# CPU/GPU DEGAUSS property equivalence, 2026-09-28

This protocol is fixed before production outcomes are inspected. It compares the
same DEGAUSS Hamiltonian, not DEGAUSS against a different classical force field.
No source or selected executable will be modified. Hashes are in manifest.json.

## Systems and ensembles

Methanol (2121 atoms), ethanol (2316), benzene (2505) in water. Original single
solute topologies are used, with idegauss=1, alpha=18.17, beta=3.65, Gaussian input
radius=0.2 A, charge scale=1. These are fully coupled states. All have 8 A cutoff,
order-4 PME, 2 fs, SHAKE on H bonds, ntf=1, tolerance 1e-7, Langevin 300 K and
gamma=2/ps. NPT uses the Monte Carlo barostat, not Berendsen ensemble fluctuations.
Common equilibrated starting configurations are produced by the CPU reference:
100 ps NPT then 50 ps NVT. No basis collector is used for NPT.

For each backend (CPU, immutable SPFP, immutable DPFP) and each system:
- Four independent seeded NVT replicas: 40 ps discarded, 200 ps analyzed.
- Four independent seeded NPT replicas: 40 ps discarded, 200 ps analyzed.
- One common-start 50 ps NVE run at 2 fs, repeated at 1 fs if drift requires it.
NVT coordinates are saved every 0.1 ps; thermodynamics every 0.1 ps. NPT coordinates
are saved every 1 ps; densities/volumes every 0.1 ps. NVE energies every 0.1 ps.
The NVT GPU runs collect the existing exact cross-lambda basis every 500 steps.
SPFP performance optimizations are enabled; the small-system RNG prefetch remains
disabled, matching the retained small-system preset. DPFP uses the same flags.

## Numerical checks

Zero-initial-velocity, near-fixed-coordinate runs compare analytic forces from
CPU, SPFP, DPFP at the original parameters and alpha/beta +/-10%, Gaussian input
radii 0.1/0.4 A, plus a heterogeneous per-atom radius list. Near-zero step size
allows forces to be recovered from double-precision restart velocities. A
Berendsen fixed-coordinate pressure/virial probe is separate from NPT sampling.
Large-system baseline snapshots are also checked. Parameter changes are verified
in the printed parameter summary, not assumed merely because a file was edited.

## Analysis and criteria

Report differences and 95% confidence intervals, not just failure to reject a
zero difference. Replica means are the primary independent observations. Paired
CPU/GPU replica differences use a Student-t interval (four independently seeded
replica pairs); time frames are not treated as independent replicates. Same
seed numbers do not imply matching CPU/GPU random streams.

Prespecified practical equivalence margins for this initial validation:
- Mean temperature: +/-1 K.
- Mean NVT potential energy per atom: +/-0.01 kcal/mol/atom.
- NPT mean density: +/-0.5% relative to CPU.
- Water self diffusion: +/-5% relative to CPU.
- Water rank-2 orientational integral (0..10 ps): +/-5% relative to CPU.
- Solute diffusion and orientational integral: +/-15% relative to CPU.
An interval entirely inside the margin is evidence of equivalence at that
tolerance. An interval crossing a margin is inconclusive unless a reproducible
offset is established. These tolerances are not universal force-field accuracy
requirements. Tight fitting objectives may require tighter tests.

Diffusion uses identical periodic boxes and matched thermostat: multiple-origin
MSD slopes at 5..20 ps (water) and 10..40 ps (solute). Water uses oxygen positions;
solute uses reconstructed molecular COM. Coordinates are unwrapped before MSD.
Water orientation uses its dipole direction, and solute orientation uses a heavy
atom axis (benzene uses the ring normal). Integrated correlations have fixed
finite integration limits and will be named accordingly, not called converged
infinite-time relaxation times. NVT dynamics describe this specified Langevin
process, not thermostat-free experimental dynamics.

Energy fluctuation estimates, RDFs and NVE drift are diagnostic. Heat capacities,
compressibilities, binding/unbinding rates and converged alchemical free energies
are not certified by these short tests. NPT support of the ordinary MD path must
not be described as NPT support of the native coefficient collector.

GPU hardware is busy: these are correctness tests and no timing/speed claim is
made. Failed device-availability pilots are retained separately.

## Supplemental numerical control, added 2026-09-28 after inspecting FFT choices

The same default PME input selected different FFT meshes on CPU and GPU. For
example the methanol fixed snapshot used CPU 30x30x30 and GPU 28x32x28. This
confounds floating-point precision with reciprocal-space discretization.
All original cases and property trajectories are retained with their actual
default grids; their differences must be described accordingly.

A separate `fixed_matched_mesh` suite repeats all 33 parameter/virial/large-system
cases on CPU, SPFP and DPFP with explicit common 32x32x32 meshes for small systems
and 64x64x64 for large systems. The original order-6 cases keep order 6; all
others keep order 4. Coordinates, parameters, cutoff and all other numerical
inputs remain those of the original fixed-coordinate case. The script checks
the actual printed mesh. This separates the grid effect from arithmetic
precision. It does not replace production outcomes or change any equivalence
margins. Interpret single-point controls separately from ensemble properties.
