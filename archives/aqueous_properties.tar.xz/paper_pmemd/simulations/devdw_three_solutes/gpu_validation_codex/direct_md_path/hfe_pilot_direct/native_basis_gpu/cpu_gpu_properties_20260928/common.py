"""Matched CPU/GPU DEGAUSS validation; never edits the selected source or binary."""
import os, re, json, subprocess, time, hashlib
from pathlib import Path
import numpy as np
from netCDF4 import Dataset

HERE = Path(__file__).resolve().parent
ROOT = Path('/home8/larry/ambers/amber_merge_degauss_pmemd')
SIM = Path('/home8/larry/project/alchemical/hfe/paper_pmemd/simulations/devdw_three_solutes')
B = SIM/'gpu_validation_codex/direct_md_path/hfe_pilot_direct/native_basis_gpu'
EXES = {'cpu': HERE/'pmemd.cpu.reference',
        'spfp': B/'parallel_bonded_clear/pmemd.cuda_SPFP.bonded',
        'dpfp': B/'parallel_bonded_clear/pmemd.cuda_DPFP.bonded'}
FLAGS = {'FORCE_GRAPH':1, 'PME_GRAPH':0, 'SHARED_SKIN_SYNC':1,
         'ACTIVE_CONSTANTS':1, 'CONSTANT_GRAPH':1, 'FUSED_SKIN_KE':1,
         'UPDATE_SNAPSHOT':1, 'KINETIC_BLOCKS':1, 'VELOCITY_KE':1,
         'PARALLEL_BONDED':1, 'PARALLEL_FORCE':1,
         'KINETIC_STREAM':0, 'RNG_PREFETCH':0}

def values(text, name, cast=float):
    m = re.search(r'^%FLAG\s+'+re.escape(name)+r'\s*\n%FORMAT[^\n]*\n(.*?)(?=^%FLAG|\Z)', text, re.M|re.S)
    if not m: raise ValueError(name)
    return np.array(list(map(cast,m[1].split())))

def env_for(engine, optimized=True):
    env = {k:v for k,v in os.environ.items() if not k.startswith('DEGAUSS_')}
    env.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', CUDA_VISIBLE_DEVICES='0')
    if engine != 'cpu':
        env.update({'DEGAUSS_'+k:str(v if optimized else 0) for k,v in FLAGS.items()})
    return env

def mdin(steps=1000, dt=.002, seed=271828, ensemble='nvt', ntwx=50,
         restart=True, ntc=2, ntpr=50, params='', order=4, barostat=2):
    npt = ensemble=='npt'; nve=ensemble=='nve'
    return f'''CPU GPU property validation: {ensemble}
 &cntrl
 imin=0, nstlim={steps}, dt={dt:.12g}, ig={seed},
 irest={int(restart)}, ntx={5 if restart else 1},
 ntt={0 if nve else 3}, temp0=300, tempi=300, gamma_ln={0 if nve else 2},
 ntb={2 if npt else 1}, ntp={1 if npt else 0},
 {('barostat='+str(barostat)+', pres0=1.0, taup=2.0,') if npt else ''}
 cut=8.0, ntc={ntc}, ntf=1, tol=0.0000001, nscm={0 if nve else 1000},
 ioutfm=1, ntxo=2, iwrap=0, ntpr={ntpr}, ntwr={steps}, ntwx={ntwx}, ntwe=0,
 idegauss=1, icfe=0, {params}
 /
 &ewald order={order}, /
'''

def run(engine, inp, top, coord, prefix, optimized=True, extra_env=None):
    prefix=Path(prefix);prefix.parent.mkdir(parents=True,exist_ok=True)
    inpath=Path(str(prefix)+'.in');inpath.write_text(inp)
    env=env_for(engine,optimized)
    if extra_env:env.update(extra_env)
    cmd=[str(EXES[engine]),'-O','-i',str(inpath),'-p',str(top),'-c',str(coord),
         '-o',str(prefix)+'.out','-r',str(prefix)+'.rst','-x',str(prefix)+'.nc','-inf',str(prefix)+'.info']
    start=time.time()
    with Path(str(prefix)+'.log').open('w') as f:
        p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
    result={'engine':engine,'returncode':p.returncode,'wall_seconds':time.time()-start,'command':cmd}
    Path(str(prefix)+'.run.json').write_text(json.dumps(result,indent=2))
    if p.returncode:
        raise RuntimeError(str(prefix)+' failed:\n'+Path(str(prefix)+'.log').read_text()[-1800:])
    data=Path(str(prefix)+'.out').read_text()
    steps=int(re.search(r'nstlim=(\d+)',inp)[1])
    assert re.search(r'NSTEP\s*=\s*'+str(steps)+r'\b',data),(prefix,'incomplete')
    if re.search(r'\b(?:NaN|Infinity)\b',data,re.I):raise RuntimeError(str(prefix)+' nonfinite output')
    return Path(str(prefix)+'.rst')

def records(path):
    text=Path(path).read_text()
    # Drop final averages/RMS so these cannot masquerade as time samples.
    text=text.split('A V E R A G E S')[0]
    out=[]
    for m in re.finditer(r'NSTEP\s*=\s*(\d+)\s+TIME\(PS\)\s*=\s*([-+\d.Ee]+)(.*?)(?=NSTEP\s*=|\Z)',text,re.S):
        row={'step':int(m[1]),'time_ps':float(m[2])}
        for key,val in re.findall(r'([A-Za-z0-9()_ /-]+?)\s*=\s*([-+]?\d+(?:\.\d*)?(?:[Ee][-+]?\d+)?)',m[3]):
            row[key.strip()]=float(val)
        out.append(row)
    return out

def dump_json(path,obj):
    Path(path).write_text(json.dumps(obj,indent=2,allow_nan=False))
